package com.capitalone.api.card.rest.config;

import org.junit.Assert;
import org.junit.Test;

public class ResourceConfigTest {

	@Test
	public void testResourceConfig(){
		ResourceConfig config = new ResourceConfig();
		Assert.assertTrue((Boolean) config.getProperties().get("jersey.config.xml.security.disable"));
	}
}