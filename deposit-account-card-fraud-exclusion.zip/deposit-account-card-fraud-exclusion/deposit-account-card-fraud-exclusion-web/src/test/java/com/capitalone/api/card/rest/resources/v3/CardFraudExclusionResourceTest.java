package com.capitalone.api.card.rest.resources.v3;

import static junit.framework.Assert.assertNotNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.mockito.Mockito.when;

import org.apache.log4j.Appender;
import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggingEvent;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import static org.mockito.Matchers.any;

import com.capitalone.api.card.model.v3.FraudExclusionFormParams;
import com.capitalone.api.card.model.v3.FraudExclusionHeaderParams;
import com.capitalone.api.card.model.v3.FraudExclusionPathParams;
import com.capitalone.api.card.model.v3.FraudExclusionRequest;
import com.capitalone.api.card.model.v3.FraudExclusionRetrievalRequest;
import com.capitalone.api.card.model.v3.FraudExclusionRetrievalResponse;
import com.capitalone.api.card.service.api.CardFraudExclusionService;
import com.capitalone.api.commons.model.EntityRequest;
import com.capitalone.api.model.id.ReferenceId;

public class CardFraudExclusionResourceTest {

	@InjectMocks
	private CardFraudExclusionResource resource;

	@Mock
	private CardFraudExclusionService service;

	@Mock
	private Appender mockAppender;

	private ArgumentCaptor<LoggingEvent> logMessageCaptor;

	private final static String API_KEY = "MOBILE";

	private final static String USER = "221655";

	private final static String PROFILE_SOR_ID = "185";

	private final static String ACCOUNT_ID = "00000000001";

	private final static String CARD_FIRST_SIX = "510805";

	private final static String CARD_LAST_FOUR = "0222";

	private final static ReferenceId CARD_REFERENCE_ID;

	private final static ReferenceId ACCOUNT_REFERENCE_ID;

	private final static String INTERACTION_ID = "590680271504594";

	private final static String START_DATE = "2015-06-25";

	private final static String END_DATE = "2015-06-27";

	private final static String NOTE = "Italy here I come!";

	private final static String CARD_ACTION_CODE = "TravelNotification";

	static {
		CARD_REFERENCE_ID = ReferenceId
				.valueOf("accountId=00000000001~~sorId=185~~firstSix=510805~~lastFour=0222");
		ACCOUNT_REFERENCE_ID = ReferenceId
				.valueOf("accountId=00000000001~~sorId=185");

	}

	@Before
	public void setUp() throws Exception {
		initMocks(this);
		Logger.getRootLogger().addAppender(mockAppender);
		logMessageCaptor = ArgumentCaptor.forClass(LoggingEvent.class);
	}

	@After
	public void tearDown() throws Exception {
		service = null;
	}

	@Test
	public void addFraudExclusionTestForSuccess() {

		FraudExclusionHeaderParams entityRequest = new FraudExclusionHeaderParams();
		entityRequest.setApiKey(API_KEY);
		entityRequest.setClientCorrelationId(INTERACTION_ID);
		entityRequest.setUserId(USER);

		FraudExclusionPathParams pathParams = new FraudExclusionPathParams();
		pathParams.setAccountReferenceId(ACCOUNT_REFERENCE_ID);
		pathParams.setCardReferenceId(CARD_REFERENCE_ID);

		FraudExclusionFormParams formParams = new FraudExclusionFormParams();
		formParams.setCardActionCode(CARD_ACTION_CODE);
		formParams.setExclusionEndDate(END_DATE);
		formParams.setExclusionStartDate(START_DATE);
		formParams.setServicingNotes(NOTE);
		formParams.setIsEmailResponseRequired(true);

		ArgumentCaptor<FraudExclusionRequest> captureRequest = ArgumentCaptor
				.forClass(FraudExclusionRequest.class);
		ArgumentCaptor<EntityRequest> entityRequestRequest = ArgumentCaptor
				.forClass(EntityRequest.class);
		doNothing().when(service).create(captureRequest.capture(),
				entityRequestRequest.capture());

		resource.addFraudExclusion(entityRequest, pathParams, formParams);

		verify(service, times(1)).create(captureRequest.capture(),
				entityRequestRequest.capture());
		FraudExclusionRequest actualRequest = captureRequest.getAllValues()
				.get(0);
		assertNotNull(actualRequest);
		assertEquals(CARD_ACTION_CODE, actualRequest.getCardActionCode());
		assertEquals(END_DATE, actualRequest.getExclusionEndDate());
		assertEquals(START_DATE, actualRequest.getExclusionStartDate());
		assertTrue(actualRequest.isEmailResponseRequired());
		assertEquals(NOTE, actualRequest.getServicingNotes());
		assertEquals(PROFILE_SOR_ID, actualRequest.getSorId());
		assertEquals(ACCOUNT_ID, actualRequest.getAccountNumber());

		assertEquals(ACCOUNT_ID, actualRequest.getCardReferenceId()
				.getAccountId());
		assertEquals(CARD_FIRST_SIX, actualRequest.getCardReferenceId()
				.getFirstSix());
		assertEquals(CARD_LAST_FOUR, actualRequest.getCardReferenceId()
				.getLastFour());

		assertEquals(ACCOUNT_ID, actualRequest.getAccountReferenceId()
				.getAccountId());
		assertEquals(PROFILE_SOR_ID, actualRequest.getAccountReferenceId()
				.getSystemOfRecordId());
	}
	
	@Test
    public void getFraudExclusionTest() {
	    
	    FraudExclusionHeaderParams entityRequest = new FraudExclusionHeaderParams();
        entityRequest.setApiKey(API_KEY);
        entityRequest.setClientCorrelationId(INTERACTION_ID);
        entityRequest.setUserId(USER);

        FraudExclusionPathParams pathParams = new FraudExclusionPathParams();
        pathParams.setAccountReferenceId(ACCOUNT_REFERENCE_ID);
        pathParams.setCardReferenceId(CARD_REFERENCE_ID);

        FraudExclusionRetrievalResponse response = new FraudExclusionRetrievalResponse();
        response.setExclusionEndDate(END_DATE);
        response.setExclusionStartDate(START_DATE);
        
        when(service.retrieve(any(FraudExclusionRetrievalRequest.class), any(EntityRequest.class))).thenReturn(response);
        FraudExclusionRetrievalResponse retrievalResponse = resource.getFraudExclusion(entityRequest, pathParams);

        assertEquals(response.getExclusionStartDate(), retrievalResponse.getExclusionStartDate());
        assertEquals(response.getExclusionEndDate(),retrievalResponse.getExclusionEndDate());
        
	}

}