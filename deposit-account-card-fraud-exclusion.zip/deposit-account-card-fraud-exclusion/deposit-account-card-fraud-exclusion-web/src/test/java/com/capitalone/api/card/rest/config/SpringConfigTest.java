package com.capitalone.api.card.rest.config;

import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;

import com.capitalone.api.commons.test.categories.UnitTest;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class SpringConfigTest {
	
    @InjectMocks
    private SpringConfig config;
    private static final int MESSAGE_SOURCE_RELOAD_CACHE = 7200;
    
    @Mock
    private org.apache.commons.configuration.Configuration epfApplicationConfigUtil;

    private static final String DEFAULT_STRING = "DEFAULT";

    @Test
    public void testMessageSource() {
        Mockito.when(epfApplicationConfigUtil.getString("error.messages.basename")).thenReturn(DEFAULT_STRING);
        Mockito.when(epfApplicationConfigUtil.getString("internal.error.messages.basename")).thenReturn(DEFAULT_STRING);
        MessageSource messageSource = config.messageSource(MESSAGE_SOURCE_RELOAD_CACHE, DEFAULT_STRING);
        MatcherAssert.assertThat(messageSource, Matchers.notNullValue());
    }

    @Test
    public void testValidationMessages() {
        Mockito.when(epfApplicationConfigUtil.getString("validation.messages.basename")).thenReturn(DEFAULT_STRING);
        MessageSource messageSource = config.validationMessages(MESSAGE_SOURCE_RELOAD_CACHE, DEFAULT_STRING);
        MatcherAssert.assertThat(messageSource, Matchers.notNullValue());
    }
}