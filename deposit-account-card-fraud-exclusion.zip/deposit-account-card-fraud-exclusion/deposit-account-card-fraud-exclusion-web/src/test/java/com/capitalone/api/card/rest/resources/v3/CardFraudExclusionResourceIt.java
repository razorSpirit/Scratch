package com.capitalone.api.card.rest.resources.v3;

//import static com.jayway.restassured.RestAssured.expect;
import static com.jayway.restassured.RestAssured.given;
import static junit.framework.Assert.assertNotNull;

import org.junit.ClassRule;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runners.MethodSorters;

import com.capitalone.api.card.model.v3.FraudExclusionFormParams;
import com.capitalone.api.commons.itest.ApiRestClassRule;
import com.capitalone.api.commons.test.categories.IntegrationTest;
import com.capitalone.api.model.id.ReferenceId;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;

/**
 * Integration test class.  Note, none of these tests will work in isolation as they
 * expect data from the "save" to transpire first.
 * 
 * @author svo905
 * @since 1.0
 */
@Category(IntegrationTest.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CardFraudExclusionResourceIt {
	 private final static String ACCOUNT_REF_ID = "KvzryT4%2FT9ZqX2DMRY0jw%2FygNQ8bv11u%2FOP8lJobC6xgBmWnVovwJAClv1wDxQPD";
	 private final static String CARD_REF_ID = "KvzryT4%2FT9ZqX2DMRY0jw%2FygNQ8bv11u%2FOP8lJobC6zPzyeKKSxfnAoq5EQfqQTM2MLzk5sC5JOQnv0bcDIj%2FfeoUvTQ8lftyWiQ7y%2Bp3mE%3D";
	 private final static String JSON_APPLICATION = "application/json; v=3";
	 private final static String API_KEY = "MOBILE";
	 private final static String USER = "221655";
	 private final static String INTERACTION_ID = "590680271504594";
	 private final static String START_DATE = "2015-06-25";
	 private final static String END_DATE = "2015-06-27";
	 private final static String NOTE = "Italy here I come!";
	 private final static String CARD_ACTION_CODE = "TravelNotification";
	 
    @ClassRule
    public static ApiRestClassRule apiRule = new ApiRestClassRule("/deposit-account-card-fraud-exclusion-web//deposit/accounts/{accountReferenceId}/bank-cards/{cardReferenceId}/fraud-exclusion");

    @Test
    public void addFraudExclusionTestForRequest() {
   	 FraudExclusionFormParams formParams = new FraudExclusionFormParams();
   	 formParams.setCardActionCode(CARD_ACTION_CODE);
   	 formParams.setExclusionEndDate(END_DATE);
   	 formParams.setExclusionStartDate(START_DATE);
   	 formParams.setServicingNotes(NOTE);
   	 formParams.setIsEmailResponseRequired(true);  	 

        final String URI = "/deposit/accounts/"+ACCOUNT_REF_ID+"/bank-cards/"+CARD_REF_ID+"/fraud-exclusion";
        //standaloneSetup(CardFraudExclusionResource.class).     
        Response response = 
        given().
            contentType(JSON_APPLICATION).
            header("Accept", JSON_APPLICATION).
            header("Api-Key", API_KEY).
            header("Client-Correlation-Id", INTERACTION_ID).
            header("User-Id", USER).         
            body(formParams).
        when().
            put(URI).
        then().
            statusCode(204).
            contentType(ContentType.JSON).
        extract().
            response();

        assertNotNull(response);
    }    
}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
