package com.capitalone.api.card.rest.config;

/**
 * Spring and Jersey configuration classes for deposit-account-card-fraud-exclusion functionality.
 */