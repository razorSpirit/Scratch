package com.capitalone.api.card.rest.resources.v3;

/**
 * Exposed REST resources for deposit-account-card-fraud-exclusion functionality.
 */