package com.capitalone.api.card.rest.resources.v3;

import java.net.HttpURLConnection;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.inject.Named;
import javax.validation.Valid;
import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.server.JSONP;
import org.springframework.beans.BeanUtils;

import com.capitalone.api.card.model.v3.FraudExclusionFormParams;
import com.capitalone.api.card.model.v3.FraudExclusionHeaderParams;
import com.capitalone.api.card.model.v3.FraudExclusionPathParams;
import com.capitalone.api.card.model.v3.FraudExclusionRequest;
import com.capitalone.api.card.model.v3.FraudExclusionRetrievalRequest;
import com.capitalone.api.card.model.v3.FraudExclusionRetrievalResponse;
import com.capitalone.api.card.service.api.CardFraudExclusionService;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.model.EntityRequest;
import com.capitalone.api.commons.model.error.ErrorResponse;
import com.capitalone.api.commons.security.ApiSecurityContext;
import com.capitalone.api.commons.web.resource.AbstractBaseResource;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * Card Fraud Exclusion API
 * 
 * @author svo905
 * @since 1.0
 */

@Named
@Trace
@Path("/deposits/accounts/{accountReferenceId}/bank-cards/{cardReferenceId}")
@Api(value = "/deposits/accounts/{accountReferenceId}/bank-cards/{cardReferenceId}/fraud-exclusion", description = "Fraud Exclusion Operations")
@Produces({"application/vnd.com.capitalone.api+v3+json", "application/vnd.com.capitalone.api+v3+xml",
        "application/vnd.com.capitalone.api+v3+javascript", "application/javascript", MediaType.APPLICATION_JSON,
        MediaType.APPLICATION_XML})
@Consumes({"application/vnd.com.capitalone.api+v3+json", "application/vnd.com.capitalone.api+v3+xml",
        MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
public class CardFraudExclusionResource extends AbstractBaseResource {

    @Inject
    @Named("cardFraudExclusionService")
    private CardFraudExclusionService cardFraudExclusionService;

    private static final String BODY_VALUE = "{ \n\"exclusionStartDate\":\"2016-02-12\",\n\"exclusionEndDate\":\"2016-02-13\",\n\"servicingNotes\":\"Put note here\",\n\"cardActionCode\":\"AntiFraudServicing\",\n\"emailIndicator\":\"true\"\n}";

    /**
     * Create FraudExclusion dates and note.
     * 
     * @param entityRequest Standard {@link EntityRequest}
     * @param fraudExclusionPathParams {@link FraudExclusionPathParams}
     * @param fraudExclusionFormParams {@link FraudExclusionFormParams}
     */
    @PUT
    @Path("/fraud-exclusion")
    @JSONP(queryParam = JSONP.DEFAULT_QUERY)
    @ApiOperation(value = "Create FraudExclusion dates and note", notes = "Create FraudExclusion dates and note in the vendors system real time.")
    @ApiResponses({
            @ApiResponse(code = HttpURLConnection.HTTP_CREATED, message = "The server has fulfilled the request but does not need to return an entity-body."),
            @ApiResponse(code = HttpURLConnection.HTTP_BAD_REQUEST, message = "Bad Request: The request could not be understood by the server due to malformed syntax. The client SHOULD NOT repeat the request without modifications.", response = ErrorResponse.class),
            @ApiResponse(code = HttpURLConnection.HTTP_FORBIDDEN, message = "FORBIDDEN. The client is not authorized to perform the requested operation.", response = ErrorResponse.class),
            @ApiResponse(code = HttpURLConnection.HTTP_NOT_FOUND, message = "Not Found: The server has not found anything matching the Request-URI. No indication is given of whether the condition is temporary or permanent. The 410 (Gone) status code SHOULD be used if the server knows, through some internally configurable mechanism, that an old resource is permanently unavailable and has no forwarding address. This status code is commonly used when the server does not wish to reveal exactly why the request has been refused, or when no other response is applicable.", response = ErrorResponse.class),
            @ApiResponse(code = HttpURLConnection.HTTP_INTERNAL_ERROR, message = "Internal Server Error: The server encountered an unexpected condition which prevented it from fulfilling the request.", response = ErrorResponse.class)})
    @RolesAllowed({ApiSecurityContext.CLIENT_ROLE, ApiSecurityContext.USER_ROLE})
    public void addFraudExclusion(
            @BeanParam FraudExclusionHeaderParams fraudExclusionHeaderParams,
            @BeanParam FraudExclusionPathParams fraudExclusionPathParams,
            @ApiParam(value = "The exclusion dates and note to be created.", required = true, defaultValue = BODY_VALUE) @Valid FraudExclusionFormParams fraudExclusionFormParams) {

        logPathParams(fraudExclusionPathParams);

        FraudExclusionRequest request = new FraudExclusionRequest();
        BeanUtils.copyProperties(fraudExclusionPathParams, request);
        BeanUtils.copyProperties(fraudExclusionFormParams, request);

        EntityRequest entityRequest = new EntityRequest();
        BeanUtils.copyProperties(fraudExclusionHeaderParams, entityRequest);

        logEntityRequest(entityRequest);

        cardFraudExclusionService.create(request, entityRequest);
    }

    /**
     * Retrieve Fraud Exclusion dates and notes in 3 possible formats : ALL, LATEST, HISTORY
     * 
     * @param entityRequest Standard {@link EntityRequest}
     * @param fraudExclusionPathParams {@link FraudExclusionPathParams}
     * @param fraudExclusionFormParams {@link FraudExclusionFormParams}
     */
    @GET
    @Path("/fraud-exclusion")
    @JSONP(queryParam = JSONP.DEFAULT_QUERY)
    @ApiOperation(value = "Retrieve Fraud Exclusion dates and notes.", notes = "3 possible formats : ALL, LATEST, HISTORY")
    @ApiResponses({
            @ApiResponse(code = HttpURLConnection.HTTP_BAD_REQUEST, message = "Bad Request: The request could not be understood by the server due to malformed syntax. The client SHOULD NOT repeat the request without modifications.", response = ErrorResponse.class),
            @ApiResponse(code = HttpURLConnection.HTTP_FORBIDDEN, message = "FORBIDDEN. The client is not authorized to perform the requested operation.", response = ErrorResponse.class),
            @ApiResponse(code = HttpURLConnection.HTTP_NOT_FOUND, message = "Not Found: The server has not found anything matching the Request-URI. No indication is given of whether the condition is temporary or permanent. The 410 (Gone) status code SHOULD be used if the server knows, through some internally configurable mechanism, that an old resource is permanently unavailable and has no forwarding address. This status code is commonly used when the server does not wish to reveal exactly why the request has been refused, or when no other response is applicable.", response = ErrorResponse.class),
            @ApiResponse(code = HttpURLConnection.HTTP_INTERNAL_ERROR, message = "Internal Server Error: The server encountered an unexpected condition which prevented it from fulfilling the request.", response = ErrorResponse.class)})
    @RolesAllowed({ApiSecurityContext.CLIENT_ROLE, ApiSecurityContext.USER_ROLE})
    public FraudExclusionRetrievalResponse getFraudExclusion(
            @BeanParam FraudExclusionHeaderParams fraudExclusionHeaderParams,
            @BeanParam FraudExclusionPathParams fraudExclusionPathParams) {
        logPathParams(fraudExclusionPathParams);

        FraudExclusionRetrievalRequest request = new FraudExclusionRetrievalRequest();
        BeanUtils.copyProperties(fraudExclusionPathParams, request);

        EntityRequest entityRequest = new EntityRequest();
        BeanUtils.copyProperties(fraudExclusionHeaderParams, entityRequest);

        logEntityRequest(entityRequest);

        return cardFraudExclusionService.retrieve(request, entityRequest);
    }

    protected void logPathParams(FraudExclusionPathParams fraudExclusionPathParams) {
        logger.debug("accountId:{}, cardLastFour:{}" + fraudExclusionPathParams.getAccountReferenceId().getAccountId(),
                fraudExclusionPathParams.getCardReferenceId().getLastFour());
    }

    protected void logEntityRequest(EntityRequest entityRequest) {
        String interactionId = entityRequest.getClientCorrelationId();
        String apiKey = entityRequest.getApiKey();
        String userId = entityRequest.getUserId();

        logger.debug("apiKey:{}, userId:{}, interactionId:{}", apiKey, userId, interactionId);

    }
}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
