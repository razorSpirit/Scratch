package com.capitalone.api.card.service.util.errors;

import static com.capitalone.api.card.service.constants.ErrorConstants.METAVANTE_ERROR_CODE;

import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.capitalone.api.bank.lib.metavante.model.AddnStat;
import com.capitalone.api.bank.lib.metavante.model.StatType;
import com.capitalone.api.card.service.exceptions.PartialApiException;
import com.capitalone.api.commons.exception.ApiErrorCode;
import com.capitalone.api.commons.exception.ApiSystemException;
import com.capitalone.api.commons.exception.RequestValidationException;

public class ErrorHandler {

	public static final String BLANK = "";

	public static void throwApiSystemException(String errorCode, String msgId, String developerText) {
		throw new ApiSystemException(buildApiErrorCode(errorCode, msgId, developerText));
	}

	public static void throwApiSystemException(String msgId, String developerText) {
		throw new ApiSystemException(buildApiErrorCode(msgId, msgId, developerText));
	}

	public static void throwRequestValidationException(String errorCode, String msgId, String developerText) {
		throw new RequestValidationException(buildApiErrorCode(errorCode, msgId, developerText));
	}

	public static void throwRequestValidationException(String msgId, String developerText) {
		throw new RequestValidationException(buildApiErrorCode(msgId, msgId, developerText));
	}

	public static void throwApiSystemException(String developerText, StatType statType) {
		throw createApiSystemException(developerText, statType);
	}

	public static ApiSystemException createApiSystemException(String developerText, StatType statType) {
		ApiErrorCode error = buildApiErrorCode(METAVANTE_ERROR_CODE, METAVANTE_ERROR_CODE, developerText);

		if (statType != null) {
			error.getErrorDetails()
					.add(buildApiErrorCode(BLANK + statType.getStatCd(), METAVANTE_ERROR_CODE, statType.getStatDesc()));
			List<AddnStat> addnStats = statType.getAddnStat();
			for (AddnStat addnStat : addnStats) {
				error.getErrorDetails().add(buildApiErrorCode(BLANK + addnStat.getNativeErrorCd(), METAVANTE_ERROR_CODE,
						addnStat.getStatDesc()));
			}
		}

		return new ApiSystemException(error);
	}

	public static void throwPartialSuccessException(String developerText, StatType statType) {
		ApiErrorCode error = buildApiErrorCode(METAVANTE_ERROR_CODE, METAVANTE_ERROR_CODE, developerText);

		if (null != statType) {
			error.getErrorDetails()
					.add(buildApiErrorCode(BLANK + statType.getStatCd(), METAVANTE_ERROR_CODE, statType.getStatDesc()));
			List<AddnStat> addnStats = statType.getAddnStat();
			for (AddnStat addnStat : addnStats) {
				error.getErrorDetails().add(buildApiErrorCode(BLANK + addnStat.getNativeErrorCd(), METAVANTE_ERROR_CODE,
						addnStat.getStatDesc()));
			}
		}

		throw new PartialApiException(error);
	}

	public static ApiErrorCode buildApiErrorCode(String errorCode, String msgId, String developerText) {
		ApiErrorCode error = new ApiErrorCode(errorCode, msgId);
		if (StringUtils.isNotEmpty(developerText)) {
			error.setDeveloperText(developerText);
		}
		return error;
	}

}