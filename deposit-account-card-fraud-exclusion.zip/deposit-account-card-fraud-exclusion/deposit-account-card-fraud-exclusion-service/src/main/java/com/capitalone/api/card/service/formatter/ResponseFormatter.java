package com.capitalone.api.card.service.formatter;

import javax.inject.Named;

import com.capitalone.api.card.model.v3.FraudExclusionRetrievalResponse;
import com.capitalone.api.card.model.v3.ServicingNoteFormat;
import com.capitalone.api.card.service.dto.ParsedDatesAndNotes;

@Named
public class ResponseFormatter {

    public FraudExclusionRetrievalResponse format(ParsedDatesAndNotes parsedDatesAndNotes, ServicingNoteFormat format) {

        switch (format) {
            case ALL:
            	return returnFormatterAll(parsedDatesAndNotes);
            case LATEST:
            	return returnFormatterLatest(parsedDatesAndNotes);
            case HISTORY:
            	return returnFormatterHistory(parsedDatesAndNotes);
            case NONOTIFICATIONS:
            	return returnNoNotifications();
            default:
                return null;
        }

    }

	private FraudExclusionRetrievalResponse returnNoNotifications() {
		FraudExclusionRetrievalResponse response = new FraudExclusionRetrievalResponse();
		response.setServicingNoteFormat(ServicingNoteFormat.NONOTIFICATIONS);
		return response;
	}

	private FraudExclusionRetrievalResponse returnFormatterHistory(ParsedDatesAndNotes parsedDatesAndNotes) {
		ResponseFormatterHistory responseFormatterHistory = new ResponseFormatterHistory();
		return responseFormatterHistory.format(parsedDatesAndNotes);
	}

	private FraudExclusionRetrievalResponse returnFormatterLatest(ParsedDatesAndNotes parsedDatesAndNotes) {
		ResponseFormatterLatest responseFormatterLatest = new ResponseFormatterLatest();
		return responseFormatterLatest.format(parsedDatesAndNotes);
	}

	private FraudExclusionRetrievalResponse returnFormatterAll(ParsedDatesAndNotes parsedDatesAndNotes) {
		ResponseFormatterAll responseFormatterAll = new ResponseFormatterAll();
		return responseFormatterAll.format(parsedDatesAndNotes);
	}

}
