/**
 * Request converters for the deposit-account-card-fraud-exclusion functionality.
 */
package com.capitalone.api.card.service.convert.request;