package com.capitalone.api.card.service.dto;

public class ParsedNote {
	private int lineNumber;
	private String noteCardActionType;
	private String noteStartDate;
	private String noteEndDate;
	private String note;
	private String originalNote;

	public int getLineNumber() {
		return lineNumber;
	}

	public void setLineNumber(int lineNumber) {
		this.lineNumber = lineNumber;
	}

	public String getNoteCardActionType() {
		return noteCardActionType;
	}

	public void setNoteCardActionType(String noteCardActionType) {
		this.noteCardActionType = noteCardActionType;
	}

	public String getNoteStartDate() {
		return noteStartDate;
	}

	public void setNoteStartDate(String noteStartDate) {
		this.noteStartDate = noteStartDate;
	}

	public String getNoteEndDate() {
		return noteEndDate;
	}

	public void setNoteEndDate(String noteEndDate) {
		this.noteEndDate = noteEndDate;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public void setOriginalNote(String originalNote) {
		this.originalNote = originalNote;
	}
}