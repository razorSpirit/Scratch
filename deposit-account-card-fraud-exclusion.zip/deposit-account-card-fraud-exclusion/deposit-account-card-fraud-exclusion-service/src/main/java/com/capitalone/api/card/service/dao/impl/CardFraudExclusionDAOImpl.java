package com.capitalone.api.card.service.dao.impl;

import static com.capitalone.api.card.service.constants.ErrorConstants.DEV_TXT_DATES_FAILED;
import static com.capitalone.api.card.service.constants.ErrorConstants.DEV_TXT_DATE_ROLLBACK;
import static com.capitalone.api.card.service.constants.ErrorConstants.DEV_TXT_GET_DATES_FAILED;
import static com.capitalone.api.card.service.constants.ErrorConstants.DEV_TXT_GET_NOTES_FAILED;
import static com.capitalone.api.card.service.constants.ErrorConstants.DEV_TXT_NOTE_FAILED;
import static com.capitalone.api.card.service.constants.ErrorConstants.DEV_TXT_VENDOR_HEALTH_FAILED;
import static com.capitalone.api.card.service.constants.ErrorConstants.UNEXPECTED_ERROR;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.bank.lib.metavante.dao.MetavanteDAO;
import com.capitalone.api.bank.lib.metavante.model.AcctInqRequest;
import com.capitalone.api.bank.lib.metavante.model.AcctInqResponse;
import com.capitalone.api.bank.lib.metavante.model.AddnStat;
import com.capitalone.api.bank.lib.metavante.model.ArrayOfCardNumbers;
import com.capitalone.api.bank.lib.metavante.model.FraudExclusionDatesRequest;
import com.capitalone.api.bank.lib.metavante.model.FraudExclusionDatesResponse;
import com.capitalone.api.bank.lib.metavante.model.NotesRequest;
import com.capitalone.api.bank.lib.metavante.model.NotesResponse;
import com.capitalone.api.bank.lib.metavante.model.SearchCardsRequest;
import com.capitalone.api.bank.lib.metavante.model.SearchCardsResponse;
import com.capitalone.api.bank.lib.metavante.model.StatType;
import com.capitalone.api.card.service.constants.ServiceConstants;
import com.capitalone.api.card.service.dao.CardFraudExclusionDAO;
import com.capitalone.api.card.service.util.errors.ErrorHandler;

@Named("CardFraudExclusionDAO")
public class CardFraudExclusionDAOImpl implements CardFraudExclusionDAO {

    private static final String EMPTY_STRING = "";

    private static final String UNEXPECTED_EXCEPTION = "Unexpected Exception {}";

    @Inject
    private MetavanteDAO metavanteDAO;

    private static final Logger LOGGER = LoggerFactory.getLogger(CardFraudExclusionDAOImpl.class);

    @Override
    public void addDates(String cardNumber, String startDate, String endDate) {
        FraudExclusionDatesResponse response = null;
        StatType statType = null;

        FraudExclusionDatesRequest request = new FraudExclusionDatesRequest();
        request.setCardNumber(cardNumber);
        request.setStartDate(startDate);
        request.setEndDate(endDate);

        try {
            response = metavanteDAO.addFraudExclusionDates(request);
            statType = response.getStatType();
        } catch (Exception exception) {
            statType = new StatType();
            statType.setStatCd(UNEXPECTED_ERROR);
            statType.setStatDesc(exception.getMessage());

            LOGGER.error(UNEXPECTED_EXCEPTION, exception);

        }

        if (!wasMetavanteCallSuccess(statType)) {

            LOGGER.error("adding of dates failed");
            ErrorHandler.throwApiSystemException(DEV_TXT_DATES_FAILED, statType);
        }

    }

    @Override
    public void addNote(String cardNumber, String startDate, String endDate, String note) {
        NotesResponse response = null;
        StatType statType = null;

        NotesRequest request = new NotesRequest();
        request.setCardNumber(cardNumber);
        request.setNote(note);

        try {
            response = metavanteDAO.addNote(request);
            statType = response.getStatType();
        } catch (Exception exception) {
            statType = new StatType();
            statType.setStatCd(UNEXPECTED_ERROR);
            statType.setStatDesc(exception.getMessage());

            LOGGER.error(UNEXPECTED_EXCEPTION, exception);

        }

        if (!wasMetavanteCallSuccess(statType)) {
            rollBackDates(cardNumber, startDate, endDate);
            LOGGER.error("adding note failed but rollback of dates was successful");
            ErrorHandler.throwApiSystemException(DEV_TXT_NOTE_FAILED, statType);
        }

    }

    protected void rollBackDates(String cardNumber, String cardActionCode, String note) {
        StatType statType = removeDates(cardNumber, cardActionCode, note);
        if (!wasMetavanteCallSuccess(statType)) {
            LOGGER.error("rollback failed, service completed with partial success (dates are added but note failed)");
            ErrorHandler.throwPartialSuccessException(DEV_TXT_DATE_ROLLBACK, statType);
        }
    }

    protected StatType removeDates(String cardNumber, String startDate, String endDate) {
        FraudExclusionDatesResponse response = null;
        StatType statType = null;

        FraudExclusionDatesRequest request = new FraudExclusionDatesRequest();
        request.setCardNumber(cardNumber);
        request.setStartDate(startDate);
        request.setEndDate(endDate);

        try {
            response = metavanteDAO.deleteFraudExclusionDates(request);
            statType = response.getStatType();
        } catch (Exception exception) {
            statType = new StatType();
            statType.setStatCd(UNEXPECTED_ERROR);
            statType.setStatDesc(exception.getMessage());

            LOGGER.error(UNEXPECTED_EXCEPTION, exception);
        }
        return statType;
    }

    @Override
    public SearchCardsResponse findCardsByAccountNumber(String accountNumber) {
        SearchCardsRequest searchCardsRq = new SearchCardsRequest();
        searchCardsRq.setAccountNumber(accountNumber);
        SearchCardsResponse response = null;

        response = metavanteDAO.searchCards(searchCardsRq);

        return response;
    }

    @Override
    public AcctInqResponse lookUpAccountByCardNumber(String cardNumber) {
        AcctInqRequest request = new AcctInqRequest();
        request.setCardNumber(cardNumber);

        AcctInqResponse response = null;
        StatType statType = null;

        try {
            response = metavanteDAO.accountInq(request);
            statType = response.getStat();
        } catch (Exception exception) {
            statType = new StatType();
            statType.setStatCd(UNEXPECTED_ERROR);
            statType.setStatDesc(exception.getMessage());

            LOGGER.error(UNEXPECTED_EXCEPTION, exception);
        }
        if (!wasMetavanteCallSuccess(statType)) {
            LOGGER.error("The lookupAccountByCardNumber was unsuccessful.");
            ErrorHandler.throwApiSystemException("lookUpAccountByCardNumber 1", statType);
        }
        return response;
    }

    protected boolean wasMetavanteCallSuccess(StatType statType) {
        return (null != statType && statType.getStatCd() == 0) ? true : false;
    }

    @Override
    public void isHealthy() {
        if (!metavanteDAO.isHealthy()) {
            LOGGER.error("Metavante health check failed.");
            ErrorHandler.throwApiSystemException(DEV_TXT_VENDOR_HEALTH_FAILED, "isHealthy 1", null);
        }
    }

    @Override
    public ArrayOfCardNumbers findCard(String accountNumber, String firstSixOfCard, String lastFourOfCard) {
        StatType statType = null;
        SearchCardsResponse response = null;
        try {
            response = findCardsByAccountNumber(accountNumber);
            statType = response.getStat();
        } catch (Exception exception) {
            statType = new StatType();
            statType.setStatCd(UNEXPECTED_ERROR);
            statType.setStatDesc(exception.getMessage());

            LOGGER.error(UNEXPECTED_EXCEPTION, exception);
        }

        if (!wasMetavanteCallSuccess(statType)) {
            LOGGER.error("findCard() completed with an exception.");
            ErrorHandler.throwApiSystemException("findCard 1", statType);
        }
        if(null!=response) {
            List<ArrayOfCardNumbers> cards = response.getArrayOfCardNumbers();

            for (ArrayOfCardNumbers card : cards) {
                String cardNumber = card.getCardNumber();
                if (firstSixOfCard.equals(firstSixOfCard(cardNumber)) && lastFourOfCard.equals(lastFourOfCard(cardNumber))) {
                    return card;
                }
            }
        }
        return null;
    }

    protected static String firstSixOfCard(String cardNumber) {
        if (StringUtils.isNotBlank(cardNumber) && cardNumber.length() > 10) {
            return cardNumber.substring(0, 6);
        }
        return EMPTY_STRING;
    }

    protected static String lastFourOfCard(String cardNumber) {
        if (StringUtils.isNotBlank(cardNumber) && cardNumber.length() > 10) {
            return cardNumber.substring(cardNumber.length() - 4);
        }
        return EMPTY_STRING;
    }

    @Override
    public FraudExclusionDatesResponse getDates(String cardNumber) {
        FraudExclusionDatesResponse response = null;
        StatType statType = null;
        boolean noDates = false;

        FraudExclusionDatesRequest request = new FraudExclusionDatesRequest();
        request.setCardNumber(cardNumber);
        try {
            response = metavanteDAO.getFraudExclusionDates(request);
            statType = response.getStatType();
            for (AddnStat additionalStat : statType.getAddnStat()) {
                if (StringUtils.equalsIgnoreCase(additionalStat.getStatDesc(),
                        ServiceConstants.DATE_INFORMATION_NOT_FOUND)) {
                    noDates = true;
                    break;
                }
            }
        } catch (Exception exception) {
            statType = new StatType();
            statType.setStatCd(UNEXPECTED_ERROR);
            statType.setStatDesc(exception.getMessage());

            LOGGER.error(UNEXPECTED_EXCEPTION, exception);
        }
        if (!wasMetavanteCallSuccess(statType) && !noDates) {
            LOGGER.error("getDates() completed with an exception.");
            ErrorHandler.throwApiSystemException(DEV_TXT_GET_DATES_FAILED, statType);
        }
        return response;
    }

    @Override
    public NotesResponse getNotes(String cardNumber) {
        NotesResponse response = null;
        StatType statType = null;

        NotesRequest request = new NotesRequest();
        request.setCardNumber(cardNumber);
        try {
            response = metavanteDAO.getNotes(request);
            statType = response.getStatType();
        } catch (Exception exception) {
            statType = new StatType();
            statType.setStatCd(UNEXPECTED_ERROR);
            statType.setStatDesc(exception.getMessage());

            LOGGER.error(UNEXPECTED_EXCEPTION, exception);

        }

        if (!wasMetavanteCallSuccess(statType)) {
            LOGGER.error("getNotes() completed with an exception.");
            ErrorHandler.throwApiSystemException(DEV_TXT_GET_NOTES_FAILED, statType);
        }
        return response;
    }
}
