package com.capitalone.api.card.service.util.validation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import com.capitalone.api.commons.exception.RequestValidationException;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateMidnight;
import org.joda.time.DateTime;
import org.joda.time.Period;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.bank.lib.metavante.model.AcctInqResponse;
import com.capitalone.api.bank.lib.metavante.model.ArrayOfCardNumbers;
import com.capitalone.api.bank.lib.profile.accounts.dao.ProfileAccountsDAO;
import com.capitalone.api.bank.lib.profile.accounts.dao.model.CardData;
import com.capitalone.api.card.model.v3.CardActionType;
import com.capitalone.api.card.model.v3.FraudExclusionRequest;
import com.capitalone.api.card.model.v3.FraudExclusionRetrievalRequest;
import com.capitalone.api.card.model.v3.ServicingNoteFormat;
import com.capitalone.api.card.service.constants.ErrorConstants;
import com.capitalone.api.card.service.dao.CardFraudExclusionDAO;
import com.capitalone.api.card.service.dto.Card;
import com.capitalone.api.card.service.util.errors.ErrorHandler;
import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.model.EntityRequest;
import com.capitalone.api.model.id.AccountReferenceId;
import com.capitalone.api.model.id.CardReferenceId;

@Profile
@Trace
@Named
public class CardFraudExclusionValidator {

    private static final Logger LOG = LoggerFactory.getLogger(CardFraudExclusionValidator.class);

    protected static final String REGEX_NUMERIC = "[-+]?\\d*\\.?\\d+";

    protected static final String REGEX_DATE_FORMAT = "([0-9]{4})-([0-9]{2})-([0-9]{2})";

    protected static final int VALID_DATE_DIFF_IN_YEARS = 1;

    protected static final int VALID_NOTE_LENGTH = 50;

    protected static final String METAVANTE_CARD_ACTIVE_STATUS_CODE = "1";

    protected static final String PROFILE_CARD_ENABLED_STATUS_CODE = "1";

    protected static final String PROFILE_CARD_ACTIVATABLE_STATUS_CODE = "2";

    @Inject
    private CardFraudExclusionDAO cardFraudExclusionDAO;

    @Inject
    private ProfileAccountsDAO profileAccountsDAO;

    private SimpleDateFormat fraudDateFormat = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * Validate the request for valid non empty account reference id and image reference id and for its proper format.
     * Validates the account reference id for valid account number and sorID.
     * 
     */
    public Card validateAndRetrieveCard(FraudExclusionRequest request, EntityRequest entityRequest) {
        validateEntityRequest(entityRequest);
        validateFormParams(request);
        return validatePathParams(request.getAccountReferenceId(), request.getCardReferenceId(), true);
    }

    public Card validateAndRetrieveCard(FraudExclusionRetrievalRequest request, EntityRequest entityRequest) {
        validateEntityRequest(entityRequest);
        validateGetRequest(request);
        return validatePathParams(request.getAccountReferenceId(), request.getCardReferenceId(), false);
    }

    protected void validateEntityRequest(EntityRequest entityRequest) {
        String userId = entityRequest.getUserId();
        if (StringUtils.isBlank(userId)) {
            LOG.error("The User-Id is blank.");
            ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_USER_ID_BLANK,
                    "validateEntityRequest 1");
        }
    }

    protected void validateFormParams(FraudExclusionRequest request) {
        validateCardActionCode(request.getCardActionCode());
        validateFraudExclusionDates(request.getExclusionStartDate(), request.getExclusionEndDate(),
                request.getCardActionType());
        validateNote(request.getServicingNotes());
    }

    protected Card validatePathParams(AccountReferenceId accountRefId, CardReferenceId cardRefId,
            boolean isPathParmsForPut) {

        String sorId = accountRefId.getSystemOfRecordId();
        String accountId = accountRefId.getAccountId();
        validateAccountReferenceId(sorId, accountId);

        String crdSorId = cardRefId.getSystemOfRecordId();
        String crdAccId = cardRefId.getAccountId();
        String crdFirstSix = cardRefId.getFirstSix();
        String crdLastFour = cardRefId.getLastFour();
        validateCardReferenceId(crdSorId, crdAccId, crdFirstSix, crdLastFour);

        return validateCard(cardRefId, isPathParmsForPut);
    }

    protected void validateGetRequest(FraudExclusionRetrievalRequest request) {
        ServicingNoteFormat format = request.getServicingNotesFormat();
        if (format.equals(ServicingNoteFormat.NONE) || format.equals(ServicingNoteFormat.NONOTIFICATIONS)) {
            LOG.error("The ServicingNoteFormat is invalid");
            ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_SERVICING_NOTE_FORMAT_ID_INVALID,
                    "validateGetRequest 1");
        }
    }

    /**
     * Validate Account Reference Id
     */
    protected void validateAccountReferenceId(String sorId, String accountId) {

        if (StringUtils.isBlank(accountId) || !accountId.matches(REGEX_NUMERIC)) {
            LOG.error("The Account Id is invalid");
            ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_ACCOUNT_ID_INVALID,
                    "validateAccountReferenceId 1");
        }
        if (StringUtils.isBlank(sorId) || !sorId.matches(REGEX_NUMERIC)) {
            LOG.error("The Source Id is invalid");
            ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_SOURCE_ID_INVALID,
                    "validateAccountReferenceId 2");
        }
    }

    /**
     * Validate Card Reference Id
     */
    protected void validateCardReferenceId(String sorId, String accountId, String firstSix, String lastFour) {

        if (StringUtils.isBlank(accountId) || !accountId.matches(REGEX_NUMERIC)) {
            LOG.error("The Account Id is invalid");
            ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_ACCOUNT_ID_INVALID,
                    "validateCardReferenceId 1");
        }
        if (StringUtils.isBlank(sorId) || !sorId.matches(REGEX_NUMERIC)) {
            LOG.error("The Source Id is invalid");
            ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_SOURCE_ID_INVALID,
                    "validateCardReferenceId 2");
        }
        if (StringUtils.isBlank(firstSix) || !firstSix.matches(REGEX_NUMERIC)) {
            LOG.error("The first six digits of card are invalid");
            ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_CARD_FIRST6_INVALID,
                    "validateCardReferenceId 3");
        }
        if (StringUtils.isBlank(lastFour) || !lastFour.matches(REGEX_NUMERIC)) {
            LOG.error("The last four digits of card are invalid");
            ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_CARD_LAST4_INVALID,
                    "validateCardReferenceId 4");
        }

    }

    /**
     * Validate Fraud Exclusion Dates
     */
    protected void validateFraudExclusionDates(String fromDate, String toDate, CardActionType cardActionType) {

        validateBasic(fromDate, toDate);
        try {
            Date fromDt = fraudDateFormat.parse(fromDate);
            Date toDt = fraudDateFormat.parse(toDate);

            DateMidnight currdateMidnight = new DateMidnight();

            DateTime dateTimeFrom = new DateTime(fromDt);
            DateTime dateTimeTo = new DateTime(toDt);

            validateDates(cardActionType, currdateMidnight, dateTimeFrom, dateTimeTo);

        } catch (ParseException pe) {
            LOG.error("The Exclusion Dates are invalid");
            ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_XCLU_DT_INVALID,
                    "validateFraudExclusionDates 9");
        }

    }

	private void validateDates(CardActionType cardActionType, DateMidnight currdateMidnight, DateTime dateTimeFrom,
			DateTime dateTimeTo) {
		if (dateTimeFrom.isBefore(currdateMidnight)) {
		    LOG.error("From Date is in the past");
		    ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_FROM_DT_PAST,
		            "validateFraudExclusionDates 5");
		}

		if (dateTimeTo.isBefore(currdateMidnight)) {
		    LOG.error("To Date is in the past");
		    ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_TO_DT_PAST,
		            "validateFraudExclusionDates 6");
		}

		if (dateTimeTo.isBefore(dateTimeFrom)) {
		    LOG.error("To Date is before the From Date");
		    ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_TO_DT_BEFORE,
		            "validateFraudExclusionDates 7");
		}
		if (cardActionType.equals(CardActionType.TRAVEL_NOTIFICATION)) {
		    Period periodDifference = new Period(dateTimeFrom, dateTimeTo);
		    if (periodDifference.getYears() >= VALID_DATE_DIFF_IN_YEARS) {
		        LOG.error("To date is more than one year from From Date");
		        ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_TO_DT_AFTER,
		                "validateFraudExclusionDates 8");
		    }
		}
	}

	private void validateBasic(String fromDate, String toDate) {
		if (StringUtils.isBlank(fromDate)) {
            LOG.error("The Exclusion From Date is blank");
            ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_FROM_DT_BLANK,
                    "validateFraudExclusionDates 1");
        }
        if (!fromDate.matches(REGEX_DATE_FORMAT)) {
            LOG.error("The Exclusion From Date format is invalid");
            ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_FROM_DT_FORMAT_INVALID,
                    "validateFraudExclusionDates 2");
        }
        if (StringUtils.isBlank(toDate)) {
            LOG.error("The Exclusion To Date is blank");
            ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_TO_DT_BLANK,
                    "validateFraudExclusionDates 3");
        }
        if (!toDate.matches(REGEX_DATE_FORMAT)) {
            LOG.error("The Exclusion To Date format is invalid");
            ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_TO_DT_FORMAT_INVALID,
                    "validateFraudExclusionDates 4");
        }
	}

    /**
     * Validate Note
     */
    protected void validateNote(String note) {

        if (StringUtils.isBlank(note)) {
            LOG.error("Note cannot be blank");
            ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_NOTE_BLANK, "validateNote 1");
        }
        if (note.length() > VALID_NOTE_LENGTH) {
            LOG.error("Note cannot be more than " + VALID_NOTE_LENGTH + " characters");
            ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_NOTE_INVALID_LEN, "validateNote 2");
        }
    }

    /**
     * Validate Card Action Code
     */
    protected void validateCardActionCode(String cardActionCode) {

        if (StringUtils.isBlank(cardActionCode)) {
            LOG.error("Exclusion Type cannot be blank");
            ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_EXCLU_TYPE_BLANK,
                    ErrorConstants.ERR_MSG_ID_EXCLU_TYPE_BLANK, "validateCardActionCode 1");
        }

        CardActionType cardActionType = CardActionType.valueFor(cardActionCode);

        if (cardActionType.equals(CardActionType.NONE)) {
            LOG.error("Exclusion Type is invalid");
            ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_EXCLU_TYPE_INVALID,
                    ErrorConstants.ERR_MSG_ID_EXCLU_TYPE_INVALID, "validateCardActionCode 2");
        }

    }

    protected Card validateCard(CardReferenceId cardReferenceId, boolean isValidatingStatus) {

        String accountNumber = cardReferenceId.getAccountId();
        String firstSixOfCard = cardReferenceId.getFirstSix();
        String lastFourOfCard = cardReferenceId.getLastFour();

        Card card = retrieveCard(accountNumber, firstSixOfCard, lastFourOfCard);

        String cardState = card.getProfileState();

        String cardStatus = String.valueOf(card.getMetavanteStatus());

        if (isValidatingStatus) {
            if (!METAVANTE_CARD_ACTIVE_STATUS_CODE.equals(cardStatus)) {
                LOG.error("The card status is not valid for the invocation of the API, Card not ACTIVE in Metavante");
                ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_CARD_STATUS_INVALID,
                        "validateCard 1 - Card not ACTIVE in Metavante");
            }
            if (!(PROFILE_CARD_ENABLED_STATUS_CODE.equals(cardState)
                    || PROFILE_CARD_ACTIVATABLE_STATUS_CODE.equals(cardState) || null == cardState)) {
                LOG.error("The card status is not valid for the invocation of the API, Card not ENABLED or ACTIVABLE or card status is not available in Profile");
                ErrorHandler.throwRequestValidationException(ErrorConstants.ERR_MSG_ID_CARD_STATUS_INVALID,
                        "validateCard 2 - Card not ENABLED or ACTIVABLE or card status is not available in Profile");
            }
        }

        return card;
    }

    protected Card retrieveCard(String accountNumber, String firstSixOfCard, String lastFourOfCard) {

        Card card = retrieveCardFromMetavante(accountNumber, firstSixOfCard, lastFourOfCard);

        List<CardData> profileCards = profileAccountsDAO.retrieveCardsData(card.getCustomerNumber());

        for (CardData profileCard : profileCards) {
            if (profileCard.getFirst6Digits().equals(firstSixOfCard)
                    && profileCard.getLast4Digits().equals(lastFourOfCard)) {
                card.setProfileState(profileCard.getCardState());
                card.setProfileStatus(profileCard.getMetavanteCardStatus());

                break;
            }
        }

        return card;
    }

    protected Card retrieveCardFromMetavante(String accountNumber, String firstSixOfCard, String lastFourOfCard) {
        ArrayOfCardNumbers metavanteCardData = cardFraudExclusionDAO.findCard(accountNumber, firstSixOfCard,
                lastFourOfCard);
        if (null != metavanteCardData) {
            AcctInqResponse metavanteAccountResponse = cardFraudExclusionDAO.lookUpAccountByCardNumber(metavanteCardData
                    .getCardNumber());
            if (null == metavanteAccountResponse) {
                LOG.error("The lookupAccountByCardNumber was unsuccessful.");
                throw new RequestValidationException(ErrorHandler.buildApiErrorCode(ErrorConstants.ERR_MSG_ID_CARD_NOT_WITH_ACCOUNT,
                        ErrorConstants.ERR_MSG_ID_CARD_NOT_WITH_ACCOUNT, "retrieveCardFromMetavante 2"));
            }

            Card card = new Card();
            card.setCustomerNumber(metavanteAccountResponse.getCustID());
            card.setCardNumber(metavanteCardData.getCardNumber());
            card.setFirstName(metavanteCardData.getFirstName());
            card.setMetavanteStatus(metavanteCardData.getDebitCardStatusCode());
            return card;
        } else {
            LOG.error("Invalid card, it is not associated with the account");
            throw new RequestValidationException(ErrorHandler.buildApiErrorCode(ErrorConstants.ERR_MSG_ID_CARD_NOT_WITH_ACCOUNT,
                    ErrorConstants.ERR_MSG_ID_CARD_NOT_WITH_ACCOUNT, "retrieveCardFromMetavante 1"));
        }
    }

}
