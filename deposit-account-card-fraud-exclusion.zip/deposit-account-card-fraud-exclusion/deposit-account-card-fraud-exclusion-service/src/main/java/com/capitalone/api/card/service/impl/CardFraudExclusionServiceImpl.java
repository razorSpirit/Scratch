package com.capitalone.api.card.service.impl;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;

import com.capitalone.api.bank.commons.db.utils.PingUtil;
import com.capitalone.api.card.model.v3.FraudExclusionRequest;
import com.capitalone.api.card.model.v3.FraudExclusionRetrievalRequest;
import com.capitalone.api.card.model.v3.FraudExclusionRetrievalResponse;
import com.capitalone.api.card.model.v3.ServicingNoteFormat;
import com.capitalone.api.card.service.api.CardFraudExclusionService;
import com.capitalone.api.card.service.dao.CardFraudExclusionDAO;
import com.capitalone.api.card.service.dto.Card;
import com.capitalone.api.card.service.dto.ParsedDatesAndNotes;
import com.capitalone.api.card.service.formatter.ResponseFormatter;
import com.capitalone.api.card.service.util.activities.DatesActivityWriter;
import com.capitalone.api.card.service.util.build.DatesAndNotesBuilder;
import com.capitalone.api.card.service.util.emails.ExclusionEmailSender;
import com.capitalone.api.card.service.util.notes.NoteStamper;
import com.capitalone.api.card.service.util.validation.CardFraudExclusionValidator;
import com.capitalone.api.commons.model.EntityRequest;
import com.capitalone.api.commons.services.base.AbstractBaseService;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.context.model.EPFContextContainer;

@Configuration
@EnableAsync
@Named("cardFraudExclusionService")
public class CardFraudExclusionServiceImpl extends AbstractBaseService implements CardFraudExclusionService {

    private static final String NO_EXCLUSION_DATE_SET = "UNKNOWN";

    @Inject
    private CardFraudExclusionValidator cardFraudExclusionValidator;

    @Inject
    private DatesActivityWriter datesActivityWriter;

    @Inject
    private ExclusionEmailSender exclusionEmail;

    @Inject
    private CardFraudExclusionDAO cardFraudExclusionDAO;

    @Inject
    private PingUtil pingUtil;

    @Inject
    private DatesAndNotesBuilder datesAndNotesBuilder;

    @Inject
    private ResponseFormatter responseFormatter;

    @Override
    public void health() {
        pingUtil.pingProfile();
        cardFraudExclusionDAO.isHealthy();
    }

    @Override
    /**
     *  Creates dates and note in Metavante (CMSE)
     */
    public void create(FraudExclusionRequest request, EntityRequest entityRequest) {
        logger.debug("service started for create");

        Card cardData = cardFraudExclusionValidator.validateAndRetrieveCard(request, entityRequest);

        EPFContext epfContext = EPFContextContainer.getContext();

        if (request.isEmailResponseRequired()) {
            exclusionEmail.async(epfContext, request, entityRequest, cardData.getCustomerNumber());
        }

        cardFraudExclusionDAO.addDates(cardData.getCardNumber(), request.getExclusionStartDate(),
                request.getExclusionEndDate());

        cardFraudExclusionDAO.addNote(cardData.getCardNumber(), request.getExclusionStartDate(),
                request.getExclusionEndDate(), NoteStamper.getStampedNote(request));

        datesActivityWriter.write(epfContext, request, entityRequest, cardData.getCustomerNumber(),
                NoteStamper.getStampedNote(request));

        logger.debug("service completed for create with success");
    }

    @Override
    /**
     * Retrieves dates and notes from Metavante(CMSE)
     */
    public FraudExclusionRetrievalResponse retrieve(FraudExclusionRetrievalRequest request, EntityRequest entityRequest) {

        logger.debug("service started for retrieve");

        Card cardData = cardFraudExclusionValidator.validateAndRetrieveCard(request, entityRequest);

        ParsedDatesAndNotes parsedDatesAndNotes = datesAndNotesBuilder.build(cardData.getCardNumber());

        if (parsedDatesAndNotes == null
                || checkForNoDate(parsedDatesAndNotes)
                || CollectionUtils.isEmpty(parsedDatesAndNotes.getParsedNote())) {
            request.setServicingNotesFormat(ServicingNoteFormat.NONOTIFICATIONS);

        }
        FraudExclusionRetrievalResponse response = responseFormatter.format(parsedDatesAndNotes,
                request.getServicingNotesFormat());

        logger.debug("service completed for retrieve");

        return response;
    }

    /**
     * @param parsedDatesAndNotes
     * @return
     */
    protected boolean checkForNoDate(ParsedDatesAndNotes parsedDatesAndNotes) {
        return (parsedDatesAndNotes.getExclusionStartDate() == null || parsedDatesAndNotes.getExclusionStartDate()
                .equalsIgnoreCase(NO_EXCLUSION_DATE_SET))
        && (parsedDatesAndNotes.getExclusionEndDate() == null || parsedDatesAndNotes.getExclusionEndDate()
                .equalsIgnoreCase(NO_EXCLUSION_DATE_SET));
    }
}