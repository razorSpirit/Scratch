package com.capitalone.api.card.service.util.activities;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.card.model.v3.FraudExclusionRequest;
import com.capitalone.api.commons.model.EntityRequest;
import com.capitalone.epf.context.model.EPFContext;

@Named("DatesActivityWriter")
public class DatesActivityWriter {
    private static final Logger LOGGER = LoggerFactory.getLogger(DatesActivityWriter.class);

    @Inject
    private ExclusionDatesActivity exclusionDatesActivity;

    public void write(EPFContext epfContext, FraudExclusionRequest request, EntityRequest entityRequest,
            String customerNumber, String note) {

        LOGGER.info("started writing activity..with epfContext:" + epfContext.getUserId());
        exclusionDatesActivity.async(epfContext, request, customerNumber, note,
                entityRequest.getClientCorrelationId());
    }

}