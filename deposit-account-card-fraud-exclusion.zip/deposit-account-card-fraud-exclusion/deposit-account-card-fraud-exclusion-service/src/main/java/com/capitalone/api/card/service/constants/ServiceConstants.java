package com.capitalone.api.card.service.constants;

public class ServiceConstants {

    public static final String API_DEFAULT_ERROR_CODE = "999999";

    public static final int API_BAD_REQUEST = 200000;

    public static final long PIN_MOD_API_PARTIAL_SUCCESS_BANK = 200042;

    public static final int SUCCESS_STAT_CD = 0;

    // HTTP Error Codes
    public static final int HTTP_ERROR_CODE_INTERNAL_SERVER = 500;

    public static final int HTTP_ERROR_CODE_BAD_REQUEST = 400;

    public static final int HTTP_ERROR_CODE_RESOURCE_NOT_FOUND = 404;

    public static final int HTTP_ERROR_CODE_PARTIAL_CONTENT = 206;

    public static final int HTTP_ERROR_CODE_403 = 403;

    // PIN Verification Error Codes
    // 500
    public static final int API_ERROR_GENERAL_ERROR = 200219; // Connectware Cardbase General Error

    // 400
    public static final int API_ERROR_INVALID_PIN = 200254; // Invalid PIN

    public static final int API_ERROR_CARD_NOT_FOUND = 200113; // No card found for the search criteria

    public static final int API_ERROR_NEGATIVE_FILE = 200259; // Card on negative file

    public static final int API_ERROR_ACCOUNT_NOT_GOOD_STANDING = 200115; // Account is not in good standing

    public static final int API_ERROR_ENTRIES_EXCEEDED = 200260; // Maximum number of tries exceeded

    public static final int API_ERROR_RESPOSE_VALIDATION_ERROR = 200226; // Response Validation Error

    public static final int API_ERROR_INVALID_LENGTH = 200255; // Invalid PIN length

    public static final int API_ERROR_MISSING_INPUT = 200256; // Missing Input

    public static final int API_ERROR_PREFIX_ERROR = 200878; // Prefix Error

    public static final int API_ERROR_INVALID_ENCRYPTED = 200879; // Invalid Encrypted PIN

    public static final int API_ERROR_SYSTEM_ERROR = 200803; // System Error

    public static final int API_ERROR_INVALID_INPUT = 200037; // Err Invalid Input

    public static final int API_ERROR_NO_MATCHING_RECORD = 200033; // No records matched the selection criteria of the
                                                                   // request.

    public static final String API_ERROR_GENERAL_ERROR_TXT = "Connectware Cardbase General Error";

    public static final String API_ERROR_INVALID_PIN_TXT = "Invalid PIN";

    public static final String API_ERROR_CARD_NOT_FOUND_TXT = "No card found for the search criteria";

    public static final String API_ERROR_NEGATIVE_FILE_TXT = "Card on negative file";

    public static final String API_ERROR_ACCOUNT_NOT_GOOD_STANDING_TXT = "Account is not in good standing";

    public static final String API_ERROR_ENTRIES_EXCEEDED_TXT = "Maximum number of tries exceeded";

    public static final String API_ERROR_RESPOSE_VALIDATION_ERROR_TXT = "Response Validation Error";

    public static final String API_ERROR_INVALID_LENGTH_TXT = "Invalid PIN length";

    public static final String API_ERROR_MISSING_INPUT_TXT = "Missing Input";

    public static final String API_ERROR_PREFIX_ERROR_TXT = "Prefix Error";

    public static final String API_ERROR_INVALID_ENCRYPTED_TXT = "Invalid Encrypted PIN";

    public static final String API_ERROR_SYSTEM_ERROR_TXT = "System Error";

    public static final String API_ERROR_INVALID_INPUT_TXT = "Err Invalid Input";

    public static final String API_ERROR_NO_MATCHING_RECORD_TXT = "No records matched the selection criteria of the request.";

    public static final String METAVANTE_ERROR_CODES = "MetavanteErrorCodes";

    public static final String NATIVE_ERROR_CODE = "NativeErrorCd";

    public static final String API_STAT_CODE = "StatCd";

    // E-mail Notification
    public static final String EMAIL_NOTIFICATION_DOCIDS = "EmailNotificationDocIds";

    public static final String CARD_ACTION_CODE = "CardActionCode";

    public static final String DOC_ID = "DocId";

    public static final String PARAM_KEY_ATTACHMENT_CONTENT = "attachmentContent";

    public static final String PARAM_KEY_ATTACHMENT_NAME = "attachmentName";

    public static final String DEFAULT_ATTACHMENT_NAME = "Disclosures.pdf";

    public static final String EXT_SYSTEM_CODE = "EFIT_IMAGING";

    public static final String CONTENT_INTEGRATION_GROUP = "CIG_CUST_BY_CID";

    public static final String MAXIMUM_DOC_BYTE_SIZE = "100000000";

    public static final String META_DATA_REQ_IND = "Y";

    public static final String EIP_ERROR = "900001";

    public static final String ECR_ERROR = "900002";

    public static final String CCC_ERROR = "900003";

    public static final String CUSTOMER_ID_NOT_FOUND = "900000";

    public static final String ATTACHMENT_NOT_FOUND = "900004";

    // header error codes
    public static final String HEADER_NOUSERID = "900004";

    public static final String SERVICE_NAME = "CustomerInteractionActivityService";

    public static final String PATH_PARAM_CUSTOMER_REFID = "customerReferenceId";

    public static final String PATH_PARAM_INTERACTION_ID = "interactionId";

    public static final String HTTP_ACCEPT = "application/json;v=3";

    public static final String DELEMETER = ",";

    public static final String ADDED_FROM = "added from";

    public static final String PERFORMED_ELIGIBLE_REATTEMPT = "performed; eligible reattempt";

    public static final String FAILED_FOR = "failed for";

    public static final String DATE_INFORMATION_NOT_FOUND = "1055-FRAUD EXCLUSION DATE INFORMATION NOT FOUND";
    
    private ServiceConstants(){
    	
    }

}