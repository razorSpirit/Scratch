package com.capitalone.api.card.service.util.activities;

import static com.capitalone.api.card.service.constants.ServiceConstants.ADDED_FROM;
import static com.capitalone.api.card.service.constants.ServiceConstants.PERFORMED_ELIGIBLE_REATTEMPT;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;

import com.capitalone.api.card.model.v3.CardActionType;
import com.capitalone.api.card.model.v3.FraudExclusionRequest;
import com.capitalone.epf.context.model.EPFContext;

@Named
public class ExclusionDatesActivity {

	protected static final String ACTIVITY_TYPE = "702104";

	private static final Logger LOGGER = LoggerFactory.getLogger(EmailNotificationActivity.class);

	@Inject
	private ActivityWriter activityWriter;

	private String customerNumber;
	private String interactionId;
	private List<String> references;

	private SimpleDateFormat oldFormat = new SimpleDateFormat("yyyy-MM-dd");
	private SimpleDateFormat newFormat = new SimpleDateFormat("MM/dd/yy");

	public void write(String activityType, String statusDescription, String startDate, String endDate,
			String customerNumber, String note, String interactionId) {
		LOGGER.info("Writing activity.");
		save(activityType, statusDescription, startDate, endDate, customerNumber, note, interactionId);
		run();
	}

	@Async
	public void async(EPFContext epfContext, FraudExclusionRequest request, String customerNumber, String note,
			String interactionId) {
		LOGGER.info("Writing activity. Using EPF Context:" + epfContext.getUserId());
		if(request.getCardActionType().equals(CardActionType.ANTI_FRAUD_SERVICING)){
			save(request.getCardActionType().getDescription(), PERFORMED_ELIGIBLE_REATTEMPT,
					changeDateFormat(oldFormat, newFormat, request.getExclusionStartDate()),
					changeDateFormat(oldFormat, newFormat, request.getExclusionEndDate()), customerNumber, note,
					interactionId);
		} else {
		save(request.getCardActionType().getDescription(), ADDED_FROM,
				changeDateFormat(oldFormat, newFormat, request.getExclusionStartDate()),
				changeDateFormat(oldFormat, newFormat, request.getExclusionEndDate()), customerNumber, note,
				interactionId);
		}
		run();
	}

	protected void save(String activityType, String statusDescription, String startDate, String endDate,
			String customerNumber, String note, String interactionId) {

		this.interactionId = interactionId;
		this.customerNumber = customerNumber;

		references = new ArrayList<String>();
		references.add(activityType);
		references.add(statusDescription);
		references.add(startDate);
		references.add(endDate);
		references.add(note);
	}

	private void run() {
		activityWriter.write(ACTIVITY_TYPE, references, interactionId, customerNumber);
	}

	public String changeDateFormat(DateFormat oldFormat, DateFormat newFormat, String oldDate) {
		try {
			return newFormat.format(oldFormat.parse(oldDate));
		} catch (ParseException e) {
            LOGGER.error("Error Formatting Dates:", e);
			return null;
		}
	}

}