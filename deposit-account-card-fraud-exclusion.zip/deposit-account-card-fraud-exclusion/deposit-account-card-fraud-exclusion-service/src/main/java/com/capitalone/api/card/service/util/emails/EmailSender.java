package com.capitalone.api.card.service.util.emails;

import static com.capitalone.api.card.service.constants.EmailConstants.CCC_COMMUNICATION_CHANNEL;
import static com.capitalone.api.card.service.constants.EmailConstants.PARAM_CLIENTID;
import static com.capitalone.api.card.service.constants.EmailConstants.PARAM_EMAIL;
import static com.capitalone.api.card.service.constants.EmailConstants.PARAM_FIRST_NAME;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import _100.customercommunication.gw.Contact;

import com.capitalone.api.bank.lib.cst.customers.dao.CustomerDetailsDao;
import com.capitalone.api.bank.lib.cst.customers.model.CustomerDetail;
import com.capitalone.api.bank.lib.customer.communication.dao.DGWCustomerCommunicationDAO;
import com.capitalone.api.bank.lib.customer.communication.model.CustomerCommunicationRequest;
import com.capitalone.api.bank.lib.customer.communication.model.CustomerCommunicationResult;
import com.capitalone.api.card.service.util.activities.EmailNotificationActivity;
import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;

@Profile
@Trace
@Named
public class EmailSender {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmailSender.class);

    protected static final String EMAIL_FAILED = "N";

    protected static final String EMAIL_SUCCESS = "Y";

    @Inject
    private DGWCustomerCommunicationDAO dgwCustomerCommunicationDAO;

    @Inject
    private CustomerDetailsDao customerDetailsDao;

    @Inject
    private EmailNotificationActivity emailNotificationActivity;

    public void send(EmailRequest request) {

        LOGGER.info("sending email started.");

        String emailStatus = EMAIL_SUCCESS;

        CustomerCommunicationResult customerCommunicationResult = null;

        try {
            CustomerCommunicationRequest cccRequest = buildCustomerCommunicationRequest(request.getAccountNumber(),
                    request.getCustomerNumber(), request.getRequestedBy(), request.getDocId(), request.getParameters());

            customerCommunicationResult = dgwCustomerCommunicationDAO.sendCustomerCommunication(cccRequest);
        } catch (Exception exception) {
            emailStatus = EMAIL_FAILED;
            LOGGER.error("Error occurred sending customer email notification.", exception);
        }

        if (emailStatus.equals(EMAIL_SUCCESS) && customerCommunicationResult != null) {
            emailStatus = customerCommunicationResult.isCorrespondenceSuccess() ? EMAIL_SUCCESS : EMAIL_FAILED;
            if(EMAIL_FAILED.equals(emailStatus)){
            	LOGGER.error("Error occurred sending customer email notification. See CCC logs.");
            }
        }
        
        if (request.isWritingActivity()) {
            emailNotificationActivity.write(request.getDocId(), emailStatus, request.getCustomerNumber(),
                    request.getInteractionId(), request.getActivityDescription());
        }

        LOGGER.info("sending email completed with {}.", emailStatus);
    }

    protected CustomerCommunicationRequest buildCustomerCommunicationRequest(String accountNumber,
            String customerNumber, String requestedBy, String docId, Map<String, String> parameters) {
        LOGGER.info("building CustomerCommunicationRequest started");
        CustomerCommunicationRequest request = new CustomerCommunicationRequest();
        request.setCustomerNumber(new BigInteger(customerNumber));
        request.setDocumentTemplateId(docId);
        request.setAccountNumber(accountNumber);
        request.setParameterMap(buildParameterMap(customerNumber, parameters));
		Contact contactDetails = new Contact();
		request.setCustomerContactDetails(contactDetails);		
        request.setRequestedBy(requestedBy);
        request.getCommunicationChannelList().add(CCC_COMMUNICATION_CHANNEL);
        LOGGER.info("building CustomerCommunicationRequest completed");

        return request;
    }

    protected Map<String, String> buildParameterMap(String customerNumber, Map<String, String> parameters) {
        LOGGER.info("building parameters");
        Map<String, String> parameterMap = new HashMap<String, String>();

        parameterMap.putAll(buildCustomerParameters(customerNumber));
        parameterMap.putAll(parameters);

        LOGGER.info("completed building parameters");

        return parameterMap;
    }

    protected Map<String, String> buildCustomerParameters(String customerNumber) {
        LOGGER.info("buiding customer parameters...");

        CustomerDetail customerDetail = customerDetailsDao.getCustomerDetail(customerNumber);

        Map<String, String> parameters = new HashMap<String, String>();

        String email = null;
        if (customerDetail.getEmailAddresses() != null && customerDetail.getEmailAddresses().get(0) != null) {
            email = customerDetail.getEmailAddresses().get(0).getEmailAddress();
        }

         parameters.put(PARAM_EMAIL, email);
         parameters.put(PARAM_FIRST_NAME, customerDetail.getFirstName());
         parameters.put(PARAM_CLIENTID, customerDetail.getCustomerId());

        LOGGER.info("completed buiding customer parameters");

        return parameters;
    }

}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
