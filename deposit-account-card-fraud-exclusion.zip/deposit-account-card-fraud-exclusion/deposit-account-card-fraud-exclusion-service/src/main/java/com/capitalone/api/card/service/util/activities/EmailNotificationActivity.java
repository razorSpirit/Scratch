package com.capitalone.api.card.service.util.activities;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Named
public class EmailNotificationActivity {
    protected static final String ACTIVITY_TYPE = "701178";
    private static final Logger LOGGER = LoggerFactory.getLogger(EmailNotificationActivity.class);

    @Inject
    private ActivityWriter activityWriter;
    
    private String customerNumber;
    private String interactionId;
    private List<String> references;
    
	public void write(String docId, String emailStatus, String customerNumber, String interactionId, String activityDescription) {
		LOGGER.info("Writing activity.");
		save(customerNumber, interactionId, docId, emailStatus, activityDescription);
		run();
	}
	
    public void save(String customerNumber, String interactionId, String docId, String emailStatus, String activityDescription) {
    	this.interactionId = interactionId;
    	this.customerNumber = customerNumber;
    	references = new ArrayList<String>();
        references.add(activityDescription);
        references.add("DocId: " + docId);
        references.add("Successful(" + emailStatus + ")");
    }

	private void run() {
		activityWriter.write(ACTIVITY_TYPE, references, interactionId, customerNumber);
	}

}