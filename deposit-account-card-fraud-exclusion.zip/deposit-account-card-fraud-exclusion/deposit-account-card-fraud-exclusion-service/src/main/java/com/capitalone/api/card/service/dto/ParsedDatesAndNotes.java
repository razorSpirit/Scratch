package com.capitalone.api.card.service.dto;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

public class ParsedDatesAndNotes {

    private String exclusionStartDate;

    private String exclusionEndDate;

    private List<ParsedNote> parsedNotes;

    public String getExclusionStartDate() {
        return exclusionStartDate;
    }

    public void setExclusionStartDate(String exclusionStartDate) {
        this.exclusionStartDate = exclusionStartDate;
    }

    public String getExclusionEndDate() {
        return exclusionEndDate;
    }

    public void setExclusionEndDate(String exclusionEndDate) {
        this.exclusionEndDate = exclusionEndDate;
    }

    public List<ParsedNote> getParsedNote() {
        if (null == parsedNotes) {
            parsedNotes = new ArrayList<ParsedNote>();
        }
        return parsedNotes;
    }

    public void setParsedNote(List<ParsedNote> parsedNotes) {
        this.parsedNotes = parsedNotes;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        int noteCount = (null == parsedNotes || parsedNotes.isEmpty()) ? 0 : parsedNotes.size();
        sb.append(safeString(exclusionStartDate)).append(safeString(exclusionEndDate))
                .append(safeString(exclusionEndDate)).append(String.valueOf(noteCount));
        return sb.toString();
    }

    private static String safeString(String value) {
        return StringUtils.isEmpty(value) ? "" : value;
    }

}
