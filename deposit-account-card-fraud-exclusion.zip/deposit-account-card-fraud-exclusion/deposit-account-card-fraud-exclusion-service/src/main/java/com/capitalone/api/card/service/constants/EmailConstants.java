package com.capitalone.api.card.service.constants;

public final class EmailConstants {

    //-------------------------- CCC ------------------------------
    public static final String CCC_COMMUNICATION_CHANNEL = "EMAIL";

    //-------------------------- REQUIRED ------------------------------
    public static final String PARAM_EMAIL = "Email";

    public static final String PARAM_CLIENTID = "clientID";

    //-------------------------- OPTIONAL ------------------------------
    public static final String PARAM_FIRST_NAME = "FirstName";
    
}