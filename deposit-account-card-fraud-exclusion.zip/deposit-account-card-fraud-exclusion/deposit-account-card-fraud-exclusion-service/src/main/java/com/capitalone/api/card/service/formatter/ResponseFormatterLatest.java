package com.capitalone.api.card.service.formatter;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.capitalone.api.card.model.v3.CardActionType;
import com.capitalone.api.card.model.v3.FraudExclusionNoteDetail;
import com.capitalone.api.card.model.v3.FraudExclusionRetrievalResponse;
import com.capitalone.api.card.model.v3.ServicingNoteFormat;
import com.capitalone.api.card.service.dto.ParsedDatesAndNotes;
import com.capitalone.api.card.service.dto.ParsedNote;

/**
 * Creates FraudExclusionRetrievalResponse for LATEST format
 */
public class ResponseFormatterLatest {

    final DateTimeFormatter notesDtformat = DateTimeFormat.forPattern("MM/dd/yy");

    final DateTimeFormatter fraudDtFormat = DateTimeFormat.forPattern("yyyy-MM-dd");

    /**
     * Creates FraudExclusionRetrievalResponse from the ParsedDatesAndNotes created from Metavante (CMSE)
     * 
     * @param parsedDatesAndNotes Fraud Exclusion Dates and parsed Notes from Metavante
     * @return API response for Fraud Exclusion Dates and Notes fetched from Metavante
     */
    public FraudExclusionRetrievalResponse format(ParsedDatesAndNotes parsedDatesAndNotes) {
        return createFormatLatestResponse(parsedDatesAndNotes);
    }

    /**
     * Creates FraudExclusionRetrievalResponse for LATEST format
     * 
     * @param parsedDatesAndNotes Fraud Exclusion Dates and parsed Notes from Metavante
     * @return API response for LATEST format
     */
    public FraudExclusionRetrievalResponse createFormatLatestResponse(ParsedDatesAndNotes parsedDatesAndNotes) {
        List<String> cardActionTypeList = new ArrayList<String>();
        String cardActionType = null;
        List<ParsedNote> matchedNotesList = getMatchedParsedNotesList(parsedDatesAndNotes);

        if (matchedNotesList.isEmpty()) {
            ResponseFormatterAll responseFormatterAll = new ResponseFormatterAll();
            return responseFormatterAll.format(parsedDatesAndNotes);

        } else {
            List<FraudExclusionNoteDetail> servicingNotesList = new ArrayList<FraudExclusionNoteDetail>();
            for (ParsedNote note : matchedNotesList) {
                cardActionType = note.getNoteCardActionType();
                // if we have different action types for given exclusion dates, then return the ALL response
                // else continue setting the note in list
                boolean isDifferentActionType = isDifferentActionType(cardActionTypeList, cardActionType);
                if (isDifferentActionType) {
                    ResponseFormatterAll responseFormatterAll = new ResponseFormatterAll();
                    return responseFormatterAll.format(parsedDatesAndNotes);
                }
                FraudExclusionNoteDetail noteDetail = new FraudExclusionNoteDetail();
                noteDetail.setServicingNotesLineNumber(note.getLineNumber());
                noteDetail.setServicingNote(note.getNote());
                servicingNotesList.add(noteDetail);
            }

            FraudExclusionRetrievalResponse response = new FraudExclusionRetrievalResponse();
            response.setServicingNoteFormat(ServicingNoteFormat.LATEST);
            response.setExclusionStartDate(parsedDatesAndNotes.getExclusionStartDate());
            response.setExclusionEndDate(parsedDatesAndNotes.getExclusionEndDate());
            response.setCardActionCode(CardActionType.valueForNotesCode(cardActionType));
            response.setServicingNotes(servicingNotesList);

            return response;
        }

    }

    /**
     * Returns all the ParsedNote that matches the fraud exclusion dates set in Metavante
     * 
     * @param parsedDatesAndNotes Fraud Exclusion Dates and parsed Notes from Metavante
     * @return API response for LATEST format
     */
    public List<ParsedNote> getMatchedParsedNotesList(ParsedDatesAndNotes parsedDatesAndNotes) {
        List<ParsedNote> matchedNotesList = new ArrayList<ParsedNote>();

        DateTime fromDt = parsedDatesAndNotes.getExclusionStartDate() != null ? fraudDtFormat
                .parseDateTime(parsedDatesAndNotes.getExclusionStartDate()) : null;
        DateTime toDt = parsedDatesAndNotes.getExclusionEndDate() != null ? fraudDtFormat
                .parseDateTime(parsedDatesAndNotes.getExclusionEndDate()) : null;
        List<ParsedNote> parsedNotesList = parsedDatesAndNotes.getParsedNote();
        if (parsedNotesList != null) {
            Iterator<ParsedNote> itr = parsedNotesList.iterator();
            while (itr.hasNext()) {
                ParsedNote note = itr.next();
                if (notesDtformat.print(fromDt).equals(note.getNoteStartDate())
                        && notesDtformat.print(toDt).equals(note.getNoteEndDate())) {
                    matchedNotesList.add(note);
                }
            }
        }

        return matchedNotesList;
    }

    /**
     * Returns if action type is different than previously encountered action types
     * 
     * @param checkString The current encountered action type
     * @return whether action type is different
     */
    public boolean isDifferentActionType(List<String> list, String checkString) {
        if (list.isEmpty() ) {
            list.add(checkString);
            return false;
        } else {
            if (list.contains(checkString))
                return false;
        }
        return true;
    }
} 