package com.capitalone.api.card.service.exceptions;

import javax.ws.rs.core.Response;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.capitalone.api.commons.exception.AbstractApiException;
import com.capitalone.api.commons.exception.ApiErrorCode;

public class PartialApiException extends AbstractApiException {
    private final int httpStatusCode = Response.Status.PARTIAL_CONTENT.getStatusCode();

    private static final long serialVersionUID = 5432674880906634840L;

    public PartialApiException(ApiErrorCode error) {
        super(error);
    }
    
    @Override
    public int getHttpStatusCode() {
        return httpStatusCode;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}