package com.capitalone.api.card.service.util.card;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang.StringUtils;

import com.capitalone.api.bank.lib.metavante.dao.impl.MetavanteDaoImpl;
import com.capitalone.api.bank.lib.metavante.model.ArrayOfCardNumbers;
import com.capitalone.api.bank.lib.metavante.model.SearchCardsRequest;
import com.capitalone.api.bank.lib.metavante.model.SearchCardsResponse;
import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.model.id.CardReferenceId;

@Profile
@Trace
@Named
public class CardFinder {

	@Inject
	private MetavanteDaoImpl metavanteDaoImpl;

	public ArrayOfCardNumbers getCardNumber(CardReferenceId cardReferenceId) {

		SearchCardsRequest searchCardsRq = new SearchCardsRequest();
		searchCardsRq.setAccountNumber(cardReferenceId.getAccountId());
		SearchCardsResponse searchCardsRs = null;

		searchCardsRs = metavanteDaoImpl.searchCards(searchCardsRq);

		ArrayOfCardNumbers matchedCard = null;

		// Search card
		if (searchCardsRs != null) {
			matchedCard = getCardNumber(searchCardsRs.getArrayOfCardNumbers(), cardReferenceId.getFirstSix(),
					cardReferenceId.getLastFour());
		}

		return matchedCard;
	}

	/**
     * Get Card Number based on first 6 digits and last 4 digits.
     * 
     * @param arrayOfCardNumbersList
     * @param accountNumber
     * @param sourceFirstSixDigits
     * @param sourceLastFourDigits
     * @return
     */
    private static ArrayOfCardNumbers getCardNumber(List<ArrayOfCardNumbers> arrayOfCardNumbersList,
            String sourceFirstSixDigits, String sourceLastFourDigits) {

        String cardNumber = StringUtils.EMPTY;
        for (ArrayOfCardNumbers arrayOfCardNumbers : arrayOfCardNumbersList) {
            if (arrayOfCardNumbers != null) {
                cardNumber = arrayOfCardNumbers.getCardNumber();
                if (StringUtils.isNotBlank(cardNumber) && StringUtils.equalsIgnoreCase(sourceFirstSixDigits,  getFirstSixDigits(cardNumber))
                        && StringUtils.equalsIgnoreCase(sourceLastFourDigits, getLastFourDigits(cardNumber))) {                    
                        return arrayOfCardNumbers;                    
                }
            }
        }

        return null;
    }

	/**
	 * 
	 * @param cardNo
	 * @return
	 */
	protected static String getFirstSixDigits(String cardNo) {
		String firstSixCardDigits = "";
		if (StringUtils.isNotBlank(cardNo) && cardNo.length() > 10) {
			firstSixCardDigits = cardNo.substring(0, 6);
		}
		return firstSixCardDigits;
	}

	/**
	 * 
	 * @param cardNumber
	 * @return
	 */
	protected static String getLastFourDigits(String cardNumber) {
		String lastFourCardDigits = "";
		if (StringUtils.isNotBlank(cardNumber) && cardNumber.length() > 10) {
			lastFourCardDigits = cardNumber.substring(cardNumber.length() - 4);
		}
		return lastFourCardDigits;
	}

}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of
 * Capital One and is protected by law. It may not be copied or distributed in
 * any form or medium, disclosed to third parties, reverse engineered or used in
 * any manner without prior written authorization from Capital One.
 */