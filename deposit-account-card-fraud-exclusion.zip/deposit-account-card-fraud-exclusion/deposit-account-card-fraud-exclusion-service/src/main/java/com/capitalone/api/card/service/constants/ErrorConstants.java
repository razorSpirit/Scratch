package com.capitalone.api.card.service.constants;

public final class ErrorConstants {
	
    // ========================== MESSAGE ID'S (for MessagePropertyKeys) ==============================    
    public static final String ERR_MSG_ID_FROM_DT_PAST = "200016";
    
    public static final String ERR_MSG_ID_TO_DT_PAST = "200017";
    
    public static final String ERR_MSG_ID_TO_DT_BEFORE = "200048";
    
    public static final String ERR_MSG_ID_TO_DT_AFTER = "200018";
    
    public static final String ERR_MSG_ID_XCLU_DT_INVALID = "200049";
    
    public static final String ERR_MSG_ID_FROM_DT_BLANK = "200010";
    
    public static final String ERR_MSG_ID_TO_DT_BLANK = "200011";
    
    public static final String ERR_MSG_ID_NOTE_BLANK = "200013";
    
    public static final String ERR_MSG_ID_NOTE_INVALID_LEN = "200014";
    
    public static final String ERR_MSG_ID_EXCLU_TYPE_BLANK = "200012";
    
    public static final String ERR_MSG_ID_EXCLU_TYPE_INVALID = "200050";
    
    public static final String ERR_MSG_ID_CARD_NOT_WITH_ACCOUNT = "200051";
    
    public static final String ERR_MSG_ID_CARD_STATUS_INVALID = "200015";
    
    public static final String ERR_MSG_ID_CARD_LAST4_INVALID = "200053";
    
    public static final String ERR_MSG_ID_CARD_FIRST6_INVALID = "200054";
    
    public static final String ERR_MSG_ID_SOURCE_ID_INVALID = "200055";
    
    public static final String ERR_MSG_ID_ACCOUNT_ID_INVALID = "200056";

    public static final String ERR_MSG_ID_UNEXPECTED = "200057";
    
    public static final String ERR_MSG_ID_FROM_DT_FORMAT_INVALID  = "200058";
    
    public static final String ERR_MSG_ID_TO_DT_FORMAT_INVALID = "200059";

    public static final String ERR_MSG_ID_SERVICING_NOTE_FORMAT_ID_INVALID = "200060";
    
    public static final String ERR_MSG_ID_USER_ID_BLANK = "200061";
    
    // ========================== DEVELOPER TEXT ==============================
    public static final String DEV_TXT_DATES_FAILED = "The adding of the dates failed.";
    public static final String DEV_TXT_NOTE_FAILED = "The adding of the note failed.";
    public static final String DEV_TXT_DATE_ROLLBACK = "The rollback of the dates failed.";
    public static final String DEV_TXT_VENDOR_HEALTH_FAILED = "Metavante health check failed."; 
    public static final String DEV_TXT_GET_DATES_FAILED = "The fetching of the fraud exclusion dates failed.";
    public static final String DEV_TXT_GET_NOTES_FAILED = "The fetching of the notes failed.";
    // ========================== ADDITIONAL API ERROR CODES ==============================
    //       Base API error codes are found in ApiErrorCode.DEFAULT_ERROR_CODE
    public static final String METAVANTE_ERROR_CODE = "200113";
    public static final long UNEXPECTED_ERROR = -99999;
    
    private ErrorConstants ()
	{
		
	}
    
}