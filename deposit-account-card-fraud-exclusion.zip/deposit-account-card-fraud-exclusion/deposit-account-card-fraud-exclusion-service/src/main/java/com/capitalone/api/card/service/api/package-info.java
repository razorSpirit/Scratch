/**
 * These are the exposed service interfaces for the deposit-account-card-fraud-exclusion functionality.
 */
package com.capitalone.api.card.service.api;