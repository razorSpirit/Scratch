package com.capitalone.api.card.service.util.activities;

import java.math.BigInteger;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.bank.lib.activity.dao.ActivityDao;
import com.capitalone.api.bank.lib.activity.model.Activity;
import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;

@Profile
@Trace
@Named
public class ActivityWriter {

    private static final Logger LOGGER = LoggerFactory.getLogger(ActivityWriter.class);

    @Inject
    private ActivityDao activityDao;

    public void write(String activityType, List<String> refDataList, String interactionId, String customerNumber) {
        LOGGER.info("started writing activityType{}", activityType);
        Activity activity = new Activity();
        activity.setCustomerId(customerNumber);
        activity.setInteractionId(new BigInteger(interactionId));
        activity.setActivityTypeId(new BigInteger(activityType));
        activity.getActivityReferenceData().addAll(refDataList);
        try {
            activityDao.createActivity(activity);
        } catch (Exception e) {
            LOGGER.error("Exception occured in capturing activity: " + e);
        }
        LOGGER.info("completed writing activityType{}", activityType);
    }
}