package com.capitalone.api.card.service.util.notes;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.capitalone.api.card.model.v3.CardActionType;
import com.capitalone.api.card.model.v3.FraudExclusionRequest;

public class NoteStamper {
	
    public static String getStampedNote(FraudExclusionRequest request){       
        final DateTimeFormatter notesDtFormat = DateTimeFormat.forPattern("MM/dd/yy");        
        final DateTimeFormatter fraudDtFormat = DateTimeFormat.forPattern("yyyy-MM-dd");

		String exclusionTypeCode = CardActionType.valueFor(request.getCardActionCode()).getNotesCode();

		DateTime fromDt = fraudDtFormat.parseDateTime(request.getExclusionStartDate());
		DateTime toDt = fraudDtFormat.parseDateTime(request.getExclusionEndDate());

		String dateRange = notesDtFormat.print(fromDt) + "-" + notesDtFormat.print(toDt) ;

    	return exclusionTypeCode + ":" +dateRange + " "+ request.getServicingNotes();
    }
}