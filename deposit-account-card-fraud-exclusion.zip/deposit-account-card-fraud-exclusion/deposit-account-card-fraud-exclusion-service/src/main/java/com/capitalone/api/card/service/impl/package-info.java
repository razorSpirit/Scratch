/**
 * These are the implementations for the service interfaces {@link com.capitalone.api.card.service.api} for the deposit-account-card-fraud-exclusion functionality.
 */
package com.capitalone.api.card.service.impl;