package com.capitalone.api.card.service.util.emails;

import java.util.HashMap;
import java.util.Map;

public class EmailRequest {
	private String accountNumber;
	private String activityDescription;
	private String customerNumber;
	private String requestedBy;
	private String docId;	
	private Map<String, String> parameters;
	private String interactionId;
	private boolean isWritingActivity;
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getActivityDescription() {
		return activityDescription;
	}
	public void setActivityDescription(String activityDescription) {
		this.activityDescription = activityDescription;
	}			
	public String getCustomerNumber() {
		return customerNumber;
	}
	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}
	public String getRequestedBy() {
		return requestedBy;
	}
	public void setRequestedBy(String requestedBy) {
		this.requestedBy = requestedBy;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public Map<String, String> getParameters() {
		return null == parameters ? new HashMap<String, String>() : parameters;
	}
	public void setParameters(Map<String, String> parameters) {
		this.parameters = parameters;
	}
	public String getInteractionId() {
		return interactionId;
	}
	public void setInteractionId(String interactionId) {
		this.interactionId = interactionId;
	}
	public boolean isWritingActivity() {
		return isWritingActivity;
	}
	public void setWritingActivity(boolean isWritingActivity) {
		this.isWritingActivity = isWritingActivity;
	}

}
