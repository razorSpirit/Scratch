package com.capitalone.api.card.service.formatter;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.capitalone.api.card.model.v3.CardActionType;
import com.capitalone.api.card.model.v3.FraudExclusionNoteDetail;
import com.capitalone.api.card.model.v3.FraudExclusionRetrievalResponse;
import com.capitalone.api.card.model.v3.ServicingNoteFormat;
import com.capitalone.api.card.service.dto.ParsedDatesAndNotes;
import com.capitalone.api.card.service.dto.ParsedNote;

public class ResponseFormatterAll {

    private static final String COLON = " : ";

    private static final String HYPHEN = "-";

    private static final String SPACE = " ";

    public FraudExclusionRetrievalResponse format(ParsedDatesAndNotes parsedDatesAndNotes) {

        FraudExclusionRetrievalResponse response = new FraudExclusionRetrievalResponse();

        response.setServicingNoteFormat(ServicingNoteFormat.ALL);
        response.setExclusionStartDate(parsedDatesAndNotes.getExclusionStartDate());
        response.setExclusionEndDate(parsedDatesAndNotes.getExclusionEndDate());
        List<ParsedNote> parsedNotes = parsedDatesAndNotes.getParsedNote();

        List<FraudExclusionNoteDetail> servicingNotesList = new ArrayList<FraudExclusionNoteDetail>();

        for (ParsedNote note : parsedNotes) {
            FraudExclusionNoteDetail fraudExcluNoteDetail = new FraudExclusionNoteDetail();
            fraudExcluNoteDetail.setServicingNotesLineNumber(note.getLineNumber());

            StringBuilder noteBuilder = new StringBuilder();

            if (StringUtils.isNotEmpty(note.getNoteCardActionType())
                    && !StringUtils.equalsIgnoreCase(note.getNoteCardActionType(),
                            CardActionType.OTHER.getDescription())) {
                noteBuilder.append(note.getNoteCardActionType()).append(SPACE).append(note.getNoteStartDate())
                        .append(HYPHEN).append(note.getNoteEndDate()).append(COLON);
            }
            noteBuilder.append(note.getNote()).toString();

            fraudExcluNoteDetail.setServicingNote(noteBuilder.toString());
            servicingNotesList.add(fraudExcluNoteDetail);
        }
        response.setServicingNotes(servicingNotesList);

        return response;
    }
}
