package com.capitalone.api.card.service.api;

import com.capitalone.api.card.model.v3.FraudExclusionRequest;
import com.capitalone.api.card.model.v3.FraudExclusionRetrievalRequest;
import com.capitalone.api.card.model.v3.FraudExclusionRetrievalResponse;
import com.capitalone.api.commons.model.EntityRequest;
import com.capitalone.api.commons.services.api.HealthCheckableService;

/**
 * Service for manipulating FraudExclusionRequest.
 * 
 * @author Generated
 * 
 */
public interface CardFraudExclusionService extends HealthCheckableService {

    /**
     * Creates Fraud Exclusion dates and note.
     * 
     * @param entityRequest
     * @param request
     * 
     */
    void create(FraudExclusionRequest request, EntityRequest entityRequest);
    
    /**
     * Retrieves  Fraud Exclusion dates and note(s) in different formats.
     * 
     * @param request
     * @param entityRequest
     * @return FraudExclusionRetrievalResponse
     */    
    FraudExclusionRetrievalResponse retrieve(FraudExclusionRetrievalRequest request,  EntityRequest entityRequest);
}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */