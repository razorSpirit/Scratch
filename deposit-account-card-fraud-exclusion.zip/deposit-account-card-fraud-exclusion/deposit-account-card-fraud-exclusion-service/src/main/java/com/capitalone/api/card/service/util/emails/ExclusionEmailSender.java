package com.capitalone.api.card.service.util.emails;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;

import com.capitalone.api.card.model.v3.FraudExclusionRequest;
import com.capitalone.api.commons.model.EntityRequest;
import com.capitalone.epf.context.model.EPFContext;

@Named
public class ExclusionEmailSender {
	FraudExclusionRequest request;
	EntityRequest entityRequest;
	String customerNumber;
    private static final Logger LOGGER = LoggerFactory.getLogger(ExclusionEmailSender.class);
    
	@Inject ExclusionEmail exclusionEmail;

	@Async
	public void async(EPFContext epfContext, FraudExclusionRequest request, EntityRequest entityRequest, String customerNumber) {	    
    	LOGGER.info("started sending email, using epfContext:"+ epfContext.getUserId());
		this.request = request;
		this.entityRequest = entityRequest;
		this.customerNumber = customerNumber;
		run();
	}
	
	private void run() {
        EmailRequest emailRequest = exclusionEmail.buildRequest(request.getCardActionType(), request.getAccountNumber(), request.getCardReferenceId().getLastFour(), customerNumber, entityRequest.getClientCorrelationId(), entityRequest.getUserId());
        exclusionEmail.send(emailRequest);		
	}
	
}
