package com.capitalone.api.card.service.dao;

import com.capitalone.api.bank.lib.metavante.model.AcctInqResponse;
import com.capitalone.api.bank.lib.metavante.model.ArrayOfCardNumbers;
import com.capitalone.api.bank.lib.metavante.model.FraudExclusionDatesResponse;
import com.capitalone.api.bank.lib.metavante.model.NotesResponse;
import com.capitalone.api.bank.lib.metavante.model.SearchCardsResponse;

public interface CardFraudExclusionDAO {

    public void addDates(String cardNumber, String startDate, String endDate);

    public void addNote(String cardNumber, String startDate, String endDate, String note);

    public AcctInqResponse lookUpAccountByCardNumber(String cardNumber);

    public SearchCardsResponse findCardsByAccountNumber(String accountNumber);

    public ArrayOfCardNumbers findCard(String accountNumber, String firstSixOfCard, String lastFourOfCard);

    public void isHealthy();

    public FraudExclusionDatesResponse getDates(String cardNumber);

    public NotesResponse getNotes(String cardNumber);
}
