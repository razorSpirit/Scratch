
package com.capitalone.api.card.service.formatter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capitalone.api.card.model.v3.CardActionType;
import com.capitalone.api.card.model.v3.FraudExclusionNoteDetail;
import com.capitalone.api.card.model.v3.FraudExclusionRetrievalResponse;
import com.capitalone.api.card.model.v3.History;
import com.capitalone.api.card.model.v3.ServicingNoteFormat;
import com.capitalone.api.card.service.dto.ParsedDatesAndNotes;
import com.capitalone.api.card.service.dto.ParsedNote;

public class ResponseFormatterHistory {

    public FraudExclusionRetrievalResponse format(ParsedDatesAndNotes parsedDatesAndNotes) {

        FraudExclusionRetrievalResponse response = new FraudExclusionRetrievalResponse();

        response.setServicingNoteFormat(ServicingNoteFormat.HISTORY);
        response.setExclusionStartDate(parsedDatesAndNotes.getExclusionStartDate());
        response.setExclusionEndDate(parsedDatesAndNotes.getExclusionEndDate());

        response.setHistory(buildHistory(parsedDatesAndNotes.getParsedNote()));

        return response;
    }

    protected List<History> buildHistory(List<ParsedNote> parsedNoteList) {

        Map<String, History> historyMap = new HashMap<String, History>();
        for (ParsedNote parsedNote : parsedNoteList) {
            StringBuilder keyBuilder = new StringBuilder();
            keyBuilder.append(parsedNote.getNoteStartDate()).append(parsedNote.getNoteEndDate())
                    .append(parsedNote.getNoteCardActionType());
            String key = keyBuilder.toString();

            FraudExclusionNoteDetail noteDetail = new FraudExclusionNoteDetail();
            noteDetail.setServicingNotesLineNumber(parsedNote.getLineNumber());
            noteDetail.setServicingNote(parsedNote.getNote());

            if (historyMap.containsKey(key)) {
                historyMap.get(key).getServicingNotes().add(noteDetail);
            } else {
                History history = new History();
                history.setStartDate(parsedNote.getNoteStartDate());
                history.setEndDate(parsedNote.getNoteEndDate());
                history.setCardActionType(CardActionType.valueForNotesCode(parsedNote.getNoteCardActionType()));

                List<FraudExclusionNoteDetail> noteList = new ArrayList<FraudExclusionNoteDetail>();
                noteList.add(noteDetail);
                history.setServicingNotes(noteList);

                historyMap.put(key, history);
            }

        }

        return new ArrayList<History>(historyMap.values());
    }
}