package com.capitalone.api.card.service.util.emails;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;

import com.capitalone.api.card.model.v3.CardActionType;

@Named
public class ExclusionEmail {

    @Inject
    EmailSender emailSender;

    protected static final String FRAUD_DOCID = "0000001251";

    protected static final String TRAVEL_DOCID = "0000001252";

    protected static final String FRAUD_DESCRIPTION = "Anti Fraud Alert";

    protected static final String TRAVEL_DESCRIPTION = "Travel Notice Alert";

    protected static final String PARAM_DATE = "date";
    
    protected static final String PARAM_CARD_NUMBER = "LastFourDigitsCardNo";
    
    
    public void send(EmailRequest request) {
        emailSender.send(request);
    }

    public EmailRequest buildRequest(CardActionType type, String accountNumber, String lastFourCardNumber, String customerNumber, 
            String interactionId, String requestedBy) {
        EmailRequest request = new EmailRequest();

        switch (type) {
            case ANTI_FRAUD_SERVICING:
                request.setDocId(FRAUD_DOCID);
                request.setActivityDescription(FRAUD_DESCRIPTION);
                break;
            case TRAVEL_NOTIFICATION:
                request.setDocId(TRAVEL_DOCID);
                request.setActivityDescription(TRAVEL_DESCRIPTION);
                break;
            default:

        }

        request.setAccountNumber(accountNumber);
        request.setCustomerNumber(customerNumber);
        request.setInteractionId(interactionId);
        request.setRequestedBy(requestedBy);
        request.setParameters(buildParameters(type, lastFourCardNumber));
        request.setWritingActivity(true);

        return request;
    }

    public static Map<String, String> buildParameters(CardActionType type, String lastFourCardNumber) {
        Map<String, String> parameters = new HashMap<String, String>();
        parameters.put(PARAM_DATE, DateTimeFormat.forPattern("MM/dd/yyyy").print(new LocalDate()));
        if(CardActionType.ANTI_FRAUD_SERVICING.equals(type)){
        	parameters.put(PARAM_CARD_NUMBER, lastFourCardNumber);
        }
        return parameters;
    }
}