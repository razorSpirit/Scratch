package com.capitalone.api.card.service.dto;

import java.math.BigInteger;

public class Card {

	private String cardNumber;
	private String customerNumber;
	private String firstName;
	private String profileState;
	private String profileStatus;
	private BigInteger metavanteStatus;
	
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getCustomerNumber() {
		return customerNumber;
	}
	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getProfileState() {
		return profileState;
	}
	public void setProfileState(String profileState) {
		this.profileState = profileState;
	}
	public String getProfileStatus() {
		return profileStatus;
	}
	public void setProfileStatus(String profileStatus) {
		this.profileStatus = profileStatus;
	}
	public BigInteger getMetavanteStatus() {
		return metavanteStatus;
	}
	public void setMetavanteStatus(BigInteger metavanteStatus) {
		this.metavanteStatus = metavanteStatus;
	}
}
