package com.capitalone.api.card.service.util.errors;

import static com.capitalone.api.card.service.constants.ErrorConstants.DEV_TXT_DATES_FAILED;
import static org.mockito.Mockito.doThrow;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

import com.capitalone.api.bank.lib.metavante.model.AddnStat;
import com.capitalone.api.bank.lib.metavante.model.StatType;
import com.capitalone.api.card.service.exceptions.PartialApiException;
import com.capitalone.api.commons.exception.ApiSystemException;

public class ErrorHandlerTest {

	@Test
	public void testApiSystemException(){
		try{
			StatType type =  null;
		 ErrorHandler.throwApiSystemException(DEV_TXT_DATES_FAILED, type);
		}catch(ApiSystemException e){
			return;
		}
		Assert.fail();
		
	}
	
	@Test
	public void testApiSystemException2(){
		try{			
		 ErrorHandler.throwApiSystemException(DEV_TXT_DATES_FAILED, "test");
		}catch(ApiSystemException e){
			return;
		}
		Assert.fail();
		
	}
	
	@Test
	public void testApiSystemException3(){
		try{			
		 ErrorHandler.throwApiSystemException(DEV_TXT_DATES_FAILED, "test","test");
		}catch(ApiSystemException e){
			return;
		}
		Assert.fail();
		
	}
	
	@Test(expected=PartialApiException.class)
    public void testThrowPartialSuccessException(){
	    StatType statType = new StatType();
	    AddnStat addnStat = new AddnStat();
	    addnStat.setNativeErrorCd("1");
	    addnStat.setStatDesc("Error");
	    List<AddnStat> lAddnStats = new ArrayList<AddnStat>();
	    lAddnStats.add(addnStat);
	    statType.setAddnStat(lAddnStats);
	    
        ErrorHandler.throwPartialSuccessException("Error Partial Exception", statType);
    }
	

    
}
