package com.capitalone.api.card.service.util.emails;

import static com.capitalone.api.card.service.constants.EmailConstants.PARAM_CLIENTID;
import static com.capitalone.api.card.service.constants.EmailConstants.PARAM_EMAIL;
import static com.capitalone.api.card.service.constants.EmailConstants.PARAM_FIRST_NAME;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Appender;
import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggingEvent;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;



//import _100.customer.gw.Email;
import com.capitalone.api.bank.lib.cst.customers.dao.CustomerDetailsDao;
import com.capitalone.api.bank.lib.cst.customers.model.CustomerDetail;
import com.capitalone.api.bank.lib.cst.customers.model.Email;
import com.capitalone.api.bank.lib.customer.communication.dao.DGWCustomerCommunicationDAO;
import com.capitalone.api.bank.lib.customer.communication.model.CustomerCommunicationRequest;
import com.capitalone.api.bank.lib.customer.communication.model.CustomerCommunicationResult;
import com.capitalone.api.card.service.util.activities.EmailNotificationActivity;

public class EmailSenderTest {

    @InjectMocks
    private EmailSender emailSender;

    @Mock
    private DGWCustomerCommunicationDAO dgwCustomerCommunicationDAO;

    @Mock
    private CustomerDetailsDao customerDetailsDao;

    @Mock
    private EmailNotificationActivity emailNotificationActivity;

    @Mock
    private Appender mockAppender;

    @Mock
    private CustomerDetail customerDetailMock;
    
    private static final String VALID_CUST_NAME = "John";

    private static final String VALID_CUST_ID = "A12";

    private static final String VALID_CUST_NUMBER = "123";
    
    private static final String VALID_ACCT_NUMBER = "444567";
    
    private static final String VALID_REQUESTED_BY = "sample";
    
    private static final String VALID_DOC_ID = "789";

    protected static final String EMAIL_FAILED = "N";

    protected static final String EMAIL_SUCCESS = "Y";

    @Mock
    private CustomerCommunicationRequest request;
    @Before
    public void setUp() throws Exception {
        initMocks(this);
        Logger.getRootLogger().addAppender(mockAppender);
        ArgumentCaptor.forClass(LoggingEvent.class);
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testEmailRequest() {

        EmailRequest request = new EmailRequest();
        request.setAccountNumber("1234");
        request.setActivityDescription("activity");
        request.setCustomerNumber("1234");
        request.setDocId("DOCID");
        Map<String, String> param = new HashMap<String, String>();
        param.put("123", "234");

        request.setParameters(param);
        request.setRequestedBy("jggkjg");
        request.setWritingActivity(false);
        request.setInteractionId("1234");

        assertNotNull(request.getAccountNumber());
        assertNotNull(request.getActivityDescription());
        assertNotNull(request.getCustomerNumber());
        assertNotNull(request.getDocId());
        assertNotNull(request.getInteractionId());
        assertNotNull(request.getParameters());
        assertNotNull(request.getRequestedBy());
        assertNotNull(request.getParameters());
        assertFalse(request.isWritingActivity());
    }
    
    @Test
    public void testEmailRequestParamsNull() {

        EmailRequest request = new EmailRequest();
        request.setAccountNumber("1234");
        request.setActivityDescription("activity");
        request.setCustomerNumber("1234");
        request.setDocId("DOCID");
        Map<String, String> param = null;

        request.setParameters(param);
        request.setRequestedBy("jggkjg");
        request.setWritingActivity(false);
        request.setInteractionId("1234");

        assertNotNull(request.getAccountNumber());
        assertNotNull(request.getActivityDescription());
        assertNotNull(request.getCustomerNumber());
        assertNotNull(request.getDocId());
        assertNotNull(request.getInteractionId());
        assertNotNull(request.getParameters());
        assertNotNull(request.getRequestedBy());
        assertEquals(request.getParameters(), MapUtils.EMPTY_MAP);
        assertFalse(request.isWritingActivity());
    }

    @Test
    public void testEmailSendSucessRequestWritingAcitivitySuccess() {
        String emailStatus = EMAIL_SUCCESS;

        EmailRequest request = mock(EmailRequest.class);
        when(request.isWritingActivity()).thenReturn(true);
        CustomerCommunicationRequest cccRequest = mock(CustomerCommunicationRequest.class);

        Exception actualException = null;
        CustomerCommunicationResult customerCommunicationResult = mock(CustomerCommunicationResult.class);

        when(dgwCustomerCommunicationDAO.sendCustomerCommunication(cccRequest)).thenReturn(customerCommunicationResult);
      
        try {
            emailSender.send(request);
        } catch (Exception e) {
            actualException = e;
            emailStatus = EMAIL_FAILED;
        }
        
        when(customerCommunicationResult.isCorrespondenceSuccess()).thenReturn(true);

        ArgumentCaptor<String> captureDocumentId = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureEmailStatus = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureEmailActivityDesc = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureDateActivityInteractionId = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureDateActivityCustomerNumber = ArgumentCaptor.forClass(String.class);

        doNothing().when(emailNotificationActivity).write(captureDocumentId.capture(), captureEmailStatus.capture(),
                captureDateActivityCustomerNumber.capture(), captureDateActivityInteractionId.capture(),
                captureEmailActivityDesc.capture());

        assertEquals(request.isWritingActivity(), true);
        assertNull(actualException);
        assertEquals(emailStatus.equals(EMAIL_SUCCESS), true);
    }
    
    
    //@Test
    public void testEmailSendSucessRequestWritingAcitivityException() {
        String emailStatus = EMAIL_SUCCESS;

        EmailRequest request = mock(EmailRequest.class);
        when(request.isWritingActivity()).thenReturn(true);
        CustomerCommunicationRequest cccRequest = mock(CustomerCommunicationRequest.class);

        Exception actualException = null;
        CustomerCommunicationResult customerCommunicationResult = mock(CustomerCommunicationResult.class);

        when(dgwCustomerCommunicationDAO.sendCustomerCommunication(cccRequest)).thenThrow(new RuntimeException());
      
        try {
            emailSender.send(request);
        } catch (Exception e) {
            actualException = e;
            emailStatus = EMAIL_FAILED;
        }
        
        when(customerCommunicationResult.isCorrespondenceSuccess()).thenReturn(true);

        ArgumentCaptor<String> captureDocumentId = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureEmailStatus = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureEmailActivityDesc = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureDateActivityInteractionId = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureDateActivityCustomerNumber = ArgumentCaptor.forClass(String.class);

        doNothing().when(emailNotificationActivity).write(captureDocumentId.capture(), captureEmailStatus.capture(),
                captureDateActivityCustomerNumber.capture(), captureDateActivityInteractionId.capture(),
                captureEmailActivityDesc.capture());

        assertEquals(request.isWritingActivity(), true);
        assertNull(actualException);
        assertEquals(emailStatus.equals(EMAIL_SUCCESS), true);
    }

    @Test
    public void testEmailSendSucessRequestWritingAcitivityFail() {
        String emailStatus = EMAIL_SUCCESS;

        EmailRequest request = mock(EmailRequest.class);
        CustomerCommunicationRequest cccRequest = mock(CustomerCommunicationRequest.class);

        Exception actualException = null;
        CustomerCommunicationResult customerCommunicationResult = mock(CustomerCommunicationResult.class);

        when(dgwCustomerCommunicationDAO.sendCustomerCommunication(cccRequest)).thenReturn(customerCommunicationResult);

        try {
            emailSender.send(request);
        } catch (Exception e) {
            actualException = e;
            emailStatus = EMAIL_FAILED;
        }

        ArgumentCaptor<String> captureDocumentId = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureEmailStatus = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureEmailActivityDesc = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureDateActivityInteractionId = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureDateActivityCustomerNumber = ArgumentCaptor.forClass(String.class);

        doNothing().when(emailNotificationActivity).write(captureDocumentId.capture(), captureEmailStatus.capture(),
                captureDateActivityCustomerNumber.capture(), captureDateActivityInteractionId.capture(),
                captureEmailActivityDesc.capture());

        assertEquals(emailStatus, (EMAIL_SUCCESS));
        assertNull(actualException);
        assertEquals(request.isWritingActivity(), false);
        verify(customerCommunicationResult, times(0)).isCorrespondenceSuccess();
    }

    @Test
    public void testEmailSendSucessRequestWritingAcitivitySuccessEmailStatusFail() {
        String emailStatus = EMAIL_FAILED;

        EmailRequest request = mock(EmailRequest.class);
        when(request.isWritingActivity()).thenReturn(true);
        CustomerCommunicationRequest cccRequest = mock(CustomerCommunicationRequest.class);

        Exception actualException = null;
        CustomerCommunicationResult customerCommunicationResult = mock(CustomerCommunicationResult.class);

        when(dgwCustomerCommunicationDAO.sendCustomerCommunication(cccRequest)).thenReturn(customerCommunicationResult);
        try {
            emailSender.send(request);
        } catch (Exception e) {
            actualException = e;
            emailStatus = EMAIL_FAILED;
        }

        when(customerCommunicationResult.isCorrespondenceSuccess()).thenReturn(true);
        ArgumentCaptor<String> captureDocumentId = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureEmailStatus = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureEmailActivityDesc = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureDateActivityInteractionId = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureDateActivityCustomerNumber = ArgumentCaptor.forClass(String.class);

        doNothing().when(emailNotificationActivity).write(captureDocumentId.capture(), captureEmailStatus.capture(),
                captureDateActivityCustomerNumber.capture(), captureDateActivityInteractionId.capture(),
                captureEmailActivityDesc.capture());

        // verify(emailNotificationActivity, times(1)).write(captureDocumentId.capture(),
        // captureEmailStatus.capture(),captureDateActivityCustomerNumber.capture(),captureDateActivityInteractionId.capture(),
        // captureDateActivityOperatorId.capture(),captureEmailActivityDesc.capture());
        verify(customerCommunicationResult, times(0)).isCorrespondenceSuccess();

        assertNotNull(customerCommunicationResult);
        assertEquals(request.isWritingActivity(), true);
        assertNull(actualException);
        assertEquals(emailStatus.equals(EMAIL_FAILED), true);
    }

    @Test
    public void testEmailSendSucessRequestWritingAcitivitySuccessCommResultNull() {
        String emailStatus = EMAIL_SUCCESS;

        EmailRequest request = mock(EmailRequest.class);
        when(request.isWritingActivity()).thenReturn(true);
        CustomerCommunicationRequest cccRequest = mock(CustomerCommunicationRequest.class);

        Exception actualException = null;
        when(dgwCustomerCommunicationDAO.sendCustomerCommunication(cccRequest)).thenReturn(null);
        try {
            emailSender.send(request);
        } catch (Exception e) {
            actualException = e;
            emailStatus = EMAIL_FAILED;
        }

        ArgumentCaptor<String> captureDocumentId = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureEmailStatus = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureEmailActivityDesc = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureDateActivityInteractionId = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureDateActivityCustomerNumber = ArgumentCaptor.forClass(String.class);

        doNothing().when(emailNotificationActivity).write(captureDocumentId.capture(), captureEmailStatus.capture(),
                captureDateActivityCustomerNumber.capture(), captureDateActivityInteractionId.capture(),
                captureEmailActivityDesc.capture());

        assertEquals(request.isWritingActivity(), true);
        assertNull(actualException);
        assertEquals(emailStatus.equals(EMAIL_SUCCESS), true);
    }

    @Test
    public void testBuildCustomerParametersValidEmailAddresses() {
        ArgumentCaptor<String> custDetailCaptor = ArgumentCaptor.forClass(String.class);

        CustomerDetail customerDetail = mock(CustomerDetail.class);

        Email email = mock(Email.class);
        ArrayList emailList = mock(ArrayList.class);
        emailList.add(email);

        when(customerDetail.getEmailAddresses()).thenReturn(emailList);
        when(customerDetail.getEmailAddresses().get(0)).thenReturn(email);

        when(customerDetail.getCustomerId()).thenReturn(VALID_CUST_ID);
        when(customerDetail.getFirstName()).thenReturn(VALID_CUST_NAME);
        when(customerDetailsDao.getCustomerDetail(custDetailCaptor.capture())).thenReturn(customerDetail);

        Map<String, String> parameters = emailSender.buildCustomerParameters(VALID_CUST_NUMBER);
        String captureEmail = customerDetail.getEmailAddresses().get(0).getEmailAddress();
        String custDetailResponse = custDetailCaptor.getAllValues().get(0);

        verify(customerDetail, times(5)).getEmailAddresses();
        verify(customerDetail, times(1)).getCustomerId();
        verify(customerDetail, times(1)).getFirstName();
        verify(customerDetailsDao, times(1)).getCustomerDetail(any(String.class));

        assertEquals(captureEmail, parameters.get(PARAM_EMAIL));
        assertEquals(parameters.get(PARAM_FIRST_NAME), VALID_CUST_NAME);
        assertEquals(parameters.get(PARAM_CLIENTID), VALID_CUST_ID);
        assertNotEquals(customerDetail.getEmailAddresses().get(0), null);
        assertEquals(customerDetail.getEmailAddresses(), emailList);
        assertEquals(custDetailResponse, VALID_CUST_NUMBER);
        
        emailSender.buildParameterMap(VALID_CUST_NUMBER, parameters);
        
        CustomerCommunicationRequest returnedRequest = emailSender.buildCustomerCommunicationRequest(VALID_ACCT_NUMBER, VALID_CUST_NUMBER, VALID_REQUESTED_BY,  VALID_DOC_ID, parameters);
    
        assertEquals(VALID_ACCT_NUMBER, returnedRequest.getAccountNumber());
        assertEquals(VALID_CUST_NUMBER, returnedRequest.getCustomerNumber().toString());
        assertEquals(VALID_REQUESTED_BY, returnedRequest.getRequestedBy());
        assertEquals(VALID_DOC_ID, returnedRequest.getDocumentTemplateId());
        assertEquals(3, returnedRequest.getParameterMap().size());
        assertEquals(VALID_CUST_NAME, returnedRequest.getParameterMap().get(PARAM_FIRST_NAME));
        assertEquals(VALID_CUST_ID, returnedRequest.getParameterMap().get(PARAM_CLIENTID));
    }

    @Test
    public void testBuildCustomerParametersNullEmailAddress() {
        ArgumentCaptor<String> custDetailCaptor = ArgumentCaptor.forClass(String.class);

        CustomerDetail customerDetail = mock(CustomerDetail.class);
        when(customerDetail.getEmailAddresses()).thenReturn(null);
        when(customerDetail.getCustomerId()).thenReturn(VALID_CUST_ID);
        when(customerDetail.getFirstName()).thenReturn(VALID_CUST_NAME);
        when(customerDetailsDao.getCustomerDetail(custDetailCaptor.capture())).thenReturn(customerDetail);

        Map<String, String> parameters = emailSender.buildCustomerParameters(VALID_CUST_NUMBER);

        verify(customerDetail, times(1)).getEmailAddresses();
        verify(customerDetail, times(1)).getCustomerId();
        verify(customerDetail, times(1)).getFirstName();
        verify(customerDetailsDao, times(1)).getCustomerDetail(any(String.class));

        assertEquals(parameters.get(PARAM_EMAIL), null);
        assertEquals(parameters.get(PARAM_FIRST_NAME), VALID_CUST_NAME);
        assertEquals(parameters.get(PARAM_CLIENTID), VALID_CUST_ID);
        assertEquals(customerDetail.getEmailAddresses(), null);

        String custDetailResponse = custDetailCaptor.getAllValues().get(0);
        assertEquals(custDetailResponse, VALID_CUST_NUMBER);
    }

    @Test
    public void testBuildCustomerParametersNullEmailAddressGet0() {
        ArgumentCaptor<String> custDetailCaptor = ArgumentCaptor.forClass(String.class);

        CustomerDetail customerDetail = mock(CustomerDetail.class);

        Email email = new Email();
        ArrayList emailList = mock(ArrayList.class);
        emailList.add(null);
        emailList.add(email);

        when(customerDetail.getEmailAddresses()).thenReturn(emailList);
        when(customerDetail.getCustomerId()).thenReturn(VALID_CUST_ID);
        when(customerDetail.getFirstName()).thenReturn(VALID_CUST_NAME);
        when(customerDetailsDao.getCustomerDetail(custDetailCaptor.capture())).thenReturn(customerDetail);

        Map<String, String> parameters = emailSender.buildCustomerParameters(VALID_CUST_NUMBER);

        verify(customerDetail, times(2)).getEmailAddresses();
        verify(customerDetail, times(1)).getCustomerId();
        verify(customerDetail, times(1)).getFirstName();
        verify(customerDetailsDao, times(1)).getCustomerDetail(any(String.class));

        assertEquals(parameters.get(PARAM_EMAIL), null);
        assertEquals(parameters.get(PARAM_FIRST_NAME), VALID_CUST_NAME);
        assertEquals(parameters.get(PARAM_CLIENTID), VALID_CUST_ID);
        assertEquals(customerDetail.getEmailAddresses().get(0), null);
        assertEquals(customerDetail.getEmailAddresses(), emailList);

        String custDetailResponse = custDetailCaptor.getAllValues().get(0);
        assertEquals(custDetailResponse, VALID_CUST_NUMBER);
    }

}
