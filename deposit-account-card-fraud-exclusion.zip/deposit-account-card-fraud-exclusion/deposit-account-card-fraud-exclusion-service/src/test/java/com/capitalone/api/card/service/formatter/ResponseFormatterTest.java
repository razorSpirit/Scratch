package com.capitalone.api.card.service.formatter;

import static org.junit.Assert.*;
import static org.mockito.MockitoAnnotations.initMocks;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;

import com.capitalone.api.card.model.v3.FraudExclusionRetrievalResponse;
import com.capitalone.api.card.model.v3.ServicingNoteFormat;
import com.capitalone.api.card.service.dto.ParsedDatesAndNotes;
import com.capitalone.api.card.service.dto.ParsedNote;

public class ResponseFormatterTest {
	
	@InjectMocks
	private ResponseFormatter responseFormatter;
	

    private static final String EXCLUSION_START_DATE = "2015-08-21";

    private static final String EXCLUSION_END_DATE = "2015-08-22";

    private static final String NOTE_START_DATE = "08/21/15";

    private static final String NOTE_END_DATE = "08/22/15";

    private static final String NOTE_CARD_ACTION_TYPE = "TRAVLNOTE";

    private static final String NOTE_TEXT = "Travelling to Europe";


	@Before
    public void setUp() throws Exception {
        initMocks(this);
    }

	@Test
	public void testFormat() {
		
		ParsedDatesAndNotes parsedDatesAndNotes = new ParsedDatesAndNotes();
        parsedDatesAndNotes.setExclusionStartDate(EXCLUSION_START_DATE);
        parsedDatesAndNotes.setExclusionEndDate(EXCLUSION_END_DATE);

        List<ParsedNote> lst = new ArrayList<ParsedNote>();

        ParsedNote p1 = new ParsedNote();
        p1.setLineNumber(1);
        p1.setNoteCardActionType(NOTE_CARD_ACTION_TYPE);
        p1.setNoteStartDate(NOTE_START_DATE);
        p1.setNoteEndDate(NOTE_END_DATE);
        p1.setNote(NOTE_TEXT); 

        lst.add(p1);
        parsedDatesAndNotes.setParsedNote(lst);
        assertEquals(parsedDatesAndNotes.toString(), "2015-08-212015-08-222015-08-221");
        
		FraudExclusionRetrievalResponse response = responseFormatter.format(parsedDatesAndNotes,ServicingNoteFormat.ALL);
		assertNotNull(response);
		
		response = responseFormatter.format(parsedDatesAndNotes,ServicingNoteFormat.LATEST);
		assertNotNull(response);
		
		response = responseFormatter.format(parsedDatesAndNotes,ServicingNoteFormat.HISTORY);
		assertNotNull(response);
		
	    response = responseFormatter.format(parsedDatesAndNotes,ServicingNoteFormat.NONOTIFICATIONS);
		assertNotNull(response);
		
		response = responseFormatter.format(parsedDatesAndNotes,ServicingNoteFormat.NONE);
		assertNull(response);
		
		
	}

}