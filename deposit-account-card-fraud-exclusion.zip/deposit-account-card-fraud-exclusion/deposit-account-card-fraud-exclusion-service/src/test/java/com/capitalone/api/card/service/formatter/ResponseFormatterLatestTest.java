package com.capitalone.api.card.service.formatter;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Appender;
import org.apache.log4j.Logger;
import org.junit.After;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.util.Assert;

import com.capitalone.api.card.model.v3.CardActionType;
import com.capitalone.api.card.model.v3.FraudExclusionRetrievalResponse;
import com.capitalone.api.card.model.v3.ServicingNoteFormat;
import com.capitalone.api.card.service.dto.ParsedDatesAndNotes;
import com.capitalone.api.card.service.dto.ParsedNote;

public class ResponseFormatterLatestTest {

    @InjectMocks
    private ResponseFormatterLatest responseFormatter;

    @Mock
    private Appender mockAppender;

    private static final String EXCLUSION_START_DATE = "2015-08-21";

    private static final String EXCLUSION_END_DATE = "2015-08-22";

    private static final String NOTE_START_DATE = "08/21/15";

    private static final String NOTE_END_DATE = "08/22/15";

    private static final String NOTE_CARD_ACTION_TYPE = "TRAVLNOTE";

    private static final String NOTE_TEXT = "Travelling to Europe";

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        Logger.getRootLogger().addAppender(mockAppender);
    }

    @After
    public void tearDown() throws Exception {
        responseFormatter = null;
    }

    @Test
    public void ResponseForFormatLatestForHappyPath() {

        ParsedDatesAndNotes parsedDatesAndNotes = new ParsedDatesAndNotes();
        parsedDatesAndNotes.setExclusionStartDate(EXCLUSION_START_DATE);
        parsedDatesAndNotes.setExclusionEndDate(EXCLUSION_END_DATE);

        List<ParsedNote> lst = new ArrayList<ParsedNote>();

        ParsedNote p1 = new ParsedNote();
        p1.setLineNumber(1);
        p1.setNoteCardActionType(NOTE_CARD_ACTION_TYPE);
        p1.setNoteStartDate(NOTE_START_DATE);
        p1.setNoteEndDate(NOTE_END_DATE);
        p1.setNote(NOTE_TEXT); 

        lst.add(p1);
        parsedDatesAndNotes.setParsedNote(lst);

        FraudExclusionRetrievalResponse response = responseFormatter.format(parsedDatesAndNotes);

        assertEquals(EXCLUSION_START_DATE, response.getExclusionStartDate());
        assertEquals(EXCLUSION_END_DATE, response.getExclusionEndDate());
        assertEquals(ServicingNoteFormat.LATEST, response.getServicingNoteFormat());
        assertEquals(CardActionType.TRAVEL_NOTIFICATION, response.getCardActionCode());
        assertEquals(1, response.getServicingNotes().get(0).getServicingNotesLineNumber());
        assertEquals(NOTE_TEXT, response.getServicingNotes().get(0).getServicingNote());
        assertNull(response.getHistory());
    }

    @Test
    public void createResponseForLatestFormatWhenFraudStEndDtAreNull() {
    	 ParsedDatesAndNotes parsedDatesAndNotes =  Mockito.mock(ParsedDatesAndNotes.class);
    	 parsedDatesAndNotes.setExclusionStartDate(null);
         parsedDatesAndNotes.setExclusionEndDate(null);
        
    	 FraudExclusionRetrievalResponse response =responseFormatter.format(parsedDatesAndNotes);
    	
    	 assertEquals(null, response.getExclusionStartDate());
         assertEquals(null, response.getExclusionEndDate()); 
         assertEquals(ServicingNoteFormat.ALL, response.getServicingNoteFormat());
         assertNull(response.getHistory());
    }
    
    @Test
    public void ResponseForFormatLatestWhenParsedNotesNull() {

        ParsedDatesAndNotes parsedDatesAndNotes = new ParsedDatesAndNotes();
        parsedDatesAndNotes.setExclusionStartDate(EXCLUSION_START_DATE);
        parsedDatesAndNotes.setExclusionEndDate(EXCLUSION_END_DATE);

        List<ParsedNote> lst = null;
        parsedDatesAndNotes.setParsedNote(lst);
        FraudExclusionRetrievalResponse response = responseFormatter.format(parsedDatesAndNotes);
 
        assertEquals(EXCLUSION_START_DATE, response.getExclusionStartDate());
        assertEquals(EXCLUSION_END_DATE, response.getExclusionEndDate());
        assertEquals(ServicingNoteFormat.ALL, response.getServicingNoteFormat());
        assertNull(response.getHistory());
    }  
    
    @Test
    public void ResponseForFormatLatestForDiffActionCode() {

        ParsedDatesAndNotes parsedDatesAndNotes = new ParsedDatesAndNotes();
        parsedDatesAndNotes.setExclusionStartDate(EXCLUSION_START_DATE);
        parsedDatesAndNotes.setExclusionEndDate(EXCLUSION_END_DATE);

        List<ParsedNote> lst = new ArrayList<ParsedNote>();

        ParsedNote p1 = new ParsedNote();
        p1.setLineNumber(1);
        p1.setNoteCardActionType("AFNOTICE");
        p1.setNoteStartDate(NOTE_START_DATE);
        p1.setNoteEndDate(NOTE_END_DATE);
        p1.setNote(NOTE_TEXT);

        ParsedNote p2 = new ParsedNote();
        p2.setLineNumber(2);
        p2.setNoteCardActionType(NOTE_CARD_ACTION_TYPE);
        p2.setNoteStartDate(NOTE_START_DATE);
        p2.setNoteEndDate(NOTE_END_DATE);
        p2.setNote(NOTE_TEXT);
        
        lst.add(p1);
        lst.add(p2);
        parsedDatesAndNotes.setParsedNote(lst); 

        FraudExclusionRetrievalResponse response = responseFormatter.format(parsedDatesAndNotes);

        assertEquals(EXCLUSION_START_DATE, response.getExclusionStartDate());
        assertEquals(EXCLUSION_END_DATE, response.getExclusionEndDate()); 
        assertEquals(ServicingNoteFormat.ALL, response.getServicingNoteFormat());
    }
 
     
    @Test(expected = NullPointerException.class)  
    public void createTestForValidationFailure() { 
        ParsedDatesAndNotes parsedDatesAndNotes = null;
        when(responseFormatter.format(parsedDatesAndNotes)).thenReturn(null);
        verify(responseFormatter, times(1)).format(any(ParsedDatesAndNotes.class));
    }
    
    @Test
    public void testIsDifferentActionType() {
        ResponseFormatterLatest responseFormatter = new ResponseFormatterLatest();
        List<String> list = new ArrayList<String>();
        list.add("one");
        list.add("two");
        Assert.isTrue(!responseFormatter.isDifferentActionType(list, "one"));
        Assert.isTrue(responseFormatter.isDifferentActionType(list, "three"));
        
        list.clear();
        Assert.isTrue(!responseFormatter.isDifferentActionType(list, "one"));
    }
    
    
    @Test
    public void testGetMatchedParsedNotesList() {
        ResponseFormatterLatest responseFormatter = new ResponseFormatterLatest();
        
        ParsedDatesAndNotes parsedDatesAndNotes = new ParsedDatesAndNotes();
        parsedDatesAndNotes.setExclusionStartDate(EXCLUSION_START_DATE);
        parsedDatesAndNotes.setExclusionEndDate(EXCLUSION_END_DATE);

        List<ParsedNote> lst = new ArrayList<ParsedNote>();

        ParsedNote p1 = new ParsedNote();
        p1.setLineNumber(1);
        p1.setNoteCardActionType("AFNOTICE");
        p1.setNoteStartDate(NOTE_START_DATE);
        p1.setNoteEndDate(NOTE_END_DATE);
        p1.setNote(NOTE_TEXT);

        ParsedNote p2 = new ParsedNote();
        p2.setLineNumber(2);
        p2.setNoteCardActionType(NOTE_CARD_ACTION_TYPE);
        p2.setNoteStartDate(NOTE_START_DATE);
        p2.setNoteEndDate(NOTE_END_DATE);
        p2.setNote(NOTE_TEXT);
        
        ParsedNote p3 = new ParsedNote();
        p2.setLineNumber(2);
        p2.setNoteCardActionType(NOTE_CARD_ACTION_TYPE);
        p2.setNoteStartDate("08/22/15");
        p2.setNoteEndDate(NOTE_END_DATE);
        p2.setNote(NOTE_TEXT);
        
        ParsedNote p4 = new ParsedNote();
        p2.setLineNumber(2);
        p2.setNoteCardActionType(NOTE_CARD_ACTION_TYPE);
        p2.setNoteStartDate(NOTE_START_DATE);
        p2.setNoteEndDate("8/23/15");
        p2.setNote(NOTE_TEXT);
        
        lst.add(p1);
        lst.add(p2);
        lst.add(p3);
        lst.add(p4);
        parsedDatesAndNotes.setParsedNote(lst); 
        
        Assert.notNull(responseFormatter.getMatchedParsedNotesList(parsedDatesAndNotes));
        
        parsedDatesAndNotes.setParsedNote(null); 
        Assert.isTrue((responseFormatter.getMatchedParsedNotesList(parsedDatesAndNotes)).size()==0);
        
    }
}
