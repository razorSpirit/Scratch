package com.capitalone.api.card.service.util.validation;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.Appender;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.bank.lib.metavante.model.AcctInqResponse;
import com.capitalone.api.bank.lib.metavante.model.ArrayOfCardNumbers;
import com.capitalone.api.bank.lib.metavante.model.StatType;
import com.capitalone.api.bank.lib.profile.accounts.dao.ProfileAccountsDAO;
import com.capitalone.api.bank.lib.profile.accounts.dao.model.CardData;
import com.capitalone.api.card.model.v3.CardActionType;
import com.capitalone.api.card.model.v3.FraudExclusionRequest;
import com.capitalone.api.card.model.v3.FraudExclusionRetrievalRequest;
import com.capitalone.api.card.model.v3.ServicingNoteFormat;
import com.capitalone.api.card.service.constants.ErrorConstants;
import com.capitalone.api.card.service.dao.CardFraudExclusionDAO;
import com.capitalone.api.card.service.dto.Card;
import com.capitalone.api.card.service.util.card.CardFinder;
import com.capitalone.api.commons.exception.ApiErrorCode;
import com.capitalone.api.commons.exception.RequestValidationException;
import com.capitalone.api.commons.model.EntityRequest;
import com.capitalone.api.model.id.AccountReferenceId;
import com.capitalone.api.model.id.CardReferenceId;
import com.capitalone.api.model.id.ReferenceId;

public class CardFraudExclusionValidatorTest {

    public static final String YYYY_MM_DD = "yyyy-MM-dd";
    @InjectMocks
    private CardFraudExclusionValidator validator;

    @Mock
    private CardFraudExclusionDAO cardFraudExclusionDAO; 

    @Mock
    private ProfileAccountsDAO profileAccountsDAO;

    @Mock
    FraudExclusionRequest request;

    @Mock
    private ConversionService conversionService;

    @Mock
    private Appender mockAppender;

    @Mock
    private CardFinder cardFinder;
    
    private EntityRequest entityRequest = null;
    
    private static final String LAST_FOUR_OF_CARD = "6789";

    private static final String FIRST_SIX_OF_CARD = "123456";

    private static final String ACCOUNT_NUMBER = "000000001";

    private static final String CARD_NUMBER = "012345678910";    
      
    private static String FROM_DATE = "2016-01-01";

    private static String TO_DATE = "2016-02-01";

    private static final String CUSTOMER_NUMBER = "11";

    private static final String FIRST_NAME = "John";

    private static final String SORID = "905";

    private static final String BAD_CARD_STATE = "0";
    private static final String GOOD_CARD_STATE = "1";

    private static final String PROFILE_CARD_STATE_ENABLED = "1";
    
    private static final String PROFILE_CARD_STATE_ACTIVABLE = "2";
    
    private static final String PROFILE_CARD_STATE_NULL = null; 
    
    private static final String METAVANTE_INACTIVE_CARD_STAUS = "0";
    
    private static final String METAVANTE_ACTIVE_GOOD_CARD_STATE = "1";
    
    

    private static final long SUCCESSFUL_STAT_TYPE_CODE = 0l;

    private static final String INTERACTION_ID = "1234567";

    private static final String USER_ID = "zxy3497";
    
    @Before
    public void setUp() throws Exception {
        initMocks(this);
        Logger.getRootLogger().addAppender(mockAppender);
        entityRequest = new EntityRequest();
        entityRequest.setClientCorrelationId(INTERACTION_ID);
        entityRequest.setUserId(USER_ID);
    }

    @After
    public void tearDown() throws Exception {
        validator = null;
        entityRequest = null;
    }

	// ================================ ACCOUNT REFERENCE ID SECTION ==================================

    @Test
    public void testValidateAccountReferenceIdForBlankSourceId() {

        RequestValidationException actualException = null;

        try {
            validator.validateAccountReferenceId("", ACCOUNT_NUMBER);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_SOURCE_ID_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_SOURCE_ID_INVALID, apiError.getMessagePropertyKey());

    }
    
    @Test(expected=RequestValidationException.class)
    public void testValidateEntityRequestNegative() {
        EntityRequest entityRequestLocal = new EntityRequest();
        
        validator.validateEntityRequest(entityRequestLocal);
    }
    
    @Test
    public void testValidateAccountReferenceIdNegative1() {
        try {
        validator.validateAccountReferenceId("185","A00000001");
        } catch(RequestValidationException rve) {
            
        }
    }
    
    
    @Test(expected=RequestValidationException.class)
    public void testValidateAccountReferenceIdNegative2() {
        validator.validateAccountReferenceId("a185","00000001");
    }
    
    
    @Test(expected=RequestValidationException.class)
    public void testValidateAccountReferenceIdNegative3() {
        validator.validateAccountReferenceId("185","");
    }
    
    @Test(expected=RequestValidationException.class)
    public void testValidateAccountReferenceIdNegative4() {
        validator.validateAccountReferenceId("","00000001");
    }

    @Test
    public void testValidateAccountReferenceIdForNullSourceId() {

        RequestValidationException actualException = null;

        try {
            validator.validateAccountReferenceId(null, ACCOUNT_NUMBER);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_SOURCE_ID_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_SOURCE_ID_INVALID, apiError.getMessagePropertyKey());

    }

    @Test
    public void testValidateAccountReferenceIdForBadSourceRegEx() {

        RequestValidationException actualException = null;

        try {
            validator.validateAccountReferenceId("abc", ACCOUNT_NUMBER);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_SOURCE_ID_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_SOURCE_ID_INVALID, apiError.getMessagePropertyKey());

    }

    @Test
    public void testValidateAccountReferenceIdForBadAccountRegEx() {

        RequestValidationException actualException = null;

        try {
            validator.validateAccountReferenceId(SORID, "abc");
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_ACCOUNT_ID_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_ACCOUNT_ID_INVALID, apiError.getMessagePropertyKey());

    }

    @Test
    public void testValidateAccountReferenceIdForBlankAccount() {

        RequestValidationException actualException = null;

        try {
            validator.validateAccountReferenceId(SORID, "");
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_ACCOUNT_ID_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_ACCOUNT_ID_INVALID, apiError.getMessagePropertyKey());

    }

    @Test
    public void testValidateAccountReferenceIdForNullAccount() {

        RequestValidationException actualException = null;

        try {
            validator.validateAccountReferenceId(SORID, null);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_ACCOUNT_ID_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_ACCOUNT_ID_INVALID, apiError.getMessagePropertyKey());

    }

    @Test
    public void testValidateAccountReferenceIdSuccess() {

        validator.validateAccountReferenceId(SORID, ACCOUNT_NUMBER);

    }
    
	// ================================ CARD REFERENCE ID SECTION ==================================
    @Test
    public void testValidateCardReferenceIdForNullAccount() {

        RequestValidationException actualException = null;

        try {
            validator.validateCardReferenceId(SORID, null, FIRST_SIX_OF_CARD, LAST_FOUR_OF_CARD);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_ACCOUNT_ID_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_ACCOUNT_ID_INVALID, apiError.getMessagePropertyKey());

    }
    
    @Test
    public void testValidateCardReferenceIdForBlankAccount() {

        RequestValidationException actualException = null;

        try {
            validator.validateCardReferenceId(SORID, "", FIRST_SIX_OF_CARD, LAST_FOUR_OF_CARD);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_ACCOUNT_ID_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_ACCOUNT_ID_INVALID, apiError.getMessagePropertyKey());

    }

    @Test
    public void testValidateCardReferenceIdForBadAccountRegEx() {

        RequestValidationException actualException = null;

        try {
            validator.validateCardReferenceId(SORID, "abc", FIRST_SIX_OF_CARD, LAST_FOUR_OF_CARD);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_ACCOUNT_ID_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_ACCOUNT_ID_INVALID, apiError.getMessagePropertyKey());

    }

    @Test
    public void testValidateCardReferenceIdForBlankSource() {

        RequestValidationException actualException = null;

        try {
            validator.validateCardReferenceId(null, ACCOUNT_NUMBER, FIRST_SIX_OF_CARD, LAST_FOUR_OF_CARD);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_SOURCE_ID_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_SOURCE_ID_INVALID, apiError.getMessagePropertyKey());

    }

    @Test
    public void testValidateCardReferenceIdForBadSourceRegEx() {

        RequestValidationException actualException = null;

        try {
            validator.validateCardReferenceId("abc", ACCOUNT_NUMBER, FIRST_SIX_OF_CARD, LAST_FOUR_OF_CARD);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_SOURCE_ID_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_SOURCE_ID_INVALID, apiError.getMessagePropertyKey());

    }

    @Test
    public void testValidateCardReferenceIdForBlankFirstSix() {

        RequestValidationException actualException = null;

        try {
            validator.validateCardReferenceId(SORID, ACCOUNT_NUMBER, null, LAST_FOUR_OF_CARD);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_CARD_FIRST6_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_CARD_FIRST6_INVALID, apiError.getMessagePropertyKey());

    }

    @Test
    public void testValidateCardReferenceIdForBadFirstSixRegEx() {

        RequestValidationException actualException = null;

        try {
            validator.validateCardReferenceId(SORID, ACCOUNT_NUMBER, "abc", LAST_FOUR_OF_CARD);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_CARD_FIRST6_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_CARD_FIRST6_INVALID, apiError.getMessagePropertyKey());

    }

    @Test
    public void testValidateCardReferenceIdForBlankLastFour() {

        RequestValidationException actualException = null;

        try {
            validator.validateCardReferenceId(SORID, ACCOUNT_NUMBER, FIRST_SIX_OF_CARD, "");
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_CARD_LAST4_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_CARD_LAST4_INVALID, apiError.getMessagePropertyKey());

    }

    @Test
    public void testValidateCardReferenceIdForBadLastFourRegEx() {

        RequestValidationException actualException = null;

        try {
            validator.validateCardReferenceId(SORID, ACCOUNT_NUMBER, FIRST_SIX_OF_CARD, "abc");
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_CARD_LAST4_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_CARD_LAST4_INVALID, apiError.getMessagePropertyKey());

    }

    @Test
    public void testValidateCardReferenceIdForSuccess() {

        validator.validateCardReferenceId(SORID, ACCOUNT_NUMBER, FIRST_SIX_OF_CARD, LAST_FOUR_OF_CARD);

    }
    
	// ================================ DATES SECTION ==================================
    @Test
    public void testValidateFraudExclusionDatesBlankFromDate() {

        RequestValidationException actualException = null;
        try {
            validator.validateFraudExclusionDates("", TO_DATE, CardActionType.TRAVEL_NOTIFICATION);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_FROM_DT_BLANK, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_FROM_DT_BLANK, apiError.getMessagePropertyKey());
    }

    @Test
    public void testValidateFraudExclusionDatesBadFromDateRegEx() {

        RequestValidationException actualException = null;

        try {
            validator.validateFraudExclusionDates("abc", TO_DATE, CardActionType.TRAVEL_NOTIFICATION);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_FROM_DT_FORMAT_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_FROM_DT_FORMAT_INVALID, apiError.getMessagePropertyKey());
    }

    @Test
    public void testValidateFraudExclusionDatesBlankToDate() {

        RequestValidationException actualException = null;

        try {
            validator.validateFraudExclusionDates(FROM_DATE, "", CardActionType.TRAVEL_NOTIFICATION);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_TO_DT_BLANK, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_TO_DT_BLANK, apiError.getMessagePropertyKey());
    }

    @Test
    public void testValidateFraudExclusionDatesBadToDateRegEx() {

        RequestValidationException actualException = null;

        try {
            validator.validateFraudExclusionDates(FROM_DATE, "abc", CardActionType.TRAVEL_NOTIFICATION);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_TO_DT_FORMAT_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_TO_DT_FORMAT_INVALID, apiError.getMessagePropertyKey());
    }

    @Test
    public void testValidateFraudExclusionDatesFromDateInPast() {

        FROM_DATE = DateFormatUtils.format(DateUtils.addMonths(new Date(),-1), YYYY_MM_DD);
        TO_DATE = DateFormatUtils.format(DateUtils.addMonths(new Date(),1), YYYY_MM_DD);

        RequestValidationException actualException = null;

        try {
            validator.validateFraudExclusionDates(FROM_DATE, TO_DATE, CardActionType.TRAVEL_NOTIFICATION);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_FROM_DT_PAST, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_FROM_DT_PAST, apiError.getMessagePropertyKey());
    }

    @Test
    public void testValidateFraudExclusionDatesToDateInPast() {

        RequestValidationException actualException = null;

        FROM_DATE = DateFormatUtils.format(DateUtils.addMonths(new Date(),0), YYYY_MM_DD);
        TO_DATE = DateFormatUtils.format(DateUtils.addMonths(new Date(),-1), YYYY_MM_DD);

        try {
            validator.validateFraudExclusionDates(FROM_DATE, TO_DATE, CardActionType.TRAVEL_NOTIFICATION);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_TO_DT_PAST, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_TO_DT_PAST, apiError.getMessagePropertyKey());
    }

    @Test
    public void testValidateFraudExclusionDatesToBeforeFromDate() {

        RequestValidationException actualException = null;
        FROM_DATE = DateFormatUtils.format(DateUtils.addMonths(new Date(),2), YYYY_MM_DD);
        TO_DATE = DateFormatUtils.format(DateUtils.addMonths(new Date(),1), YYYY_MM_DD);

        try {
            validator.validateFraudExclusionDates(FROM_DATE, TO_DATE, CardActionType.TRAVEL_NOTIFICATION);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_TO_DT_BEFORE, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_TO_DT_BEFORE, apiError.getMessagePropertyKey());
    }

    @Test
    public void testValidateFraudExclusionDatesTravelToDateTooFarAway() {

        RequestValidationException actualException = null;

        try {
            validator.validateFraudExclusionDates(FROM_DATE, "9999-09-09", CardActionType.TRAVEL_NOTIFICATION);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_TO_DT_AFTER, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_TO_DT_AFTER, apiError.getMessagePropertyKey());
    }

    @Test
    public void testValidateFraudExclusionDatesSuccess() {

        FROM_DATE = DateFormatUtils.format(DateUtils.addMonths(new Date(),0), YYYY_MM_DD);
        TO_DATE = DateFormatUtils.format(DateUtils.addMonths(new Date(),1), YYYY_MM_DD);

        validator.validateFraudExclusionDates(FROM_DATE, TO_DATE, CardActionType.TRAVEL_NOTIFICATION);
        validator.validateFraudExclusionDates(FROM_DATE, TO_DATE, CardActionType.ANTI_FRAUD_SERVICING);
        validator.validateFraudExclusionDates(FROM_DATE, TO_DATE, CardActionType.NONE);

    }
    
    @Test (expected = RequestValidationException.class)
    public void testValidateFraudExclusionDatesFailure1() {

        FROM_DATE = DateFormatUtils.format(DateUtils.addMonths(new Date(),0), YYYY_MM_DD);
        TO_DATE = DateFormatUtils.format(DateUtils.addMonths(new Date(),1), YYYY_MM_DD);

        validator.validateFraudExclusionDates("", TO_DATE, CardActionType.TRAVEL_NOTIFICATION);
       

    }
    
    @Test (expected = RequestValidationException.class)
    public void testValidateFraudExclusionDatesFailure2() {

        FROM_DATE = DateFormatUtils.format(DateUtils.addMonths(new Date(),0), YYYY_MM_DD);
        TO_DATE = DateFormatUtils.format(DateUtils.addMonths(new Date(),1), YYYY_MM_DD);
        validator.validateFraudExclusionDates("0000/00/00", TO_DATE, CardActionType.TRAVEL_NOTIFICATION);
    }
    
    @Test (expected = RequestValidationException.class)
    public void testValidateFraudExclusionDatesFailure3() {

        FROM_DATE = DateFormatUtils.format(DateUtils.addMonths(new Date(),0), YYYY_MM_DD);
        TO_DATE = DateFormatUtils.format(DateUtils.addMonths(new Date(),1), YYYY_MM_DD);
        validator.validateFraudExclusionDates(FROM_DATE, "", CardActionType.TRAVEL_NOTIFICATION);

    }
    
    @Test (expected = RequestValidationException.class)
    public void testValidateFraudExclusionDatesFailure4() {

        FROM_DATE = DateFormatUtils.format(DateUtils.addMonths(new Date(),0), YYYY_MM_DD);
        TO_DATE = DateFormatUtils.format(DateUtils.addMonths(new Date(),1), YYYY_MM_DD);
        validator.validateFraudExclusionDates(FROM_DATE, "0000/00/00", CardActionType.TRAVEL_NOTIFICATION);

    }
    
	// ================================ CARD SECTION ==================================
    
    @Test
    public void testCardForFISStatusInactiveAndProfileEnabled() {
    	testValidateCardForCardStatusNotActive(PROFILE_CARD_STATE_ENABLED,METAVANTE_INACTIVE_CARD_STAUS);
    }
    
    @Test (expected = RequestValidationException.class)
    public void testRetrieveCardFromMetavante() {
        ArrayOfCardNumbers metavanteCardData = null;
        ArgumentCaptor<String> captureAccountNumber = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureFirstSix = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureLastFour = ArgumentCaptor.forClass(String.class);
        when(cardFraudExclusionDAO.findCard(captureAccountNumber.capture(), captureFirstSix.capture(), captureLastFour.capture())).thenReturn(metavanteCardData);
        validator.retrieveCardFromMetavante(captureAccountNumber.capture(), captureFirstSix.capture(), captureLastFour.capture());
    }
    
    @Test
    public void testCardForFISStatusInactiveAndProfileActivable() {
    	testValidateCardForCardStatusNotActive(PROFILE_CARD_STATE_ACTIVABLE,METAVANTE_INACTIVE_CARD_STAUS);
    }
    
    @Test
    public void testCardForFISStatusInactiveAndProfileNull() {
    	testValidateCardForCardStatusNotActive(PROFILE_CARD_STATE_NULL,METAVANTE_INACTIVE_CARD_STAUS);
    }
    
   
    private void testValidateCardForCardStatusNotActive(String profileState,String metavanteCardStatus) {
        
        //* Metavante Card
        ArrayOfCardNumbers metavanteCardData = new ArrayOfCardNumbers();
        metavanteCardData.setCardNumber(CARD_NUMBER);

        ArgumentCaptor<String> captureAccountNumber = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureFirstSix = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureLastFour = ArgumentCaptor.forClass(String.class);
        
        when(cardFraudExclusionDAO.findCard(captureAccountNumber.capture(), captureFirstSix.capture(), captureLastFour.capture())).thenReturn(metavanteCardData);
        
        //* Metavante Account Inquiry
        StatType statTypeSuccess = new StatType();
        statTypeSuccess.setStatCd(SUCCESSFUL_STAT_TYPE_CODE);
        
        AcctInqResponse metavanteAccountResponse = new AcctInqResponse();
        metavanteAccountResponse.setCustID(CUSTOMER_NUMBER);
        metavanteAccountResponse.setStat(statTypeSuccess);
        
        ArgumentCaptor<String> captureCardNumber = ArgumentCaptor.forClass(String.class);
        
        when(cardFraudExclusionDAO.lookUpAccountByCardNumber(captureCardNumber.capture())).thenReturn(metavanteAccountResponse);
        
        //* Profile Card
        CardData profileCardData = new CardData();
        profileCardData.setFirst6Digits(FIRST_SIX_OF_CARD);
        profileCardData.setLast4Digits(LAST_FOUR_OF_CARD);
        profileCardData.setCardState(profileState);
        profileCardData.setMetavanteCardStatus(metavanteCardStatus);
        
        List<CardData> profileCards = new ArrayList<CardData>();
        profileCards.add(profileCardData);
        
        ArgumentCaptor<String> captureCustomerNumber = ArgumentCaptor.forClass(String.class);
        
        when(profileAccountsDAO.retrieveCardsData(captureCustomerNumber.capture())).thenReturn(profileCards);        
        
        //* Run the test
        RequestValidationException actualException = null;        
        CardReferenceId cardRefId = new CardReferenceId(ACCOUNT_NUMBER, SORID, FIRST_SIX_OF_CARD, LAST_FOUR_OF_CARD);

        try {
            validator.validateCard(cardRefId, true);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        //* verify the results
        
		verify(cardFraudExclusionDAO, times(1)).findCard(captureAccountNumber.capture(), captureFirstSix.capture(), captureLastFour.capture());
        assertEquals(ACCOUNT_NUMBER,captureAccountNumber.getValue());
        assertEquals(FIRST_SIX_OF_CARD,captureFirstSix.getValue());
        assertEquals(LAST_FOUR_OF_CARD,captureLastFour.getValue());

		verify(cardFraudExclusionDAO, times(1)).lookUpAccountByCardNumber(captureCardNumber.capture());
        assertEquals(CARD_NUMBER,captureCardNumber.getValue());
        
        verify(profileAccountsDAO, times(1)).retrieveCardsData(captureCustomerNumber.capture());
        assertEquals(CUSTOMER_NUMBER,captureCustomerNumber.getValue());                

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_CARD_STATUS_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_CARD_STATUS_INVALID, apiError.getMessagePropertyKey());
    }    

    @Test
    public void testValidateCardForCardEnabled() {
    	testValidateCardForSuccess(PROFILE_CARD_STATE_ENABLED);
    }
    
    @Test
    public void testValidateCardForCardActivable() {
    	testValidateCardForSuccess(PROFILE_CARD_STATE_ACTIVABLE);
    }
    
    @Test
    public void testValidateCardForNoStatus() {
    	testValidateCardForSuccess(PROFILE_CARD_STATE_NULL);
    }
    
    @Test
    public void testValidateCardForBadCard() {
    	testValidateCardforFailure(CARD_NUMBER,BAD_CARD_STATE);
    }
    	
    private void testValidateCardforFailure (String cardNumber, String dummyCardState) {

        //* Metavante Card
        ArrayOfCardNumbers metavanteCardData = new ArrayOfCardNumbers();
        metavanteCardData.setCardNumber(cardNumber);
        
        when(cardFraudExclusionDAO.findCard(any(String.class), any(String.class), any(String.class))).thenReturn(metavanteCardData);
        
        //* Metavante Account Inquiry
        StatType statTypeSuccess = new StatType();
        statTypeSuccess.setStatCd(SUCCESSFUL_STAT_TYPE_CODE);
        
        AcctInqResponse metavanteAccountResponse = new AcctInqResponse();
        metavanteAccountResponse.setCustID(CUSTOMER_NUMBER);
        metavanteAccountResponse.setStat(statTypeSuccess);
        
        when(cardFraudExclusionDAO.lookUpAccountByCardNumber(any(String.class))).thenReturn(metavanteAccountResponse);
        
        //* Profile Card
        CardData profileCardData = new CardData();
        profileCardData.setFirst6Digits(FIRST_SIX_OF_CARD);
        profileCardData.setLast4Digits(LAST_FOUR_OF_CARD);
        profileCardData.setCardState(dummyCardState);
        profileCardData.setMetavanteCardStatus(METAVANTE_ACTIVE_GOOD_CARD_STATE);
        
        List<CardData> profileCards = new ArrayList<CardData>();
        profileCards.add(profileCardData);
        
        when(profileAccountsDAO.retrieveCardsData(any(String.class))).thenReturn(profileCards);        
        
        //* Run the test
        RequestValidationException actualException = null;        
        CardReferenceId cardRefId = new CardReferenceId(ACCOUNT_NUMBER, SORID, FIRST_SIX_OF_CARD, LAST_FOUR_OF_CARD);

        try {
            validator.validateCard(cardRefId, true);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        //* verify the results
        
		verify(cardFraudExclusionDAO, times(1)).findCard(any(String.class), any(String.class), any(String.class));
		verify(cardFraudExclusionDAO, times(1)).lookUpAccountByCardNumber(any(String.class));
        verify(profileAccountsDAO, times(1)).retrieveCardsData(any(String.class));               

        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_CARD_STATUS_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_CARD_STATUS_INVALID, apiError.getMessagePropertyKey());
     }
    
    
    private void testValidateCardForSuccess(String dummyState) {
        //* Metavante Card
        ArrayOfCardNumbers metavanteCardData = new ArrayOfCardNumbers();
        metavanteCardData.setCardNumber(CARD_NUMBER);
        metavanteCardData.setFirstName(FIRST_NAME);
        metavanteCardData.setDebitCardStatusCode(new BigInteger(GOOD_CARD_STATE));
        
        when(cardFraudExclusionDAO.findCard(any(String.class), any(String.class), any(String.class))).thenReturn(metavanteCardData);
        
        //* Metavante Account Inquiry
        StatType statTypeSuccess = new StatType();
        statTypeSuccess.setStatCd(SUCCESSFUL_STAT_TYPE_CODE);
        
        AcctInqResponse metavanteAccountResponse = new AcctInqResponse();
        metavanteAccountResponse.setCustID(CUSTOMER_NUMBER);
        metavanteAccountResponse.setStat(statTypeSuccess);
        
        when(cardFraudExclusionDAO.lookUpAccountByCardNumber(any(String.class))).thenReturn(metavanteAccountResponse);
        
        //* Profile Card
        CardData profileCardData = new CardData();
        profileCardData.setFirst6Digits(FIRST_SIX_OF_CARD);
        profileCardData.setLast4Digits(LAST_FOUR_OF_CARD);
        profileCardData.setCardState(dummyState);
        profileCardData.setMetavanteCardStatus(GOOD_CARD_STATE);
        
        List<CardData> profileCards = new ArrayList<CardData>();
        profileCards.add(profileCardData);
        
        when(profileAccountsDAO.retrieveCardsData(any(String.class))).thenReturn(profileCards);        
        
        //* Run the test    
        CardReferenceId cardRefId = new CardReferenceId(ACCOUNT_NUMBER, SORID, FIRST_SIX_OF_CARD, LAST_FOUR_OF_CARD);

        Card card = validator.validateCard(cardRefId, true);

        //* verify the results
        
		verify(cardFraudExclusionDAO, times(1)).findCard(any(String.class), any(String.class), any(String.class));
		verify(cardFraudExclusionDAO, times(1)).lookUpAccountByCardNumber(any(String.class));
        verify(profileAccountsDAO, times(1)).retrieveCardsData(any(String.class));
        
        assertNotNull(card);
        assertEquals(FIRST_NAME, card.getFirstName());
        assertEquals(CUSTOMER_NUMBER, card.getCustomerNumber());
        //assertEquals(GOOD_CARD_STATE, card.getProfileState());
        //assertEquals(GOOD_CARD_STATE, card.getProfileStatus());    
        assertEquals(GOOD_CARD_STATE, String.valueOf(card.getMetavanteStatus()));
    }       

    @Test
    public void testValidateCardForCardNotFoundInMetavante() {
    	ArrayOfCardNumbers metavanteCardData = new ArrayOfCardNumbers();
        when(cardFraudExclusionDAO.findCard(any(String.class), any(String.class), any(String.class))).thenReturn(metavanteCardData);
        
        RequestValidationException actualException = null;

        ReferenceId refId = new ReferenceId.Builder().field(SORID, SORID).field("accountId", ACCOUNT_NUMBER)
                .field("fistSixId", FIRST_SIX_OF_CARD).field("lastFourId", LAST_FOUR_OF_CARD).build();
        CardReferenceId cardRefId = new CardReferenceId(refId);

        try {
            validator.validateCard(cardRefId, true);
        } catch (RequestValidationException exception) {
            actualException = exception;
        }

        verify(cardFraudExclusionDAO, times(1)).findCard(any(String.class), any(String.class), any(String.class));
        
        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_CARD_NOT_WITH_ACCOUNT, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_CARD_NOT_WITH_ACCOUNT, apiError.getMessagePropertyKey());
    }    

	// ================================ CARD ACTION CODE SECTION ==================================    
	@Test
	public void testValidateCardActionCodeForBlank() {
		RequestValidationException actualException = null;

		try {
			validator.validateCardActionCode("");
		} catch (RequestValidationException exception) {
			actualException = exception;
		}
        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_EXCLU_TYPE_BLANK, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_EXCLU_TYPE_BLANK, apiError.getMessagePropertyKey());
		
	}

	@Test
	public void testValidateCardActionCodeForBadCode() {
		RequestValidationException actualException = null;

		try {
			validator.validateCardActionCode("Bad");
		} catch (RequestValidationException exception) {
			actualException = exception;
		}
        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_EXCLU_TYPE_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_EXCLU_TYPE_INVALID, apiError.getMessagePropertyKey());		
	}
	
	@Test
	public void testValidateCardActionCodeForSuccess() {
		for (CardActionType cardActionType : CardActionType.values()) {
			if (! cardActionType.equals(CardActionType.NONE)) {
				validator.validateCardActionCode(cardActionType.getCode());
			}
		}
		
	}	

	// ================================ NOTE SECTION ==================================
	@Test
	public void testValidateNoteForBlank() {
		RequestValidationException actualException = null;

		try {
			validator.validateNote("");
		} catch (RequestValidationException exception) {
			actualException = exception;
		}
        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_NOTE_BLANK, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_NOTE_BLANK, apiError.getMessagePropertyKey());		
	}
	
	@Test
	public void testValidateNoteForInvalidLength() {
		RequestValidationException actualException = null;

		String note = StringUtils.repeat("*", CardFraudExclusionValidator.VALID_NOTE_LENGTH+1);
		
		try {
			validator.validateNote(note);
		} catch (RequestValidationException exception) {
			actualException = exception;
		}
        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_NOTE_INVALID_LEN, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_NOTE_INVALID_LEN, apiError.getMessagePropertyKey());		
	}

	@Test
	public void testValidateNoteForSuccess() {
		String note = StringUtils.repeat("*", CardFraudExclusionValidator.VALID_NOTE_LENGTH);		
		validator.validateNote(note);
	}
	
	// ================================ PATH PARMS SECTION ==================================
	@Test
	public void testValidatePathParmsForSuccess() {
        //* Metavante Card
        ArrayOfCardNumbers metavanteCardData = new ArrayOfCardNumbers();
        metavanteCardData.setCardNumber(CARD_NUMBER);
        metavanteCardData.setFirstName(FIRST_NAME);
        metavanteCardData.setDebitCardStatusCode(new BigInteger(GOOD_CARD_STATE));
        
        when(cardFraudExclusionDAO.findCard(any(String.class), any(String.class), any(String.class))).thenReturn(metavanteCardData);
        
        //* Metavante Account Inquiry
        StatType statTypeSuccess = new StatType();
        statTypeSuccess.setStatCd(SUCCESSFUL_STAT_TYPE_CODE);
        
        AcctInqResponse metavanteAccountResponse = new AcctInqResponse();
        metavanteAccountResponse.setCustID(CUSTOMER_NUMBER);
        metavanteAccountResponse.setStat(statTypeSuccess);
        
        when(cardFraudExclusionDAO.lookUpAccountByCardNumber(any(String.class))).thenReturn(metavanteAccountResponse);
        
        //* Profile Card
        CardData profileCardData = new CardData();
        profileCardData.setFirst6Digits(FIRST_SIX_OF_CARD);
        profileCardData.setLast4Digits(LAST_FOUR_OF_CARD);
        profileCardData.setCardState(GOOD_CARD_STATE);
        profileCardData.setMetavanteCardStatus(GOOD_CARD_STATE);
        
        List<CardData> profileCards = new ArrayList<CardData>();
        profileCards.add(profileCardData);
        
        when(profileAccountsDAO.retrieveCardsData(any(String.class))).thenReturn(profileCards);   
		AccountReferenceId accountRefId = new AccountReferenceId(ACCOUNT_NUMBER, SORID);
		CardReferenceId cardRefId = new CardReferenceId(ACCOUNT_NUMBER, SORID, FIRST_SIX_OF_CARD, LAST_FOUR_OF_CARD);

		//* run the test
		Card card = validator.validatePathParams(accountRefId, cardRefId, true);
		
		//* verify the results        
		verify(cardFraudExclusionDAO, times(1)).findCard(any(String.class), any(String.class), any(String.class));
		verify(cardFraudExclusionDAO, times(1)).lookUpAccountByCardNumber(any(String.class));
        verify(profileAccountsDAO, times(1)).retrieveCardsData(any(String.class)); 
        
        assertNotNull(card);
        assertEquals(FIRST_NAME, card.getFirstName());
        assertEquals(CUSTOMER_NUMBER, card.getCustomerNumber());
        assertEquals(GOOD_CARD_STATE, card.getProfileState());
        assertEquals(GOOD_CARD_STATE, card.getProfileStatus()); 
        assertEquals(GOOD_CARD_STATE, String.valueOf(card.getMetavanteStatus()));
	}
	// ================================ Form PARMS SECTION ==================================
	@Test
	public void testValidateFormParmsForSuccess() {
		FraudExclusionRequest request = new FraudExclusionRequest();

        FROM_DATE = DateFormatUtils.format(DateUtils.addMonths(new Date(),0), YYYY_MM_DD);
        TO_DATE = DateFormatUtils.format(DateUtils.addMonths(new Date(),1), YYYY_MM_DD);

		request.setExclusionStartDate(FROM_DATE);
		request.setExclusionEndDate(TO_DATE);
		request.setCardActionCode(CardActionType.TRAVEL_NOTIFICATION.getCode());
		request.setServicingNotes(StringUtils.repeat("*", CardFraudExclusionValidator.VALID_NOTE_LENGTH));
		
		validator.validateFormParams(request);		
	}
	
	// ================================ ValidateAndRetrieveCard with FraudExclusionRequest SECTION ==================================
	@Test
	public void testValidateAndRetrieveCardWithFraudExclusionRequest() {

        FROM_DATE = DateFormatUtils.format(DateUtils.addMonths(new Date(),0), YYYY_MM_DD);
        TO_DATE = DateFormatUtils.format(DateUtils.addMonths(new Date(),1), YYYY_MM_DD);

        //* Metavante Card
        ArrayOfCardNumbers metavanteCardData = new ArrayOfCardNumbers();
        metavanteCardData.setCardNumber(CARD_NUMBER);
        metavanteCardData.setFirstName(FIRST_NAME);
        metavanteCardData.setDebitCardStatusCode(new BigInteger(GOOD_CARD_STATE));
        
        when(cardFraudExclusionDAO.findCard(any(String.class), any(String.class), any(String.class))).thenReturn(metavanteCardData);
        
        //* Metavante Account Inquiry
        StatType statTypeSuccess = new StatType();
        statTypeSuccess.setStatCd(SUCCESSFUL_STAT_TYPE_CODE);
        
        AcctInqResponse metavanteAccountResponse = new AcctInqResponse();
        metavanteAccountResponse.setCustID(CUSTOMER_NUMBER);
        metavanteAccountResponse.setStat(statTypeSuccess);
        
        when(cardFraudExclusionDAO.lookUpAccountByCardNumber(any(String.class))).thenReturn(metavanteAccountResponse);
        
        //* Profile Card
        CardData profileCardData = new CardData();
        profileCardData.setFirst6Digits(FIRST_SIX_OF_CARD);
        profileCardData.setLast4Digits(LAST_FOUR_OF_CARD);
        profileCardData.setCardState(GOOD_CARD_STATE);
        profileCardData.setMetavanteCardStatus(GOOD_CARD_STATE);
        
        List<CardData> profileCards = new ArrayList<CardData>();
        profileCards.add(profileCardData);
        
        when(profileAccountsDAO.retrieveCardsData(any(String.class))).thenReturn(profileCards);   
		AccountReferenceId accountRefId = new AccountReferenceId(ACCOUNT_NUMBER, SORID);
		CardReferenceId cardRefId = new CardReferenceId(ACCOUNT_NUMBER, SORID, FIRST_SIX_OF_CARD, LAST_FOUR_OF_CARD);
		
		FraudExclusionRequest request = new FraudExclusionRequest();
		request.setAccountReferenceId(accountRefId);
		request.setCardReferenceId(cardRefId);
		request.setExclusionStartDate(FROM_DATE);
		request.setExclusionEndDate(TO_DATE);
		request.setCardActionCode(CardActionType.TRAVEL_NOTIFICATION.getCode());
		request.setServicingNotes(StringUtils.repeat("*", CardFraudExclusionValidator.VALID_NOTE_LENGTH));
		
		//* run the test
		Card card = validator.validateAndRetrieveCard(request, entityRequest);
		
		//* verify the results
		verify(cardFraudExclusionDAO, times(1)).findCard(any(String.class), any(String.class), any(String.class));
		verify(cardFraudExclusionDAO, times(1)).lookUpAccountByCardNumber(any(String.class));
        verify(profileAccountsDAO, times(1)).retrieveCardsData(any(String.class)); 
        
        assertNotNull(card);
        assertEquals(FIRST_NAME, card.getFirstName());
        assertEquals(CUSTOMER_NUMBER, card.getCustomerNumber());
        assertEquals(GOOD_CARD_STATE, card.getProfileState());
        assertEquals(GOOD_CARD_STATE, card.getProfileStatus()); 
        assertEquals(GOOD_CARD_STATE, String.valueOf(card.getMetavanteStatus()));
		
	}
	
	// ================================ ValidateAndRetrieveCard with FraudExclusionRetrievalRequest SECTION ==================================
	@Test
	public void testValidateAndRetrieveCardWithFraudExclusionRetrievalRequestForSuccess() {
		
        //* Metavante Card
        ArrayOfCardNumbers metavanteCardData = new ArrayOfCardNumbers();
        metavanteCardData.setCardNumber(CARD_NUMBER);
        metavanteCardData.setFirstName(FIRST_NAME);
        
        when(cardFraudExclusionDAO.findCard(any(String.class), any(String.class), any(String.class))).thenReturn(metavanteCardData);
        
        //* Metavante Account Inquiry
        StatType statTypeSuccess = new StatType();
        statTypeSuccess.setStatCd(SUCCESSFUL_STAT_TYPE_CODE);
        
        AcctInqResponse metavanteAccountResponse = new AcctInqResponse();
        metavanteAccountResponse.setCustID(CUSTOMER_NUMBER);
        metavanteAccountResponse.setStat(statTypeSuccess);
        
        when(cardFraudExclusionDAO.lookUpAccountByCardNumber(any(String.class))).thenReturn(metavanteAccountResponse);
        
        //* Profile Card
        CardData profileCardData = new CardData();
        profileCardData.setFirst6Digits(FIRST_SIX_OF_CARD);
        profileCardData.setLast4Digits(LAST_FOUR_OF_CARD);
        profileCardData.setCardState(GOOD_CARD_STATE);
        profileCardData.setMetavanteCardStatus(GOOD_CARD_STATE);
        
        List<CardData> profileCards = new ArrayList<CardData>();
        profileCards.add(profileCardData);
        
        when(profileAccountsDAO.retrieveCardsData(any(String.class))).thenReturn(profileCards);   
		AccountReferenceId accountRefId = new AccountReferenceId(ACCOUNT_NUMBER, SORID);
		CardReferenceId cardRefId = new CardReferenceId(ACCOUNT_NUMBER, SORID, FIRST_SIX_OF_CARD, LAST_FOUR_OF_CARD);

		FraudExclusionRetrievalRequest request = new FraudExclusionRetrievalRequest();
		request.setAccountReferenceId(accountRefId);
		request.setCardReferenceId(cardRefId);
		request.setServicingNotesFormat(ServicingNoteFormat.LATEST);
		
		//* run the test
		Card card = validator.validateAndRetrieveCard(request, entityRequest);
		
		//* verify the results
		verify(cardFraudExclusionDAO, times(1)).findCard(any(String.class), any(String.class), any(String.class));
		verify(cardFraudExclusionDAO, times(1)).lookUpAccountByCardNumber(any(String.class));
        verify(profileAccountsDAO, times(1)).retrieveCardsData(any(String.class)); 
        
        assertNotNull(card);
        assertEquals(FIRST_NAME, card.getFirstName());
        assertEquals(CUSTOMER_NUMBER, card.getCustomerNumber());
        assertEquals(GOOD_CARD_STATE, card.getProfileState());
        assertEquals(GOOD_CARD_STATE, card.getProfileStatus());        		
	}
	
	@Test
	public void testValidateAndRetrieveCardWithFraudExclusionRetrievalRequestForNoteFormatNONE() {
		FraudExclusionRetrievalRequest request = new FraudExclusionRetrievalRequest();
		request.setServicingNotesFormat(ServicingNoteFormat.NONE);
		
		RequestValidationException actualException = null;
		
		try {
			validator.validateAndRetrieveCard(request, entityRequest);
		} catch (RequestValidationException exception) {
			actualException = exception;
		}
		
        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_SERVICING_NOTE_FORMAT_ID_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_SERVICING_NOTE_FORMAT_ID_INVALID, apiError.getMessagePropertyKey());
	}
	
	@Test
	public void testValidateAndRetrieveCardWithFraudExclusionRetrievalRequestForNoteFormatNONOTIFICATIONS() {
		FraudExclusionRetrievalRequest request = new FraudExclusionRetrievalRequest();
		request.setServicingNotesFormat(ServicingNoteFormat.NONOTIFICATIONS);
		
		RequestValidationException actualException = null;
		
		try {
			validator.validateAndRetrieveCard(request, entityRequest);
		} catch (RequestValidationException exception) {
			actualException = exception;
		}
		
        assertNotNull(actualException);

        ApiErrorCode apiError = actualException.getApiError();
        assertNotNull(apiError);
        assertEquals(ErrorConstants.ERR_MSG_ID_SERVICING_NOTE_FORMAT_ID_INVALID, apiError.getId());
        assertEquals(ErrorConstants.ERR_MSG_ID_SERVICING_NOTE_FORMAT_ID_INVALID, apiError.getMessagePropertyKey());
	}	
	

}
