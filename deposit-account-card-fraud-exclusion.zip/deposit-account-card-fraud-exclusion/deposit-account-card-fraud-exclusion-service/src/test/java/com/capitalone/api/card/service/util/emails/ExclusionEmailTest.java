package com.capitalone.api.card.service.util.emails;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.capitalone.api.card.model.v3.CardActionType;

@RunWith(MockitoJUnitRunner.class)
public class ExclusionEmailTest {
      
    protected static final String PARAM_CARD_NUMBER = "LastFourDigitsCardNo";
    protected static final String EMAIL_SUCCESS = "Y";

    private ExclusionEmail exclusionEmail;

    @Mock
    private EmailSender emailSender;
    
    @Test
    public void testSend()
    {
    	EmailRequest request = new EmailRequest();
    	request.setAccountNumber("1234567890");
        request.setCustomerNumber("12345678");
        request.setInteractionId("999999");
        request.setRequestedBy("userId");
        
        exclusionEmail = new ExclusionEmail();
        exclusionEmail.emailSender = emailSender;
        
        exclusionEmail.send(request);
        
        Mockito.verify(emailSender, Mockito.times(1)).send(request);
    }    
    
    
    @Test
    public void testBuildRequest()
    {
    	EmailRequest request = new EmailRequest();
    	request.setAccountNumber("1234567890");
        request.setCustomerNumber("12345678");
        request.setInteractionId("999999");
        request.setRequestedBy("userId");
        
        exclusionEmail = new ExclusionEmail();
        
        HashMap<String, String> parameterMap = (HashMap) exclusionEmail.buildParameters(CardActionType.ANTI_FRAUD_SERVICING,  "1234");
        request.setParameters(parameterMap);
        request.setWritingActivity(true);
        
        EmailRequest emailReq = exclusionEmail.buildRequest(CardActionType.ANTI_FRAUD_SERVICING, "1234567890", "1234", "12345678", "999999", "userId");
        Assert.assertEquals(emailReq.getActivityDescription(), "Anti Fraud Alert");
        
        emailReq = exclusionEmail.buildRequest(CardActionType.TRAVEL_NOTIFICATION, "1234567890", "1234", "12345678", "999999", "userId");
        Assert.assertEquals(emailReq.getActivityDescription(), "Travel Notice Alert");
        
    	
    }
    
           
    @Test
    public void testBuildParameterMap() {
        
    	Map<String, String> parameters = new HashMap<String, String>();
        parameters.put("123456781234", "1234");
        
        exclusionEmail = new ExclusionEmail();
        
        String lastFour = "1234";
        HashMap<String, String> parameterMap = (HashMap) exclusionEmail.buildParameters(CardActionType.ANTI_FRAUD_SERVICING,  "1234");
        Assert.assertEquals(parameterMap.get(PARAM_CARD_NUMBER), lastFour);
        
        parameterMap = (HashMap)exclusionEmail.buildParameters(CardActionType.ANTI_FRAUD_SERVICING.NONE,  "1234");
        Assert.assertNotEquals(parameterMap.get(PARAM_CARD_NUMBER), lastFour);
 
    }
      
}