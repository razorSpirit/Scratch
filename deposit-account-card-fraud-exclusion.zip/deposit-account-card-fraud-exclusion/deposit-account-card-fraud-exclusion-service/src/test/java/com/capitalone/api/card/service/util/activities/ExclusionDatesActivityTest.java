package com.capitalone.api.card.service.util.activities;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.MockitoAnnotations.initMocks;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.capitalone.api.card.model.v3.FraudExclusionRequest;
import com.capitalone.epf.context.model.EPFContext;

public class ExclusionDatesActivityTest {

    @InjectMocks
    private ExclusionDatesActivity exclusionDatesActivity;

    @Mock
    private ActivityWriter activityWriter;

    @Captor
    private ArgumentCaptor<List<String>> refListCaptor;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
    }

    @Test
    public void testWrite() {

        String customerNumber = "12345";
        String interactionId = "09876";
        exclusionDatesActivity.write("TravelExclusion", "statusDescription", "startDate", "endDate", customerNumber,
                "note", interactionId);

        doNothing().when(activityWriter).write(any(String.class), refListCaptor.capture(), any(String.class),
                any(String.class));

        verify(activityWriter, times(1)).write(any(String.class), refListCaptor.capture(), any(String.class),
                any(String.class));
        
    }
    
    @Test
    public void testAsync() {
    	
    	EPFContext epfContext = Mockito.mock(EPFContext.class);
    	FraudExclusionRequest request = new FraudExclusionRequest();
        String customerNumber = "12345";
        String interactionId = "09876";
        request.setExclusionStartDate("2016-01-01");
        request.setExclusionEndDate("2016-02-02");
        exclusionDatesActivity.async(epfContext, request, customerNumber,
                "note", interactionId);
        
        doNothing().when(activityWriter).write(any(String.class), refListCaptor.capture(), any(String.class),
                any(String.class));
        verify(activityWriter, times(1)).write(any(String.class), refListCaptor.capture(), any(String.class),
                any(String.class));

    }
    
    @Test
    public void testAsyncFraudExclusion() {
    	
    	EPFContext epfContext = Mockito.mock(EPFContext.class);
    	FraudExclusionRequest request = new FraudExclusionRequest();
        String customerNumber = "12345";
        String interactionId = "09876";
        request.setExclusionStartDate("2016-01-01");
        request.setExclusionEndDate("2016-02-02");
        request.setCardActionCode("AntiFraudServicing");
       
        exclusionDatesActivity.async(epfContext, request, customerNumber,
                "note", interactionId);
        
        doNothing().when(activityWriter).write(any(String.class), refListCaptor.capture(), any(String.class),
                any(String.class));
        verify(activityWriter, times(1)).write(any(String.class), refListCaptor.capture(), any(String.class),
                any(String.class));

    }
    
    @Test
    public void testAsyncIAE() {
        
        EPFContext epfContext = Mockito.mock(EPFContext.class);
        FraudExclusionRequest request = new FraudExclusionRequest();
        String customerNumber = "12345";
        String interactionId = "09876";
        request.setExclusionStartDate("2016/21/21");
        request.setExclusionEndDate("2016-02-02");
        exclusionDatesActivity.async(epfContext, request, customerNumber,
                "note", interactionId);
        
        doNothing().when(activityWriter).write(any(String.class), refListCaptor.capture(), any(String.class),
                any(String.class));
        verify(activityWriter, times(1)).write(any(String.class), refListCaptor.capture(), any(String.class),
                any(String.class));

    }
    
    
    
}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */