package com.capitalone.api.card.service.util.activities;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.MockitoAnnotations.initMocks;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;

public class EmailNotificationActivityTest {

    @InjectMocks
    private EmailNotificationActivity emailNotificationActivity;

    @Mock
    private ActivityWriter activityWriter;

    @Captor
    private ArgumentCaptor<List<String>> refListCaptor;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
    }

    @Test
    public void testEmailSuccessWrite() {

        String customerNumber = "12345";
        String interactionId = "09876";
        String docId = "12345";
        String emailStatus = "Y";
        String activityDesc = "Travel Notification Alert";
        doNothing().when(activityWriter).write(any(String.class), refListCaptor.capture(), any(String.class),
                any(String.class));
        
        emailNotificationActivity.write(docId, emailStatus, customerNumber, interactionId, activityDesc);

        verify(activityWriter, times(1)).write(any(String.class), refListCaptor.capture(), any(String.class),
                any(String.class));
    }
    
    @Test
    public void testEmailFailWrite() {

        String customerNumber = "12345";
        String interactionId = "09876";
        String docId = "12346";
        String emailStatus = "N";
        String activityDesc = "Fraud Servicing Alert";
        doNothing().when(activityWriter).write(any(String.class), refListCaptor.capture(), any(String.class),
                any(String.class));
        
        emailNotificationActivity.write(docId, emailStatus, customerNumber, interactionId, activityDesc);

        verify(activityWriter, times(1)).write(any(String.class), refListCaptor.capture(), any(String.class),
                any(String.class));
    }
}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */