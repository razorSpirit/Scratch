package com.capitalone.api.card.service.util.activities;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.mock;

import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.capitalone.api.bank.lib.activity.dao.ActivityDao;
import com.capitalone.api.bank.lib.activity.model.Activity;

public class ActivityWriterTest {

    private static final String VALID_ACTIVITY_TYPE = "123";

	private static final String VALID_INTERACTION_ID = "9876";

	private static final String VALID_CUST_ID = "12345";

	private static final String VALID_OPERATOR_ID = "sassy";

	@InjectMocks
    private ActivityWriter activityWriter;

    @Mock
    private ActivityDao activityDao;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
    }

    @Test
    public void testWriteSuccess() {

        List<String> refDataList = new ArrayList<String>();

        activityWriter.write(VALID_ACTIVITY_TYPE, refDataList, VALID_INTERACTION_ID, VALID_CUST_ID);

        doNothing().when(activityDao).createActivity(any(Activity.class));

        verify(activityDao, times(1)).createActivity(any(Activity.class));
    }
 
    
    
    @Test(expected = Exception.class)
    public void createTestForWriteFailure() {
    	List<String> refDataList = new ArrayList<String>(); 
    	activityWriter.write(VALID_ACTIVITY_TYPE, refDataList, VALID_INTERACTION_ID, VALID_CUST_ID);
    	
        Activity activity=mock(Activity.class);
        doThrow(new Exception()).when(activityDao).createActivity(activity);
      
        verify(activityDao, times(1)).createActivity(any(Activity.class));
    }

 

}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
