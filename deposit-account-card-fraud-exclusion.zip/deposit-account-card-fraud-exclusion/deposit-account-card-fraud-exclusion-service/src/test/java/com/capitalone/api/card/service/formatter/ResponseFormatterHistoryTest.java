package com.capitalone.api.card.service.formatter;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNotNull;
import static org.mockito.MockitoAnnotations.initMocks;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;

import com.capitalone.api.card.model.v3.CardActionType;
import com.capitalone.api.card.model.v3.FraudExclusionRetrievalResponse;
import com.capitalone.api.card.model.v3.History;
import com.capitalone.api.card.model.v3.ServicingNoteFormat;
import com.capitalone.api.card.service.dto.ParsedDatesAndNotes;
import com.capitalone.api.card.service.dto.ParsedNote;

public class ResponseFormatterHistoryTest {

    @InjectMocks
    private ResponseFormatterHistory responseFormatter;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
    }

    @Test
    public void testFormat() {
        FraudExclusionRetrievalResponse response = responseFormatter.format(getParsedDatesAndNotes());

        assertNotNull(response);
        assertEquals(ServicingNoteFormat.HISTORY, response.getServicingNoteFormat());
        assertEquals(getParsedDatesAndNotes().getExclusionStartDate(), response.getExclusionStartDate());
        assertEquals(getParsedDatesAndNotes().getExclusionEndDate(), response.getExclusionEndDate());
        assertTrue(getParsedDatesAndNotes().toString().equals("2015-09-302015-09-252015-09-254"));
        assertTrue(getParsedDatesEmptyNotes().toString().equals("2015-09-302015-09-252015-09-250"));
        assertTrue(0 == getParsedDatesEmptyNotes().getParsedNote().size());
        assertTrue(getParsedDatesNullNotes().toString().equals("0"));
        assertTrue(0 == getParsedDatesNullNotes().getParsedNote().size());
        assertEquals(3, response.getHistory().size());
        assertEquals(1, response.getHistory().get(0).getServicingNotes().size());
        assertEquals(CardActionType.TRAVEL_NOTIFICATION, response.getHistory().get(0).getCardActionType());
        assertEquals(1, response.getHistory().get(1).getServicingNotes().size());
        assertEquals(CardActionType.ANTI_FRAUD_SERVICING, response.getHistory().get(1).getCardActionType());
        assertEquals(2, response.getHistory().get(2).getServicingNotes().size());
        assertEquals(CardActionType.TRAVEL_NOTIFICATION, response.getHistory().get(2).getCardActionType());
    }

    @Test
    public void testBuildHistoryForMultipleNotesInHistory() {
        List<History> historyList = responseFormatter.buildHistory(getParsedNotesList());
        assertEquals(3, historyList.size());
        assertEquals(1, historyList.get(0).getServicingNotes().size());
        assertEquals(1, historyList.get(1).getServicingNotes().size());
        assertEquals(2, historyList.get(2).getServicingNotes().size());
    }

    @Test
    public void testBuildHistoryForTypeOther() {
        List<History> historyList = responseFormatter.buildHistory(getParsedNotesListWithOther());
        assertEquals(1, historyList.size());
        assertEquals(2, historyList.get(0).getServicingNotes().size());
        assertEquals(CardActionType.OTHER, historyList.get(0).getCardActionType());
        assertEquals(getParsedNotesList().get(0).getLineNumber(), historyList.get(0).getServicingNotes().get(0)
                .getServicingNotesLineNumber());

    }

    @Test
    public void testBuildHistoryForOtherAndDates() {
        List<History> historyList = responseFormatter.buildHistory(getParsedNotesListWithOtherAndDates());
        assertEquals(2, historyList.size());
        assertEquals(1, historyList.get(0).getServicingNotes().size());
        assertEquals(getParsedNotesList().get(0).getLineNumber(), historyList.get(0).getServicingNotes().get(0)
                .getServicingNotesLineNumber());

    }

    @Test
    public void testBuildHistoryForNullDateValues() {
        List<History> historyList = responseFormatter.buildHistory(getParsedNotesListWithNullDates());
        assertEquals(1, historyList.size());
        assertEquals(2, historyList.get(0).getServicingNotes().size());
        assertEquals(getParsedNotesList().get(0).getLineNumber(), historyList.get(0).getServicingNotes().get(0)
                .getServicingNotesLineNumber());

    }

    private ParsedDatesAndNotes getParsedDatesAndNotes() {
        ParsedDatesAndNotes parsedDatesAndNotes = new ParsedDatesAndNotes();

        parsedDatesAndNotes.setExclusionEndDate("2015-09-25");
        parsedDatesAndNotes.setExclusionStartDate("2015-09-30");
        parsedDatesAndNotes.setParsedNote(getParsedNotesList());
        return parsedDatesAndNotes;
    }
    
    private ParsedDatesAndNotes getParsedDatesEmptyNotes() {
        ParsedDatesAndNotes parsedDatesAndNotes = new ParsedDatesAndNotes();

        parsedDatesAndNotes.setExclusionEndDate("2015-09-25");
        parsedDatesAndNotes.setExclusionStartDate("2015-09-30");
        parsedDatesAndNotes.setParsedNote(new ArrayList<ParsedNote>());
        return parsedDatesAndNotes;
    }
    
    private ParsedDatesAndNotes getParsedDatesNullNotes() {
        ParsedDatesAndNotes parsedDatesAndNotes = new ParsedDatesAndNotes();

        parsedDatesAndNotes.setExclusionEndDate(null);
        parsedDatesAndNotes.setExclusionStartDate(null);
        parsedDatesAndNotes.setParsedNote(null);
        return parsedDatesAndNotes;
    }

    private List<ParsedNote> getParsedNotesList() {

        List<ParsedNote> parsedNoteList = new ArrayList<ParsedNote>();

        ParsedNote note1 = new ParsedNote();
        note1.setLineNumber(1);
        note1.setNote("test1");
        note1.setNoteCardActionType("TRAVLNOTE");
        note1.setNoteStartDate("2015-11-23");
        note1.setNoteEndDate("2015-11-30");

        ParsedNote note2 = new ParsedNote();
        note2.setLineNumber(2);
        note2.setNote("test");
        note2.setNoteCardActionType("TRAVLNOTE");
        note2.setNoteStartDate("2015-12-23");
        note2.setNoteEndDate("2015-12-30");

        ParsedNote note3 = new ParsedNote();
        note3.setLineNumber(3);
        note3.setNote("test2");
        note3.setNoteCardActionType("TRAVLNOTE");
        note3.setNoteStartDate("2015-11-23");
        note3.setNoteEndDate("2015-11-30");

        ParsedNote note4 = new ParsedNote();
        note4.setLineNumber(4);
        note4.setNote("test");
        note4.setNoteCardActionType("AFNOTICE");
        note4.setNoteStartDate("2015-10-23");
        note4.setNoteEndDate("2015-10-30");

        parsedNoteList.add(note1);
        parsedNoteList.add(note2);
        parsedNoteList.add(note3);
        parsedNoteList.add(note4);
        return parsedNoteList;
    }

    private List<ParsedNote> getParsedNotesListWithOther() {

        List<ParsedNote> parsedNoteList = new ArrayList<ParsedNote>();

        ParsedNote note1 = new ParsedNote();
        note1.setLineNumber(1);
        note1.setNote("note1");
        note1.setNoteCardActionType("OTHER");
        note1.setNoteStartDate("UNKNOWN");
        note1.setNoteEndDate("UNKNOWN");

        ParsedNote note2 = new ParsedNote();
        note2.setLineNumber(2);
        note2.setNote("note2");
        note2.setNoteCardActionType("OTHER");
        note2.setNoteStartDate("UNKNOWN");
        note2.setNoteEndDate("UNKNOWN");

        parsedNoteList.add(note1);
        parsedNoteList.add(note2);

        return parsedNoteList;
    }

    private List<ParsedNote> getParsedNotesListWithOtherAndDates() {
        List<ParsedNote> parsedNoteList = new ArrayList<ParsedNote>();

        ParsedNote note1 = new ParsedNote();
        note1.setLineNumber(1);
        note1.setNote("note1");
        note1.setNoteCardActionType("OTHER");
        note1.setNoteStartDate("UNKNOWN");
        note1.setNoteEndDate("UNKNOWN");

        ParsedNote note2 = new ParsedNote();
        note2.setLineNumber(2);
        note2.setNote("note2");
        note2.setNoteCardActionType("Travel");
        note2.setNoteStartDate("2015-10-23");
        note2.setNoteEndDate("2015-10-30");

        parsedNoteList.add(note1);
        parsedNoteList.add(note2);

        return parsedNoteList;
    }

    private List<ParsedNote> getParsedNotesListWithNullDates() {
        List<ParsedNote> parsedNoteList = new ArrayList<ParsedNote>();

        ParsedNote note1 = new ParsedNote();
        note1.setLineNumber(1);
        note1.setNote("note1");
        note1.setNoteCardActionType("OTHER");
        note1.setNoteStartDate(null);
        note1.setNoteEndDate(null);

        ParsedNote note2 = new ParsedNote();
        note2.setLineNumber(2);
        note2.setNote("note2");
        note2.setNoteCardActionType("OTHER");
        note2.setNoteStartDate(null);
        note2.setNoteEndDate(null);

        parsedNoteList.add(note1);
        parsedNoteList.add(note2);

        return parsedNoteList;
    }

}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
