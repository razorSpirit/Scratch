package com.capitalone.api.card.service.formatter;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.MockitoAnnotations.initMocks;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Appender;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.capitalone.api.card.model.v3.CardActionType;
import com.capitalone.api.card.model.v3.FraudExclusionRetrievalResponse;
import com.capitalone.api.card.model.v3.ServicingNoteFormat;
import com.capitalone.api.card.service.dto.ParsedDatesAndNotes;
import com.capitalone.api.card.service.dto.ParsedNote;

public class ResponseFormatterAllTest {
    @InjectMocks
    private ResponseFormatterAll responseFormatterAll;

    @Mock
    private Appender mockAppender;

    private static final String EXCLUSION_START_DATE = "2015-08-21";

    private static final String EXCLUSION_END_DATE = "2015-08-22";

    private static final String EXCLUSION_START_DATE1 = "2015-08-21";

    private static final String EXCLUSION_END_DATE1 = "2015-08-22";

    @Before
    public void setUp() throws Exception {
        initMocks(this);
    }

    @After
    public void tearDown() throws Exception {
    }

    // **************Happy Path with MulitpleNotes********************************

    @Test
    public void testResponseForMultipleNotes() {

        FraudExclusionRetrievalResponse response = responseFormatterAll.format(getParsedDatesAndNotes());
        assertNotNull(response);
        assertEquals(ServicingNoteFormat.ALL, response.getServicingNoteFormat());
        assertEquals(getParsedDatesAndNotes().getExclusionStartDate(), response.getExclusionStartDate());
        assertEquals(getParsedDatesAndNotes().getExclusionEndDate(), response.getExclusionEndDate());

        assertEquals("TravelNotification 2015-11-23-2015-11-30 : test1", response.getServicingNotes().get(0)
                .getServicingNote());

        assertEquals("test2", response.getServicingNotes().get(1).getServicingNote());

        assertEquals("test3", response.getServicingNotes().get(2).getServicingNote());

        assertEquals(1, response.getServicingNotes().get(0).getServicingNotesLineNumber());
        assertEquals(2, response.getServicingNotes().get(1).getServicingNotesLineNumber());

        assertEquals(response.getServicingNotes().size(), 3);
        assertNull(response.getHistory());
        assertNull(response.getCardActionCode());
    }

    @Test
    public void testResponseForNullNotes() {
        FraudExclusionRetrievalResponse response = responseFormatterAll.format(getParsedDatesAndNotesWithNoNotes());
        assertNotNull(response);

        assertEquals(ServicingNoteFormat.ALL, response.getServicingNoteFormat());
        assertEquals(getParsedDatesAndNotesWithNoNotes().getExclusionStartDate(), response.getExclusionStartDate());
        assertEquals(EXCLUSION_START_DATE1, getParsedDatesAndNotesWithNoNotes().getExclusionStartDate());
        assertEquals(getParsedDatesAndNotesWithNoNotes().getExclusionEndDate(), response.getExclusionEndDate());
        assertEquals(EXCLUSION_END_DATE1, getParsedDatesAndNotesWithNoNotes().getExclusionEndDate());

        assertEquals(response.getServicingNotes().size(), 0);

        assertNull(response.getHistory());
        assertNull(response.getCardActionCode());
    }

    private ParsedDatesAndNotes getParsedDatesAndNotes() {
        ParsedDatesAndNotes parsedDatesAndNotes = new ParsedDatesAndNotes();
        parsedDatesAndNotes.setExclusionEndDate(EXCLUSION_START_DATE);
        parsedDatesAndNotes.setExclusionStartDate(EXCLUSION_END_DATE);
        parsedDatesAndNotes.setParsedNote(getParsedNotesList());

        return parsedDatesAndNotes;
    }

    private List<ParsedNote> getParsedNotesList() {
        List<ParsedNote> listParsedNote = new ArrayList<ParsedNote>();

        ParsedNote note1 = new ParsedNote();
        note1.setLineNumber(1);
        note1.setNoteCardActionType(CardActionType.TRAVEL_NOTIFICATION.getCode());
        note1.setNoteStartDate("2015-11-23");
        note1.setNoteEndDate("2015-11-30");
        note1.setNote("test1");

        ParsedNote note2 = new ParsedNote();
        note2.setLineNumber(2);
        note2.setNoteStartDate(EXCLUSION_END_DATE);
        note2.setNoteEndDate(EXCLUSION_END_DATE);
        note2.setNote("test2");

        ParsedNote note3 = new ParsedNote();
        note3.setLineNumber(3);
        note3.setNoteCardActionType(CardActionType.OTHER.getCode());
        note3.setNoteStartDate(EXCLUSION_END_DATE);
        note3.setNoteEndDate(EXCLUSION_END_DATE);
        note3.setNote("test3");

        listParsedNote.add(note1);
        listParsedNote.add(note2);
        listParsedNote.add(note3);

        return listParsedNote;
    }

    private ParsedDatesAndNotes getParsedDatesAndNotesWithNoNotes() {
        ParsedDatesAndNotes parsedDatesAndNotes = new ParsedDatesAndNotes();
        parsedDatesAndNotes.setExclusionStartDate(EXCLUSION_START_DATE1);
        parsedDatesAndNotes.setExclusionEndDate(EXCLUSION_END_DATE1);
        parsedDatesAndNotes.setParsedNote(null);

        return parsedDatesAndNotes;
    }

}