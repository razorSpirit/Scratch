package com.capitalone.api.card.service.util.card;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.capitalone.api.bank.lib.metavante.dao.impl.MetavanteDaoImpl;
import com.capitalone.api.bank.lib.metavante.model.ArrayOfCardNumbers;
import com.capitalone.api.bank.lib.metavante.model.SearchCardsRequest;
import com.capitalone.api.bank.lib.metavante.model.SearchCardsResponse;
import com.capitalone.api.model.id.CardReferenceId;
import com.capitalone.api.model.id.ReferenceId;

@RunWith(MockitoJUnitRunner.class)
public class CardFinderTest {

    @Mock
    private MetavanteDaoImpl metavanteDaoImpl;

    private ReferenceId referenceId;

    CardReferenceId cardReferenceId;

    @InjectMocks
    CardFinder finder;

    @Before
    public void setUp()
            throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
        referenceId = ReferenceId.valueOf("accountId=00000000001~~sorId=185~~firstSix=123456~~lastFour=7890");
        cardReferenceId = new CardReferenceId(referenceId);
        SearchCardsRequest searchCardsRequest = new SearchCardsRequest();
        searchCardsRequest.setAccountNumber(cardReferenceId.getAccountId());

    }

    @Test
    public void testCardFinder()
            throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
        SearchCardsResponse response = new SearchCardsResponse();
        Field field = SearchCardsResponse.class.getDeclaredField("arrayOfCardNumbers");
        ArrayOfCardNumbers cardNo = new ArrayOfCardNumbers();
        cardNo.setCardNumber("1234567890127890");
        List<ArrayOfCardNumbers> cardNoList = new ArrayList<ArrayOfCardNumbers>();
        cardNoList.add(cardNo);
        field.setAccessible(true);
        field.set(response, cardNoList);
        Mockito.when(metavanteDaoImpl.searchCards(Mockito.any(SearchCardsRequest.class))).thenReturn(response);
        Assert.assertEquals(cardNo, finder.getCardNumber(new CardReferenceId(referenceId)));
        Mockito.when(metavanteDaoImpl.searchCards(Mockito.any(SearchCardsRequest.class))).thenReturn(null);
        Assert.assertEquals(null, finder.getCardNumber(new CardReferenceId(referenceId)));
    }

    @Test
    public void testGetCardNumber() throws NoSuchMethodException, SecurityException, IllegalAccessException,
            IllegalArgumentException, InvocationTargetException {
        ArrayOfCardNumbers cardNo = new ArrayOfCardNumbers();
        cardNo.setCardNumber("1234567890127890");
        List<ArrayOfCardNumbers> cardNoList = new ArrayList<ArrayOfCardNumbers>();
        cardNoList.add(cardNo);
        CardFinder finder = new CardFinder();
        Method method = CardFinder.class.getDeclaredMethod("getCardNumber", List.class, String.class, String.class);
        method.setAccessible(true);
        ArrayOfCardNumbers cardNoArr = (ArrayOfCardNumbers) method.invoke(finder, cardNoList, "123456", "7890");
        Assert.assertEquals(cardNoArr, cardNo);
        ArrayOfCardNumbers cardNoArr2 = (ArrayOfCardNumbers) method.invoke(finder, cardNoList, "1234567", "78907");
        Assert.assertEquals(cardNoArr2, null);
    }

    @Test
    public void testGetCardNumberEmpty() throws NoSuchMethodException, SecurityException, IllegalAccessException,
            IllegalArgumentException, InvocationTargetException {
        ArrayOfCardNumbers cardNo = new ArrayOfCardNumbers();
        cardNo.setCardNumber("");
        List<ArrayOfCardNumbers> cardNoList = new ArrayList<ArrayOfCardNumbers>();
        cardNoList.add(cardNo);
        CardFinder finder = new CardFinder();
        Method method = CardFinder.class.getDeclaredMethod("getCardNumber", List.class, String.class, String.class);
        method.setAccessible(true);
        ArrayOfCardNumbers cardNoArr = (ArrayOfCardNumbers) method.invoke(finder, cardNoList, "123456", "7890");
        Assert.assertEquals(null, cardNoArr);
        ArrayOfCardNumbers cardNoArr2 = (ArrayOfCardNumbers) method.invoke(finder, cardNoList, "1234567", "78907");
        Assert.assertEquals(cardNoArr2, null);

    }

    @Test
    public void testGetCardNumberNull() throws NoSuchMethodException, SecurityException, IllegalAccessException,
            IllegalArgumentException, InvocationTargetException {
        ArrayOfCardNumbers cardNo = new ArrayOfCardNumbers();
        cardNo.setCardNumber(null);
        List<ArrayOfCardNumbers> cardNoList = new ArrayList<ArrayOfCardNumbers>();
        cardNoList.add(cardNo);
        CardFinder finder = new CardFinder();
        Method method = CardFinder.class.getDeclaredMethod("getCardNumber", List.class, String.class, String.class);
        method.setAccessible(true);
        ArrayOfCardNumbers cardNoArr = (ArrayOfCardNumbers) method.invoke(finder, cardNoList, "123456", "7890");
        Assert.assertEquals(null, cardNoArr);
        ArrayOfCardNumbers cardNoArr2 = (ArrayOfCardNumbers) method.invoke(finder, cardNoList, "1234567", "78907");
        Assert.assertEquals(cardNoArr2, null);

    }

    @Test
    public void testFirstSixOfCard() {
        org.springframework.util.Assert.isTrue(finder.getFirstSixDigits("").equals(""));
        org.springframework.util.Assert.isTrue(finder.getFirstSixDigits("4321").equals(""));
        org.springframework.util.Assert.isTrue(finder.getFirstSixDigits("43215").equals(""));
        org.springframework.util.Assert.isTrue(finder.getFirstSixDigits("12345678901").equals("123456"));
    }

    @Test
    public void testLastFourOfCard() {
        org.springframework.util.Assert.isTrue(finder.getLastFourDigits("").equals(""));
        org.springframework.util.Assert.isTrue(finder.getLastFourDigits("4321").equals(""));
        org.springframework.util.Assert.isTrue(finder.getLastFourDigits("43215").equals(""));
        org.springframework.util.Assert.isTrue(finder.getLastFourDigits("12345678901").equals("8901"));
    }

}