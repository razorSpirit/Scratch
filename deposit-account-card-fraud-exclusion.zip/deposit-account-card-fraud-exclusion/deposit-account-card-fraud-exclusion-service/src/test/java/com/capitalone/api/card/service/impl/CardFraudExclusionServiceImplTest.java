package com.capitalone.api.card.service.impl;

import static com.capitalone.api.card.service.constants.ErrorConstants.DEV_TXT_DATES_FAILED;
import static com.capitalone.api.card.service.constants.ErrorConstants.DEV_TXT_NOTE_FAILED;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Appender;
import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggingEvent;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.capitalone.api.bank.commons.db.utils.PingUtil;
import com.capitalone.api.bank.lib.metavante.model.AddnStat;
import com.capitalone.api.bank.lib.metavante.model.StatType;
import com.capitalone.api.card.model.v3.CardActionType;
import com.capitalone.api.card.model.v3.FraudExclusionRequest;
import com.capitalone.api.card.model.v3.FraudExclusionRetrievalRequest;
import com.capitalone.api.card.model.v3.FraudExclusionRetrievalResponse;
import com.capitalone.api.card.model.v3.ServicingNoteFormat;
import com.capitalone.api.card.service.dao.CardFraudExclusionDAO;
import com.capitalone.api.card.service.dto.Card;
import com.capitalone.api.card.service.dto.ParsedDatesAndNotes;
import com.capitalone.api.card.service.dto.ParsedNote;
import com.capitalone.api.card.service.formatter.ResponseFormatter;
import com.capitalone.api.card.service.util.activities.DatesActivityWriter;
import com.capitalone.api.card.service.util.activities.EmailNotificationActivity;
import com.capitalone.api.card.service.util.build.DatesAndNotesBuilder;
import com.capitalone.api.card.service.util.emails.ExclusionEmailSender;
import com.capitalone.api.card.service.util.errors.ErrorHandler;
import com.capitalone.api.card.service.util.notes.NoteStamper;
import com.capitalone.api.card.service.util.validation.CardFraudExclusionValidator;
import com.capitalone.api.commons.exception.ApiSystemException;
import com.capitalone.api.commons.model.EntityRequest;
import com.capitalone.epf.context.model.EPFContext;

public class CardFraudExclusionServiceImplTest {

    @InjectMocks
    private CardFraudExclusionServiceImpl service;

    @Mock
    private CardFraudExclusionValidator validator;

    @Mock
    private CardFraudExclusionDAO cardFraudExclusionDAO;

    @Mock
    private Appender mockAppender;

    @Mock
    private DatesActivityWriter datesActivityWriter;

    @Mock
    private EmailNotificationActivity emailNotificationActivity;

    @Mock
    private ExclusionEmailSender exclusionEmail;

    @Mock
    private DatesAndNotesBuilder datesAndNotesBuilder;

    @Mock
    private ResponseFormatter responseFormatter;

    @Mock
    private PingUtil pingUtil;

    private ArgumentCaptor<LoggingEvent> logMessageCaptor;

    private static final String START_DATE = "1930-05-01";

    private static final String END_DATE = "1930-05-07";

    private static final String CARD_NUMBER = "42580482811";

    private static final String CUST_NUMBER = "11";

    private static final String INTERACTION_ID = "1234567";

    private static final String USER_ID = "zxy3497";

    private static final String ACTION_CODE = "AntiFraudServicing";

    private static final String STAMPED_NOTE = "AFNOTICE:05/01/30-05/07/30 Going to Italy - arrivederci!";

    private static final String NOTE = "Going to Italy - arrivederci!";

    private static final String EXCEPTION_MSG = "MOCK EXCEPTION";
    
    private static final String UNKNOWN = "UNKNOWN";

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        Logger.getRootLogger().addAppender(mockAppender);
        logMessageCaptor = ArgumentCaptor.forClass(LoggingEvent.class);
    }

    @After
    public void tearDown() throws Exception {
        service = null;
        logMessageCaptor = null;
    }

    // =================== TEST NoteStamper ================
    @Test
    public void noteStamperTest() {
        FraudExclusionRequest request = new FraudExclusionRequest();
        request.setExclusionStartDate(START_DATE);
        request.setExclusionEndDate(END_DATE);
        request.setServicingNotes(NOTE);
        request.setCardActionCode(ACTION_CODE);
        request.setServicingNotes(NOTE);
        request.setIsEmailResponseRequired(true);

        String actualStampedNote = NoteStamper.getStampedNote(request);
        assertNotNull(actualStampedNote);
        assertEquals(STAMPED_NOTE, actualStampedNote);
    }

    /**
     * Happy Path: 1. Validation passes 2. Email sent 3. dates addedd 4. notes added 5. activity written
     */
    @Test
    public void createTestForHappyPath() {
        Card cardData = new Card();
        cardData.setCardNumber(CARD_NUMBER);
        cardData.setCustomerNumber(CUST_NUMBER);

        FraudExclusionRequest request = new FraudExclusionRequest();
        request.setExclusionStartDate(START_DATE);
        request.setExclusionEndDate(END_DATE);
        request.setServicingNotes(NOTE);
        request.setCardActionCode(ACTION_CODE);
        request.setIsEmailResponseRequired(true);

        EntityRequest entityRequest = new EntityRequest();
        entityRequest.setClientCorrelationId(INTERACTION_ID);
        entityRequest.setUserId(USER_ID);

        NoteStamper.getStampedNote(request);

        when(validator.validateAndRetrieveCard(request, entityRequest)).thenReturn(cardData);

        // *email*
        ArgumentCaptor<EPFContext> captureEmailEPFContext = ArgumentCaptor.forClass(EPFContext.class);
        ArgumentCaptor<FraudExclusionRequest> captureEmailFraudExclusionRequest = ArgumentCaptor
                .forClass(FraudExclusionRequest.class);
        ArgumentCaptor<EntityRequest> captureEmailEntityRequest = ArgumentCaptor.forClass(EntityRequest.class);
        ArgumentCaptor<String> captureEmailCustomerNumber = ArgumentCaptor.forClass(String.class);

        doNothing().when(exclusionEmail).async(captureEmailEPFContext.capture(),
                captureEmailFraudExclusionRequest.capture(), captureEmailEntityRequest.capture(),
                captureEmailCustomerNumber.capture());

        // *addDates*
        ArgumentCaptor<String> captureDateCardNumber = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureDateStartDate = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureDateEndDate = ArgumentCaptor.forClass(String.class);
        doNothing().when(cardFraudExclusionDAO).addDates(captureDateCardNumber.capture(),
                captureDateStartDate.capture(), captureDateEndDate.capture());

        ArgumentCaptor<String> captureNoteCardNumber = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureNoteStartDate = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureNoteEndDate = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureNoteNotes = ArgumentCaptor.forClass(String.class);
        doNothing().when(cardFraudExclusionDAO).addNote(captureNoteCardNumber.capture(),
                captureNoteStartDate.capture(), captureNoteEndDate.capture(), captureNoteNotes.capture());

        // *activity*
        ArgumentCaptor<EPFContext> captureActivityEPFContext = ArgumentCaptor.forClass(EPFContext.class);
        ArgumentCaptor<FraudExclusionRequest> captureActivityFraudExclusionRequest = ArgumentCaptor
                .forClass(FraudExclusionRequest.class);
        ArgumentCaptor<EntityRequest> captureActivityEntityRequest = ArgumentCaptor.forClass(EntityRequest.class);
        ArgumentCaptor<String> captureActivityCustomerNumber = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captureActivityStampedNote = ArgumentCaptor.forClass(String.class);

        doNothing().when(datesActivityWriter).write(captureActivityEPFContext.capture(),
                captureActivityFraudExclusionRequest.capture(), captureActivityEntityRequest.capture(),
                captureActivityCustomerNumber.capture(), captureActivityStampedNote.capture());

        service.create(request, entityRequest);

        verify(validator, times(1)).validateAndRetrieveCard(request, entityRequest);

        // *email*
        verify(exclusionEmail, times(1)).async(captureEmailEPFContext.capture(),
                captureEmailFraudExclusionRequest.capture(), captureEmailEntityRequest.capture(),
                captureEmailCustomerNumber.capture());
        assertNull(captureEmailEPFContext.getValue());
        assertNotNull(captureEmailFraudExclusionRequest.getValue());
        assertNotNull(captureEmailEntityRequest.getValue());
        assertEquals(CUST_NUMBER, captureEmailCustomerNumber.getValue());

        // *addDates*
        verify(cardFraudExclusionDAO, times(1)).addDates(captureDateCardNumber.capture(),
                captureDateStartDate.capture(), captureDateEndDate.capture());
        assertEquals(CARD_NUMBER, captureDateCardNumber.getValue());
        assertEquals(START_DATE, captureDateStartDate.getValue());
        assertEquals(END_DATE, captureDateEndDate.getValue());

        verify(cardFraudExclusionDAO, times(1)).addNote(captureNoteCardNumber.capture(),
                captureNoteStartDate.capture(), captureDateEndDate.capture(), captureNoteNotes.capture());
        assertEquals(CARD_NUMBER, captureNoteCardNumber.getValue());
        assertEquals(START_DATE, captureNoteStartDate.getValue());
        assertEquals(END_DATE, captureDateEndDate.getValue());
        assertEquals(STAMPED_NOTE, captureNoteNotes.getValue());

        // *activity*
        verify(datesActivityWriter, times(1)).write(captureActivityEPFContext.capture(),
                captureActivityFraudExclusionRequest.capture(), captureActivityEntityRequest.capture(),
                captureActivityCustomerNumber.capture(), captureActivityStampedNote.capture());

        assertNull(captureActivityEPFContext.getValue());
        assertNotNull(captureActivityFraudExclusionRequest.getValue());
        assertNotNull(captureActivityEntityRequest.getValue());
        assertEquals(CUST_NUMBER, captureActivityCustomerNumber.getValue());
        assertEquals(STAMPED_NOTE, captureNoteNotes.getValue());
    }

    // =================== TEST VALIDATION FAILURE ================
    @Test(expected = NullPointerException.class)
    public void createTestForValidationFailure() {
        FraudExclusionRequest request = new FraudExclusionRequest();

        EntityRequest entityRequest = new EntityRequest();
        entityRequest.setClientCorrelationId("1234567");

        when(validator.validateAndRetrieveCard(request, entityRequest)).thenThrow(
                new NullPointerException(EXCEPTION_MSG));

        service.create(request, entityRequest);

        verify(validator, times(1)).validateAndRetrieveCard(any(FraudExclusionRequest.class), any(EntityRequest.class));
    }

    // =================== TEST DATES FAILURE AND NO EMAIL SENT ================
    @Test
    public void createTestForDatesFailure() {

        doNothing().when(exclusionEmail).async(any(EPFContext.class), any(FraudExclusionRequest.class),
                any(EntityRequest.class), any(String.class));

        Card cardData = new Card();
        cardData.setCardNumber(CARD_NUMBER);
        cardData.setCustomerNumber(CUST_NUMBER);

        FraudExclusionRequest request = new FraudExclusionRequest();
        request.setExclusionStartDate(START_DATE);
        request.setExclusionEndDate(END_DATE);
        request.setServicingNotes(NOTE);
        request.setCardActionCode(ACTION_CODE);

        EntityRequest entityRequest = new EntityRequest();
        entityRequest.setClientCorrelationId("1234567");

        when(validator.validateAndRetrieveCard(request, entityRequest)).thenReturn(cardData);
        
        StatType statType = new StatType();
        AddnStat addnStat = new AddnStat();
        addnStat.setNativeErrorCd("1");
        addnStat.setStatDesc("Error");
        List<AddnStat> lAddnStats = new ArrayList<AddnStat>();
        lAddnStats.add(addnStat);
        statType.setAddnStat(lAddnStats);

        ApiSystemException expectedApiSystemException = ErrorHandler.createApiSystemException(DEV_TXT_DATES_FAILED,
                statType);

        doThrow(expectedApiSystemException).when(cardFraudExclusionDAO).addDates(any(String.class), any(String.class),
                any(String.class));

        ApiSystemException actualApiSystemException = null;
        try {
            service.create(request, entityRequest);
            fail("Expected failure");
        } catch (ApiSystemException exception) {
            actualApiSystemException = exception;
        }

        verify(validator, times(1)).validateAndRetrieveCard(request, entityRequest);
        verify(exclusionEmail, never()).async(any(EPFContext.class), any(FraudExclusionRequest.class),
                any(EntityRequest.class), any(String.class));
        verify(cardFraudExclusionDAO, times(1)).addDates(any(String.class), any(String.class), any(String.class));
        verify(cardFraudExclusionDAO, never()).addNote(any(String.class), any(String.class), any(String.class),
                any(String.class));

        verify(datesActivityWriter, never()).write(any(EPFContext.class), any(FraudExclusionRequest.class),
                any(EntityRequest.class), any(String.class), any(String.class));

        assertNotNull(actualApiSystemException);
        assertEquals(DEV_TXT_DATES_FAILED, actualApiSystemException.getApiError().getDeveloperText());

    }

    // =================== TEST NOTES FAILURE AND NO EMAILS ================
    @Test
    public void createTestForNotesFailure() {
        Card cardData = new Card();
        cardData.setCardNumber(CARD_NUMBER);
        cardData.setCustomerNumber(CUST_NUMBER);

        FraudExclusionRequest request = new FraudExclusionRequest();
        request.setExclusionStartDate(START_DATE);
        request.setExclusionEndDate(END_DATE);
        request.setServicingNotes(NOTE);
        request.setCardActionCode(ACTION_CODE);

        EntityRequest entityRequest = new EntityRequest();
        entityRequest.setClientCorrelationId("1234567");

        doNothing().when(exclusionEmail).async(any(EPFContext.class), any(FraudExclusionRequest.class),
                any(EntityRequest.class), any(String.class));

        when(validator.validateAndRetrieveCard(request, entityRequest)).thenReturn(cardData);
        doNothing().when(cardFraudExclusionDAO).addDates(any(String.class), any(String.class), any(String.class));

        ApiSystemException expectedApiSystemException = ErrorHandler
                .createApiSystemException(DEV_TXT_NOTE_FAILED, null);

        doThrow(expectedApiSystemException).when(cardFraudExclusionDAO).addNote(any(String.class), any(String.class),
                any(String.class), any(String.class));

        ApiSystemException actualApiSystemException = null;
        try {
            service.create(request, entityRequest);
            fail("Expected failure");
        } catch (ApiSystemException exception) {
            actualApiSystemException = exception;
        }

        verify(validator, times(1)).validateAndRetrieveCard(request, entityRequest);
        verify(exclusionEmail, never()).async(any(EPFContext.class), any(FraudExclusionRequest.class),
                any(EntityRequest.class), any(String.class));
        verify(cardFraudExclusionDAO, times(1)).addDates(any(String.class), any(String.class), any(String.class));
        verify(cardFraudExclusionDAO, times(1)).addNote(any(String.class), any(String.class), any(String.class),
                any(String.class));
        verify(datesActivityWriter, never()).write(any(EPFContext.class), any(FraudExclusionRequest.class),
                any(EntityRequest.class), any(String.class), any(String.class));

        assertNotNull(actualApiSystemException);
        assertEquals(DEV_TXT_NOTE_FAILED, actualApiSystemException.getApiError().getDeveloperText());

    }

    @Test
    public void retrieveTest() {
        Card cardData = new Card();
        cardData.setCardNumber(CARD_NUMBER);
        cardData.setCustomerNumber(CUST_NUMBER);

        ParsedDatesAndNotes parsedDatesAndNotes = new ParsedDatesAndNotes();
        parsedDatesAndNotes.setExclusionStartDate(START_DATE);
        parsedDatesAndNotes.setExclusionEndDate(END_DATE);
        List<ParsedNote> parsedNotes = new ArrayList<ParsedNote>();
        ParsedNote parsedNote = new ParsedNote();
        parsedNote.setNote("note1");
        parsedNotes.add(parsedNote);
        parsedDatesAndNotes.setParsedNote(parsedNotes);

        FraudExclusionRetrievalRequest request = new FraudExclusionRetrievalRequest();
        request.setServicingNotesFormat(ServicingNoteFormat.LATEST);

        EntityRequest entityRequest = new EntityRequest();
        entityRequest.setUserId(USER_ID);

        entityRequest.setClientCorrelationId("1234567");

        FraudExclusionRetrievalResponse expectedResponse = new FraudExclusionRetrievalResponse();
        expectedResponse.setCardActionCode(CardActionType.NONE);
        expectedResponse.setExclusionStartDate(START_DATE);
        expectedResponse.setExclusionEndDate(END_DATE);

        // * validator *
        ArgumentCaptor<FraudExclusionRetrievalRequest> captureRequest = ArgumentCaptor
                .forClass(FraudExclusionRetrievalRequest.class);
        ArgumentCaptor<EntityRequest> captureEntityRequest = ArgumentCaptor.forClass(EntityRequest.class);
        when(validator.validateAndRetrieveCard(captureRequest.capture(), captureEntityRequest.capture())).thenReturn(
                cardData);

        // * datesAndNotesBuilder *
        ArgumentCaptor<String> captureCardNumber = ArgumentCaptor.forClass(String.class);
        when(datesAndNotesBuilder.build(captureCardNumber.capture())).thenReturn(parsedDatesAndNotes);

        // * responseFormatter *
        ArgumentCaptor<ParsedDatesAndNotes> captureParsedDatesAndNotes = ArgumentCaptor
                .forClass(ParsedDatesAndNotes.class);
        ArgumentCaptor<ServicingNoteFormat> captureServicingNoteFormat = ArgumentCaptor
                .forClass(ServicingNoteFormat.class);
        when(responseFormatter.format(captureParsedDatesAndNotes.capture(), captureServicingNoteFormat.capture()))
                .thenReturn(expectedResponse);

        // * run the test *
        FraudExclusionRetrievalResponse actualResponse = service.retrieve(request, entityRequest);

        verify(validator, times(1)).validateAndRetrieveCard(captureRequest.capture(), captureEntityRequest.capture());
        verify(datesAndNotesBuilder, times(1)).build(captureCardNumber.capture());
        verify(responseFormatter, times(1)).format(captureParsedDatesAndNotes.capture(),
                captureServicingNoteFormat.capture());

        assertNotNull(actualResponse);
        assertEquals(expectedResponse.getServicingNoteFormat(), actualResponse.getServicingNoteFormat());
        assertEquals(expectedResponse.getExclusionStartDate(), actualResponse.getExclusionStartDate());
        assertEquals(expectedResponse.getExclusionEndDate(), actualResponse.getExclusionEndDate());

        assertEquals(ServicingNoteFormat.LATEST, captureRequest.getValue().getServicingNotesFormat());
        assertEquals(USER_ID, captureEntityRequest.getValue().getUserId());

        assertEquals(cardData.getCardNumber(), captureCardNumber.getValue());

        assertEquals(START_DATE, captureParsedDatesAndNotes.getValue().getExclusionStartDate());
        assertEquals(END_DATE, captureParsedDatesAndNotes.getValue().getExclusionEndDate());
        assertEquals(1, captureParsedDatesAndNotes.getValue().getParsedNote().size());

        assertEquals(ServicingNoteFormat.LATEST, captureServicingNoteFormat.getValue());
    }
    
    @Test
    public void retrieveTestDatesEmpty() {
        Card cardData = new Card();
        cardData.setCardNumber(CARD_NUMBER);
        cardData.setCustomerNumber(CUST_NUMBER);

        ParsedDatesAndNotes parsedDatesAndNotes = new ParsedDatesAndNotes();
        List<ParsedNote> parsedNotes = new ArrayList<ParsedNote>();
        ParsedNote parsedNote = new ParsedNote();
        parsedNote.setNote("note1");
        parsedNotes.add(parsedNote);
        parsedDatesAndNotes.setParsedNote(parsedNotes);

        FraudExclusionRetrievalRequest request = new FraudExclusionRetrievalRequest();
        request.setServicingNotesFormat(ServicingNoteFormat.LATEST);

        EntityRequest entityRequest = new EntityRequest();
        entityRequest.setUserId(USER_ID);

        entityRequest.setClientCorrelationId("1234567");

        FraudExclusionRetrievalResponse expectedResponse = new FraudExclusionRetrievalResponse();
        expectedResponse.setCardActionCode(CardActionType.NONE);
        expectedResponse.setExclusionStartDate(START_DATE);
        expectedResponse.setExclusionEndDate(END_DATE);

        // * validator *
        ArgumentCaptor<FraudExclusionRetrievalRequest> captureRequest = ArgumentCaptor
                .forClass(FraudExclusionRetrievalRequest.class);
        ArgumentCaptor<EntityRequest> captureEntityRequest = ArgumentCaptor.forClass(EntityRequest.class);
        when(validator.validateAndRetrieveCard(captureRequest.capture(), captureEntityRequest.capture())).thenReturn(
                cardData);

        // * datesAndNotesBuilder *
        ArgumentCaptor<String> captureCardNumber = ArgumentCaptor.forClass(String.class);
        when(datesAndNotesBuilder.build(captureCardNumber.capture())).thenReturn(parsedDatesAndNotes);

        // * responseFormatter *
        ArgumentCaptor<ParsedDatesAndNotes> captureParsedDatesAndNotes = ArgumentCaptor
                .forClass(ParsedDatesAndNotes.class);
        ArgumentCaptor<ServicingNoteFormat> captureServicingNoteFormat = ArgumentCaptor
                .forClass(ServicingNoteFormat.class);
        when(responseFormatter.format(captureParsedDatesAndNotes.capture(), captureServicingNoteFormat.capture()))
                .thenReturn(expectedResponse);

        // * run the test *
        FraudExclusionRetrievalResponse actualResponse = service.retrieve(request, entityRequest);

        verify(validator, times(1)).validateAndRetrieveCard(captureRequest.capture(), captureEntityRequest.capture());
        verify(datesAndNotesBuilder, times(1)).build(captureCardNumber.capture());
        verify(responseFormatter, times(1)).format(captureParsedDatesAndNotes.capture(),
                captureServicingNoteFormat.capture());

        assertNotNull(actualResponse);
        assertEquals(expectedResponse.getServicingNoteFormat(), actualResponse.getServicingNoteFormat());
        assertEquals(expectedResponse.getExclusionStartDate(), actualResponse.getExclusionStartDate());
        assertEquals(expectedResponse.getExclusionEndDate(), actualResponse.getExclusionEndDate());

        assertEquals(USER_ID, captureEntityRequest.getValue().getUserId());

        assertEquals(cardData.getCardNumber(), captureCardNumber.getValue());

        assertEquals(1, captureParsedDatesAndNotes.getValue().getParsedNote().size());

        assertEquals(ServicingNoteFormat.NONOTIFICATIONS, captureServicingNoteFormat.getValue());
    }
    
    @Test
    public void retrieveTestNotesNull() {
        Card cardData = new Card();
        cardData.setCardNumber(CARD_NUMBER);
        cardData.setCustomerNumber(CUST_NUMBER);

        ParsedDatesAndNotes parsedDatesAndNotes = null;

        FraudExclusionRetrievalRequest request = new FraudExclusionRetrievalRequest();
        request.setServicingNotesFormat(ServicingNoteFormat.LATEST);

        EntityRequest entityRequest = new EntityRequest();
        entityRequest.setUserId(USER_ID);

        entityRequest.setClientCorrelationId("1234567");

        FraudExclusionRetrievalResponse expectedResponse = new FraudExclusionRetrievalResponse();
        expectedResponse.setCardActionCode(CardActionType.NONE);
        expectedResponse.setExclusionStartDate(START_DATE);
        expectedResponse.setExclusionEndDate(END_DATE);

        // * validator *
        ArgumentCaptor<FraudExclusionRetrievalRequest> captureRequest = ArgumentCaptor
                .forClass(FraudExclusionRetrievalRequest.class);
        ArgumentCaptor<EntityRequest> captureEntityRequest = ArgumentCaptor.forClass(EntityRequest.class);
        when(validator.validateAndRetrieveCard(captureRequest.capture(), captureEntityRequest.capture())).thenReturn(
                cardData);

        // * datesAndNotesBuilder *
        ArgumentCaptor<String> captureCardNumber = ArgumentCaptor.forClass(String.class);
        when(datesAndNotesBuilder.build(captureCardNumber.capture())).thenReturn(parsedDatesAndNotes);

        // * responseFormatter *
        ArgumentCaptor<ParsedDatesAndNotes> captureParsedDatesAndNotes = ArgumentCaptor
                .forClass(ParsedDatesAndNotes.class);
        ArgumentCaptor<ServicingNoteFormat> captureServicingNoteFormat = ArgumentCaptor
                .forClass(ServicingNoteFormat.class);
        when(responseFormatter.format(captureParsedDatesAndNotes.capture(), captureServicingNoteFormat.capture()))
                .thenReturn(expectedResponse);

        // * run the test *
        FraudExclusionRetrievalResponse actualResponse = service.retrieve(request, entityRequest);

        verify(validator, times(1)).validateAndRetrieveCard(captureRequest.capture(), captureEntityRequest.capture());
        verify(datesAndNotesBuilder, times(1)).build(captureCardNumber.capture());
        verify(responseFormatter, times(1)).format(captureParsedDatesAndNotes.capture(),
                captureServicingNoteFormat.capture());

        assertNotNull(actualResponse);
        assertEquals(expectedResponse.getServicingNoteFormat(), actualResponse.getServicingNoteFormat());
        assertEquals(expectedResponse.getExclusionStartDate(), actualResponse.getExclusionStartDate());
        assertEquals(expectedResponse.getExclusionEndDate(), actualResponse.getExclusionEndDate());

        assertEquals(USER_ID, captureEntityRequest.getValue().getUserId());

        assertEquals(cardData.getCardNumber(), captureCardNumber.getValue());

        assertEquals(ServicingNoteFormat.NONOTIFICATIONS, captureServicingNoteFormat.getValue());
    }
    
    
    @Test
    public void retrieveTestNoEndDate() {
        Card cardData = new Card();
        cardData.setCardNumber(CARD_NUMBER);
        cardData.setCustomerNumber(CUST_NUMBER);

        ParsedDatesAndNotes parsedDatesAndNotes = new ParsedDatesAndNotes();
        parsedDatesAndNotes.setExclusionStartDate(START_DATE);
        parsedDatesAndNotes.setExclusionEndDate(UNKNOWN);
        List<ParsedNote> parsedNotes = new ArrayList<ParsedNote>();
        ParsedNote parsedNote = new ParsedNote();
        parsedNote.setNote("note1");
        parsedNotes.add(parsedNote);
        parsedDatesAndNotes.setParsedNote(parsedNotes);

        FraudExclusionRetrievalRequest request = new FraudExclusionRetrievalRequest();
        request.setServicingNotesFormat(ServicingNoteFormat.LATEST);

        EntityRequest entityRequest = new EntityRequest();
        entityRequest.setUserId(USER_ID);

        entityRequest.setClientCorrelationId("1234567");

        // * validator *
        ArgumentCaptor<FraudExclusionRetrievalRequest> captureRequest = ArgumentCaptor
                .forClass(FraudExclusionRetrievalRequest.class);
        ArgumentCaptor<EntityRequest> captureEntityRequest = ArgumentCaptor.forClass(EntityRequest.class);
        when(validator.validateAndRetrieveCard(captureRequest.capture(), captureEntityRequest.capture())).thenReturn(
                cardData);

        // * datesAndNotesBuilder *
        ArgumentCaptor<String> captureCardNumber = ArgumentCaptor.forClass(String.class);
        when(datesAndNotesBuilder.build(captureCardNumber.capture())).thenReturn(parsedDatesAndNotes);

        // * responseFormatter *
        ArgumentCaptor<ParsedDatesAndNotes> captureParsedDatesAndNotes = ArgumentCaptor
                .forClass(ParsedDatesAndNotes.class);
        ArgumentCaptor<ServicingNoteFormat> captureServicingNoteFormat = ArgumentCaptor
                .forClass(ServicingNoteFormat.class);
        FraudExclusionRetrievalResponse expectedResponse = new FraudExclusionRetrievalResponse();
        expectedResponse.setServicingNoteFormat(ServicingNoteFormat.NONOTIFICATIONS);

        when(responseFormatter.format(captureParsedDatesAndNotes.capture(), captureServicingNoteFormat.capture()))
                .thenReturn(expectedResponse);
        FraudExclusionRetrievalResponse response = service.retrieve(request, entityRequest);
        assertEquals(ServicingNoteFormat.NONOTIFICATIONS, response.getServicingNoteFormat());

    }
    


    @Test
    public void retrieveTestNoStartDate() {
        Card cardData = new Card();
        cardData.setCardNumber(CARD_NUMBER);
        cardData.setCustomerNumber(CUST_NUMBER);

        ParsedDatesAndNotes parsedDatesAndNotes = new ParsedDatesAndNotes();
        parsedDatesAndNotes.setExclusionStartDate(UNKNOWN);
        parsedDatesAndNotes.setExclusionEndDate(END_DATE);
        List<ParsedNote> parsedNotes = new ArrayList<ParsedNote>();
        ParsedNote parsedNote = new ParsedNote();
        parsedNote.setNote("note1");
        parsedNotes.add(parsedNote);
        parsedDatesAndNotes.setParsedNote(parsedNotes);

        FraudExclusionRetrievalRequest request = new FraudExclusionRetrievalRequest();
        request.setServicingNotesFormat(ServicingNoteFormat.LATEST);

        EntityRequest entityRequest = new EntityRequest();
        entityRequest.setUserId(USER_ID);

        entityRequest.setClientCorrelationId("1234567");

        // * validator *
        ArgumentCaptor<FraudExclusionRetrievalRequest> captureRequest = ArgumentCaptor
                .forClass(FraudExclusionRetrievalRequest.class);
        ArgumentCaptor<EntityRequest> captureEntityRequest = ArgumentCaptor.forClass(EntityRequest.class);
        when(validator.validateAndRetrieveCard(captureRequest.capture(), captureEntityRequest.capture())).thenReturn(
                cardData);

        // * datesAndNotesBuilder *
        ArgumentCaptor<String> captureCardNumber = ArgumentCaptor.forClass(String.class);
        when(datesAndNotesBuilder.build(captureCardNumber.capture())).thenReturn(parsedDatesAndNotes);

        // * responseFormatter *
        ArgumentCaptor<ParsedDatesAndNotes> captureParsedDatesAndNotes = ArgumentCaptor
                .forClass(ParsedDatesAndNotes.class);
        ArgumentCaptor<ServicingNoteFormat> captureServicingNoteFormat = ArgumentCaptor
                .forClass(ServicingNoteFormat.class);
        FraudExclusionRetrievalResponse expectedResponse = new FraudExclusionRetrievalResponse();
        expectedResponse.setServicingNoteFormat(ServicingNoteFormat.NONOTIFICATIONS);

        when(responseFormatter.format(captureParsedDatesAndNotes.capture(), captureServicingNoteFormat.capture()))
                .thenReturn(expectedResponse);

        FraudExclusionRetrievalResponse response = service.retrieve(request, entityRequest);
        assertEquals(ServicingNoteFormat.NONOTIFICATIONS, response.getServicingNoteFormat());

    }

    @Test
    public void retrieveTestNoNotes() {
        Card cardData = new Card();
        cardData.setCardNumber(CARD_NUMBER);
        cardData.setCustomerNumber(CUST_NUMBER);

        ParsedDatesAndNotes parsedDatesAndNotes = new ParsedDatesAndNotes();
        parsedDatesAndNotes.setExclusionStartDate(START_DATE);
        parsedDatesAndNotes.setExclusionEndDate(END_DATE);
        List<ParsedNote> parsedNotes = new ArrayList<ParsedNote>();

        parsedDatesAndNotes.setParsedNote(parsedNotes);
        
        assertEquals("1930-05-011930-05-071930-05-070", parsedDatesAndNotes.toString());

        FraudExclusionRetrievalRequest request = new FraudExclusionRetrievalRequest();
        request.setServicingNotesFormat(ServicingNoteFormat.LATEST);

        EntityRequest entityRequest = new EntityRequest();
        entityRequest.setUserId(USER_ID);

        entityRequest.setClientCorrelationId("1234567");

        // * validator *
        ArgumentCaptor<FraudExclusionRetrievalRequest> captureRequest = ArgumentCaptor
                .forClass(FraudExclusionRetrievalRequest.class);
        ArgumentCaptor<EntityRequest> captureEntityRequest = ArgumentCaptor.forClass(EntityRequest.class);
        when(validator.validateAndRetrieveCard(captureRequest.capture(), captureEntityRequest.capture())).thenReturn(
                cardData);

        // * datesAndNotesBuilder *
        ArgumentCaptor<String> captureCardNumber = ArgumentCaptor.forClass(String.class);
        when(datesAndNotesBuilder.build(captureCardNumber.capture())).thenReturn(parsedDatesAndNotes);

        // * responseFormatter *
        ArgumentCaptor<ParsedDatesAndNotes> captureParsedDatesAndNotes = ArgumentCaptor
                .forClass(ParsedDatesAndNotes.class);
        ArgumentCaptor<ServicingNoteFormat> captureServicingNoteFormat = ArgumentCaptor
                .forClass(ServicingNoteFormat.class);
        FraudExclusionRetrievalResponse expectedResponse = new FraudExclusionRetrievalResponse();
        expectedResponse.setServicingNoteFormat(ServicingNoteFormat.NONOTIFICATIONS);

        when(responseFormatter.format(captureParsedDatesAndNotes.capture(), captureServicingNoteFormat.capture()))
                .thenReturn(expectedResponse);

        FraudExclusionRetrievalResponse response = service.retrieve(request, entityRequest);
        assertEquals(ServicingNoteFormat.NONOTIFICATIONS, response.getServicingNoteFormat());

    }

    @Test
    public void healthTest() {
        doNothing().when(pingUtil).pingProfile();
        doNothing().when(cardFraudExclusionDAO).isHealthy();

        service.health();

        verify(pingUtil, times(1)).pingProfile();
        verify(cardFraudExclusionDAO, times(1)).isHealthy();
    }
    
    @Test
    public void testCheckForNoDate() {
        ParsedDatesAndNotes parsedDatesAndNotes = new ParsedDatesAndNotes();
        parsedDatesAndNotes.setExclusionStartDate(START_DATE);
        parsedDatesAndNotes.setExclusionEndDate(END_DATE);
        List<ParsedNote> parsedNotes = new ArrayList<ParsedNote>();

        parsedDatesAndNotes.setParsedNote(parsedNotes);
        service.checkForNoDate(parsedDatesAndNotes);
        
        parsedDatesAndNotes.setExclusionStartDate(START_DATE);
        parsedDatesAndNotes.setExclusionEndDate("UNKNOWN");
        service.checkForNoDate(parsedDatesAndNotes);
        
        parsedDatesAndNotes.setExclusionStartDate(START_DATE);
        parsedDatesAndNotes.setExclusionEndDate(null);
        service.checkForNoDate(parsedDatesAndNotes);
        
        parsedDatesAndNotes.setExclusionStartDate("UNKNOWN");
        parsedDatesAndNotes.setExclusionEndDate(END_DATE);
        service.checkForNoDate(parsedDatesAndNotes);
        
        parsedDatesAndNotes.setExclusionStartDate(null);
        parsedDatesAndNotes.setExclusionEndDate(END_DATE);
        service.checkForNoDate(parsedDatesAndNotes);
        
        parsedDatesAndNotes.setExclusionStartDate(null);
        parsedDatesAndNotes.setExclusionEndDate(null);
        service.checkForNoDate(parsedDatesAndNotes);
        
        parsedDatesAndNotes.setExclusionStartDate("UNKNOWN");
        parsedDatesAndNotes.setExclusionEndDate("UNKNOWN");
        service.checkForNoDate(parsedDatesAndNotes);
    }
}
