package com.capitalone.api.card.service.dao.impl;

import static com.capitalone.api.card.service.constants.ErrorConstants.DEV_TXT_DATE_ROLLBACK;
import static com.capitalone.api.card.service.constants.ErrorConstants.UNEXPECTED_ERROR;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Appender;
import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggingEvent;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.util.Assert;

import com.capitalone.api.bank.lib.metavante.dao.MetavanteDAO;
import com.capitalone.api.bank.lib.metavante.model.AcctInqRequest;
import com.capitalone.api.bank.lib.metavante.model.AcctInqResponse;
import com.capitalone.api.bank.lib.metavante.model.AddnStat;
import com.capitalone.api.bank.lib.metavante.model.ArrayOfCardNumbers;
import com.capitalone.api.bank.lib.metavante.model.FraudExclusionDatesRequest;
import com.capitalone.api.bank.lib.metavante.model.FraudExclusionDatesResponse;
import com.capitalone.api.bank.lib.metavante.model.NotesRequest;
import com.capitalone.api.bank.lib.metavante.model.NotesResponse;
import com.capitalone.api.bank.lib.metavante.model.SearchCardsRequest;
import com.capitalone.api.bank.lib.metavante.model.SearchCardsResponse;
import com.capitalone.api.bank.lib.metavante.model.StatType;
import com.capitalone.api.card.service.constants.ErrorConstants;
import com.capitalone.api.card.service.exceptions.PartialApiException;
import com.capitalone.api.commons.exception.ApiErrorCode;
import com.capitalone.api.commons.exception.ApiSystemException;

public class CardFraudExclusionDAOImplTest {

    @InjectMocks
    CardFraudExclusionDAOImpl cardFraudExclusionDAO;

    @Mock
    private MetavanteDAO metavanteDAO;

    @Mock
    private Appender mockAppender;

    private static final String START_DATE = "1930-05-01";

    private static final String END_DATE = "1930-05-07";

    private static final String CARD_NUMBER = "42580482811";

    private static final String ACCT_NUMBER = "3543512222";

    private static final String NOTE = "Going to Italy - arrivederci!";

    private static final String NOTE_PREFIX = "AFNOTICE:05/01/30-05/07/30";

    private static final String FORMATTED_NOTE = NOTE_PREFIX + " " + NOTE;

    private static final String STAT_DESC = "TEST";

    private static final String EXCEPTION_MSG = "MOCK EXCEPTION";

    private static final String LOG_MOCK_EXCEPTION_MSG = "Unexpected Exception MOCK EXCEPTION";

    private static final String LOG_ROLLBACK_EXCEPTION_MSG = "rollback failed, service completed with partial success (dates are added but note failed)";

    private ArgumentCaptor<LoggingEvent> logMessageCaptor;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        Logger.getRootLogger().addAppender(mockAppender);
        logMessageCaptor = ArgumentCaptor.forClass(LoggingEvent.class);
    }

    @After
    public void tearDown() throws Exception {
        cardFraudExclusionDAO = null;
    }

    @Test
    public void isMetavanteCallSuccessTestAllCases() {
        StatType statType = new StatType();
        assertTrue(cardFraudExclusionDAO.wasMetavanteCallSuccess(statType));
        statType.setStatCd(1);
        assertFalse(cardFraudExclusionDAO.wasMetavanteCallSuccess(statType));
    }

    @Test
    public void addDatesForSuccess() {
        StatType successfulStatType = new StatType();
        successfulStatType.setStatDesc(STAT_DESC);

        FraudExclusionDatesResponse mockDatesResponse = mock(FraudExclusionDatesResponse.class);
        when(mockDatesResponse.getStatType()).thenReturn(successfulStatType);
        ArgumentCaptor<FraudExclusionDatesRequest> captureDatesRequest = ArgumentCaptor
                .forClass(FraudExclusionDatesRequest.class);
        when(metavanteDAO.addFraudExclusionDates(captureDatesRequest.capture())).thenReturn(mockDatesResponse);

        cardFraudExclusionDAO.addDates(CARD_NUMBER, START_DATE, END_DATE);

        verify(mockDatesResponse, times(1)).getStatType();
        verify(metavanteDAO, times(1)).addFraudExclusionDates(captureDatesRequest.capture());

        FraudExclusionDatesRequest datesRequest = captureDatesRequest.getAllValues().get(0);
        assertEquals(CARD_NUMBER, datesRequest.getCardNumber());
        assertEquals(START_DATE, datesRequest.getStartDate());
        assertEquals(END_DATE, datesRequest.getEndDate());
    }

    @Test
    public void addDatesForFailure() {
        when(metavanteDAO.addFraudExclusionDates(any(FraudExclusionDatesRequest.class))).thenThrow(
                new NullPointerException(EXCEPTION_MSG));

        boolean wasExceptionThrown = false;
        List<ApiErrorCode> apiErrorCodes = null;
        try {
            cardFraudExclusionDAO.addDates(CARD_NUMBER, START_DATE, END_DATE);
        } catch (ApiSystemException exception) {
            wasExceptionThrown = true;
            apiErrorCodes = exception.getApiError().getErrorDetails();
        }
        verify(metavanteDAO, times(1)).addFraudExclusionDates(any(FraudExclusionDatesRequest.class));
        verify(mockAppender, times(2)).doAppend(logMessageCaptor.capture());

        assertTrue(wasExceptionThrown);
        assertNotNull(apiErrorCodes);
        assertEquals(1, apiErrorCodes.size());
        ApiErrorCode apiErrorCode = apiErrorCodes.get(0);
        assertEquals(new Long(UNEXPECTED_ERROR).toString(), apiErrorCode.getId());
        assertEquals(EXCEPTION_MSG, apiErrorCode.getDeveloperText());

        List<LoggingEvent> loggingEvents = logMessageCaptor.getAllValues();
        assertEquals(2, loggingEvents.size());
    }

    @Test
    public void addNotesForSuccess() {
        StatType successfulStatType = new StatType();
        successfulStatType.setStatDesc(STAT_DESC);

        ArgumentCaptor<NotesRequest> captureNotesRequest = ArgumentCaptor.forClass(NotesRequest.class);
        NotesResponse mockNotesResponse = mock(NotesResponse.class);
        when(mockNotesResponse.getStatType()).thenReturn(successfulStatType);
        when(metavanteDAO.addNote(captureNotesRequest.capture())).thenReturn(mockNotesResponse);

        cardFraudExclusionDAO.addNote(CARD_NUMBER, START_DATE, END_DATE, FORMATTED_NOTE);

        verify(mockNotesResponse, times(1)).getStatType();
        verify(metavanteDAO, times(1)).addNote(captureNotesRequest.capture());

        NotesRequest notesRequest = captureNotesRequest.getAllValues().get(0);
        assertEquals(CARD_NUMBER, notesRequest.getCardNumber());
        assertEquals(FORMATTED_NOTE, notesRequest.getNote());
    }

    @Test
    public void addNotesForFailureAndRollbackSuccess() {
        StatType successfulStatType = new StatType();
        successfulStatType.setStatDesc(STAT_DESC);

        when(metavanteDAO.addNote(any(NotesRequest.class))).thenThrow(new NullPointerException(EXCEPTION_MSG));

        FraudExclusionDatesResponse mockResponse = mock(FraudExclusionDatesResponse.class);
        ArgumentCaptor<FraudExclusionDatesRequest> captureDatesRequest = ArgumentCaptor
                .forClass(FraudExclusionDatesRequest.class);
        when(metavanteDAO.deleteFraudExclusionDates(captureDatesRequest.capture())).thenReturn(mockResponse);
        when(mockResponse.getStatType()).thenReturn(successfulStatType);

        boolean wasExceptionThrown = false;
        List<ApiErrorCode> apiErrorCodes = null;

        try {
            cardFraudExclusionDAO.addNote(CARD_NUMBER, START_DATE, END_DATE, FORMATTED_NOTE);
        } catch (ApiSystemException exception) {
            wasExceptionThrown = true;
            apiErrorCodes = exception.getApiError().getErrorDetails();
        }
        verify(metavanteDAO, times(1)).addNote(any(NotesRequest.class));
        verify(metavanteDAO, times(1)).deleteFraudExclusionDates(captureDatesRequest.capture());
        verify(mockResponse, times(1)).getStatType();
        verify(mockAppender, times(2)).doAppend(logMessageCaptor.capture());

        FraudExclusionDatesRequest actualRequest = captureDatesRequest.getAllValues().get(0);
        assertEquals(CARD_NUMBER, actualRequest.getCardNumber());
        assertEquals(START_DATE, actualRequest.getStartDate());
        assertEquals(END_DATE, actualRequest.getEndDate());

        assertTrue(wasExceptionThrown);
        assertNotNull(apiErrorCodes);
        assertEquals(1, apiErrorCodes.size());
        ApiErrorCode apiErrorCode = apiErrorCodes.get(0);
        assertEquals(new Long(UNEXPECTED_ERROR).toString(), apiErrorCode.getId());
        assertEquals(EXCEPTION_MSG, apiErrorCode.getDeveloperText());

        List<LoggingEvent> loggingEvents = logMessageCaptor.getAllValues();
        assertEquals(2, loggingEvents.size());

    }

    @Test
    public void lookUpAcctByCardNumberSuccess() {
        StatType successfulStatType = new StatType();
        successfulStatType.setStatDesc(STAT_DESC);

        AcctInqResponse mockAcctInqResponse = mock(AcctInqResponse.class);
        when(mockAcctInqResponse.getStat()).thenReturn(successfulStatType);

        ArgumentCaptor<AcctInqRequest> captureAcctInquiryRequest = ArgumentCaptor.forClass(AcctInqRequest.class);

        when(metavanteDAO.accountInq(captureAcctInquiryRequest.capture())).thenReturn(mockAcctInqResponse);

        cardFraudExclusionDAO.lookUpAccountByCardNumber(CARD_NUMBER);

        verify(mockAcctInqResponse, times(1)).getStat();
        verify(metavanteDAO, times(1)).accountInq(captureAcctInquiryRequest.capture());
        assertEquals(CARD_NUMBER, captureAcctInquiryRequest.getAllValues().get(0).getCardNumber());
    }
    
    
    @Test(expected=ApiSystemException.class)
    public void lookUpAcctByCardNumberMtvFailure() {
        StatType successfulStatType = new StatType();
        successfulStatType.setStatCd(ErrorConstants.UNEXPECTED_ERROR);
        successfulStatType.setStatDesc("Error");

        AcctInqResponse mockAcctInqResponse = mock(AcctInqResponse.class);
        when(mockAcctInqResponse.getStat()).thenReturn(successfulStatType);

        ArgumentCaptor<AcctInqRequest> captureAcctInquiryRequest = ArgumentCaptor.forClass(AcctInqRequest.class);

        when(metavanteDAO.accountInq(captureAcctInquiryRequest.capture())).thenThrow(new RuntimeException());

        cardFraudExclusionDAO.lookUpAccountByCardNumber(CARD_NUMBER);
    }

    @Test
    public void lookUpAcctByCardNoFailure() {

        ArgumentCaptor<AcctInqRequest> captureAcctInquiryRequest = ArgumentCaptor.forClass(AcctInqRequest.class);
        when(metavanteDAO.accountInq(captureAcctInquiryRequest.capture())).thenThrow(
                new NullPointerException(EXCEPTION_MSG));

        boolean wasExceptionThrown = false;
        List<ApiErrorCode> apiErrorCodes = null;

        AcctInqResponse response = null;

        try {
            response = cardFraudExclusionDAO.lookUpAccountByCardNumber(CARD_NUMBER);
        } catch (ApiSystemException exception) {
            wasExceptionThrown = true;
            apiErrorCodes = exception.getApiError().getErrorDetails();
        }
        verify(metavanteDAO, times(1)).accountInq(any(AcctInqRequest.class));
        verify(mockAppender, times(2)).doAppend(logMessageCaptor.capture());
        assertTrue(wasExceptionThrown);
        assertNotNull(apiErrorCodes);
        assertEquals(1, apiErrorCodes.size());
        ApiErrorCode apiErrorCode = apiErrorCodes.get(0);
        assertEquals(new Long(UNEXPECTED_ERROR).toString(), apiErrorCode.getId());
        assertEquals(EXCEPTION_MSG, apiErrorCode.getDeveloperText());

        List<LoggingEvent> loggingEvents = logMessageCaptor.getAllValues();
        assertEquals(2, loggingEvents.size());
    }

    @Test
    public void findCardsByAccountNumberSucess() {
        StatType successfulStatType = new StatType();
        successfulStatType.setStatDesc(STAT_DESC);

        SearchCardsResponse mockSearchCardsResponse = mock(SearchCardsResponse.class);
        when(mockSearchCardsResponse.getStat()).thenReturn(successfulStatType);

        ArgumentCaptor<SearchCardsRequest> captureSearchCardsRequest = ArgumentCaptor
                .forClass(SearchCardsRequest.class);

        when(metavanteDAO.searchCards(captureSearchCardsRequest.capture())).thenReturn(mockSearchCardsResponse);

        cardFraudExclusionDAO.findCardsByAccountNumber(ACCT_NUMBER);

        verify(metavanteDAO, times(1)).searchCards(captureSearchCardsRequest.capture());
        assertEquals(ACCT_NUMBER, captureSearchCardsRequest.getAllValues().get(0).getAccountNumber());
    }

    @Test
    public void addNotesForFailureAndRollbackFailure() {
        when(metavanteDAO.addNote(any(NotesRequest.class))).thenThrow(new NullPointerException(EXCEPTION_MSG));

        FraudExclusionDatesResponse mockResponse = mock(FraudExclusionDatesResponse.class);
        when(metavanteDAO.deleteFraudExclusionDates(any(FraudExclusionDatesRequest.class))).thenThrow(
                new NullPointerException(EXCEPTION_MSG));

        ApiErrorCode apiErrorCode = null;
        try {
            cardFraudExclusionDAO.addNote(CARD_NUMBER, START_DATE, END_DATE, FORMATTED_NOTE);
        } catch (PartialApiException exception) {
            assertEquals(DEV_TXT_DATE_ROLLBACK, exception.getApiError().getDeveloperText());
            assertEquals(206, exception.getHttpStatusCode());
            apiErrorCode = exception.getApiError();
        }
        verify(metavanteDAO, times(1)).addNote(any(NotesRequest.class));
        verify(metavanteDAO, times(1)).deleteFraudExclusionDates(any(FraudExclusionDatesRequest.class));
        verify(mockResponse, never()).getStatType();
        verify(mockAppender, times(3)).doAppend(logMessageCaptor.capture());

        assertNotNull(apiErrorCode);

        List<LoggingEvent> loggingEvents = logMessageCaptor.getAllValues();
        assertEquals(3, loggingEvents.size());

    }

    @Test
    public void getDatesForSuccess() {
        StatType successfulStatType = new StatType();
        successfulStatType.setStatDesc(STAT_DESC);

        FraudExclusionDatesResponse mockDatesResponse = mock(FraudExclusionDatesResponse.class);
        when(mockDatesResponse.getStatType()).thenReturn(successfulStatType);
        ArgumentCaptor<FraudExclusionDatesRequest> captureDatesRequest = ArgumentCaptor
                .forClass(FraudExclusionDatesRequest.class);
        when(metavanteDAO.getFraudExclusionDates(captureDatesRequest.capture())).thenReturn(mockDatesResponse);

        cardFraudExclusionDAO.getDates(CARD_NUMBER);

        verify(mockDatesResponse, times(1)).getStatType();
        verify(metavanteDAO, times(1)).getFraudExclusionDates(captureDatesRequest.capture());
        assertEquals(CARD_NUMBER, captureDatesRequest.getAllValues().get(0).getCardNumber());
    }
    
    @Test
    public void getDatesForAddnStat() {        
        StatType statType = new StatType();
        AddnStat addnStat = new AddnStat();
        addnStat.setNativeErrorCd("1");
        addnStat.setStatDesc("1055-FRAUD EXCLUSION DATE INFORMATION NOT FOUND");
        List<AddnStat> lAddnStats = new ArrayList<AddnStat>();
        lAddnStats.add(addnStat);
        statType.setAddnStat(lAddnStats);

        FraudExclusionDatesResponse mockDatesResponse = mock(FraudExclusionDatesResponse.class);
        when(mockDatesResponse.getStatType()).thenReturn(statType);
        ArgumentCaptor<FraudExclusionDatesRequest> captureDatesRequest = ArgumentCaptor
                .forClass(FraudExclusionDatesRequest.class);
        when(metavanteDAO.getFraudExclusionDates(captureDatesRequest.capture())).thenReturn(mockDatesResponse);

        cardFraudExclusionDAO.getDates(CARD_NUMBER);

        verify(mockDatesResponse, times(1)).getStatType();
        verify(metavanteDAO, times(1)).getFraudExclusionDates(captureDatesRequest.capture());
        assertEquals(CARD_NUMBER, captureDatesRequest.getAllValues().get(0).getCardNumber());
    }
    
    @Test
    public void getDatesForAddnStat2() {        
        StatType statType = new StatType();
        AddnStat addnStat = new AddnStat();
        addnStat.setNativeErrorCd("1");
        addnStat.setStatDesc("Error");
        List<AddnStat> lAddnStats = new ArrayList<AddnStat>();
        lAddnStats.add(addnStat);
        statType.setAddnStat(lAddnStats);

        FraudExclusionDatesResponse mockDatesResponse = mock(FraudExclusionDatesResponse.class);
        when(mockDatesResponse.getStatType()).thenReturn(statType);
        ArgumentCaptor<FraudExclusionDatesRequest> captureDatesRequest = ArgumentCaptor
                .forClass(FraudExclusionDatesRequest.class);
        when(metavanteDAO.getFraudExclusionDates(captureDatesRequest.capture())).thenReturn(mockDatesResponse);

        cardFraudExclusionDAO.getDates(CARD_NUMBER);

        verify(mockDatesResponse, times(1)).getStatType();
        verify(metavanteDAO, times(1)).getFraudExclusionDates(captureDatesRequest.capture());
        assertEquals(CARD_NUMBER, captureDatesRequest.getAllValues().get(0).getCardNumber());
    }

    @Test
    public void getDatesForFailure() {
        when(metavanteDAO.getFraudExclusionDates(any(FraudExclusionDatesRequest.class))).thenThrow(
                new NullPointerException(EXCEPTION_MSG));
        boolean wasExceptionThrown = false;
        List<ApiErrorCode> apiErrorCodes = null;

        FraudExclusionDatesResponse response = null;

        try {
            response = cardFraudExclusionDAO.getDates(CARD_NUMBER);
        } catch (ApiSystemException exception) {
            wasExceptionThrown = true;
            apiErrorCodes = exception.getApiError().getErrorDetails();
        }
        verify(metavanteDAO, times(1)).getFraudExclusionDates(any(FraudExclusionDatesRequest.class));
        verify(mockAppender, times(2)).doAppend(logMessageCaptor.capture());
        assertTrue(wasExceptionThrown);
        assertNotNull(apiErrorCodes);
        assertEquals(1, apiErrorCodes.size());
        ApiErrorCode apiErrorCode = apiErrorCodes.get(0);
        assertEquals(new Long(UNEXPECTED_ERROR).toString(), apiErrorCode.getId());
        assertEquals(EXCEPTION_MSG, apiErrorCode.getDeveloperText());

        List<LoggingEvent> loggingEvents = logMessageCaptor.getAllValues();
        assertEquals(2, loggingEvents.size());
    }

    @Test
    public void getNotesForSuccess() {
        StatType successfulStatType = new StatType();
        successfulStatType.setStatDesc(STAT_DESC);

        ArgumentCaptor<NotesRequest> captureNotesRequest = ArgumentCaptor.forClass(NotesRequest.class);
        NotesResponse mockNotesResponse = mock(NotesResponse.class);

        when(mockNotesResponse.getStatType()).thenReturn(successfulStatType);
        when(metavanteDAO.getNotes(captureNotesRequest.capture())).thenReturn(mockNotesResponse);

        cardFraudExclusionDAO.getNotes(CARD_NUMBER);

        verify(mockNotesResponse, times(1)).getStatType();
        verify(metavanteDAO, times(1)).getNotes(captureNotesRequest.capture());

        NotesRequest notesRequest = captureNotesRequest.getAllValues().get(0);
        assertEquals(CARD_NUMBER, notesRequest.getCardNumber());
    }

    @Test
    public void getNotesForFailure() {
        when(metavanteDAO.getNotes(any(NotesRequest.class))).thenThrow(new NullPointerException(EXCEPTION_MSG));

        boolean wasExceptionThrown = false;
        List<ApiErrorCode> apiErrorCodes = null;

        NotesResponse response = null;
        try {
            response = cardFraudExclusionDAO.getNotes(CARD_NUMBER);
        } catch (ApiSystemException exception) {
            wasExceptionThrown = true;
            apiErrorCodes = exception.getApiError().getErrorDetails();
        }
        verify(metavanteDAO, times(1)).getNotes(any(NotesRequest.class));
        verify(mockAppender, times(2)).doAppend(logMessageCaptor.capture());
        assertTrue(wasExceptionThrown);
        assertNotNull(apiErrorCodes);
        assertEquals(1, apiErrorCodes.size());
        ApiErrorCode apiErrorCode = apiErrorCodes.get(0);
        assertEquals(new Long(UNEXPECTED_ERROR).toString(), apiErrorCode.getId());
        assertEquals(EXCEPTION_MSG, apiErrorCode.getDeveloperText());

        List<LoggingEvent> loggingEvents = logMessageCaptor.getAllValues();
        assertEquals(2, loggingEvents.size());
    }

    @Test
    public void testIsHealthySuccess() {
        when(metavanteDAO.isHealthy()).thenReturn(true);
        cardFraudExclusionDAO.isHealthy();
        verify(metavanteDAO, times(1)).isHealthy();
    }

    @Test
    public void testIsHealthyFailure() {
        boolean wasExceptionThrown = false;
        List<ApiErrorCode> apiErrorCodes = null;

        when(metavanteDAO.isHealthy()).thenReturn(false);
        try {
            cardFraudExclusionDAO.isHealthy();
        } catch (ApiSystemException exception) {
            wasExceptionThrown = true;
            apiErrorCodes = exception.getApiError().getErrorDetails();
        }

        verify(metavanteDAO, times(1)).isHealthy();
        assertTrue(wasExceptionThrown);
        assertNotNull(apiErrorCodes);

    }

    @Test
    public void testFindCardSuccess() {

        ArgumentCaptor<SearchCardsRequest> captureSearchCardsRequest = ArgumentCaptor
                .forClass(SearchCardsRequest.class);

        when(metavanteDAO.searchCards(captureSearchCardsRequest.capture())).thenReturn(getMockSearchResponse());

        ArrayOfCardNumbers foundCard = cardFraudExclusionDAO.findCard(ACCT_NUMBER, "123456", "9012");

        assertEquals("123456789012", foundCard.getCardNumber());

    }

    @Test
    public void testFindCardException() {

        boolean wasExceptionThrown = false;

        ArgumentCaptor<SearchCardsRequest> captureSearchCardsRequest = ArgumentCaptor
                .forClass(SearchCardsRequest.class);

        when(metavanteDAO.searchCards(captureSearchCardsRequest.capture())).thenReturn(null);

        try {
            cardFraudExclusionDAO.findCard(ACCT_NUMBER, "123456", "9012");
        } catch (ApiSystemException exception) {
            wasExceptionThrown = true;
        }
        assertTrue(wasExceptionThrown);

    }

    @Test
    public void testFindCardNotFound() {

        ArgumentCaptor<SearchCardsRequest> captureSearchCardsRequest = ArgumentCaptor
                .forClass(SearchCardsRequest.class);

        when(metavanteDAO.searchCards(captureSearchCardsRequest.capture())).thenReturn(getMockSearchResponse());

        ArrayOfCardNumbers foundCard = cardFraudExclusionDAO.findCard(ACCT_NUMBER, "123457", "9012");

        assertNull(foundCard);

    }

    @Test
    public void testFindCardLastFourNotFound() {

        ArgumentCaptor<SearchCardsRequest> captureSearchCardsRequest = ArgumentCaptor
                .forClass(SearchCardsRequest.class);

        when(metavanteDAO.searchCards(captureSearchCardsRequest.capture())).thenReturn(getMockSearchResponse());

        ArrayOfCardNumbers foundCard = cardFraudExclusionDAO.findCard(ACCT_NUMBER, "123456", "7012");

        assertNull(foundCard);

    }

    @Test
    public void find(){
        StatType successfulStatType = new StatType();
        successfulStatType.setStatDesc(STAT_DESC);

        SearchCardsResponse mockSearchCardsResponse=mock( SearchCardsResponse.class);
        when(mockSearchCardsResponse.getStat()).thenReturn(successfulStatType);

        ArgumentCaptor<SearchCardsRequest> captureSearchCardsRequest = ArgumentCaptor
                .forClass(SearchCardsRequest.class);

        when(metavanteDAO.searchCards(captureSearchCardsRequest.capture())).thenReturn(mockSearchCardsResponse);

        cardFraudExclusionDAO.findCard(ACCT_NUMBER, "", "");

        verify(metavanteDAO, times(1)).searchCards(captureSearchCardsRequest.capture());
        assertEquals(ACCT_NUMBER,captureSearchCardsRequest.getAllValues().get(0).getAccountNumber());
    }
    
    @Test (expected = ApiSystemException.class)
    public void findNotSuccessful(){
        StatType successfulStatType = new StatType();
        successfulStatType.setStatDesc("Error");
        successfulStatType.setStatCd(100);

        SearchCardsResponse mockSearchCardsResponse=mock( SearchCardsResponse.class);
        when(mockSearchCardsResponse.getStat()).thenReturn(successfulStatType);

        ArgumentCaptor<SearchCardsRequest> captureSearchCardsRequest = ArgumentCaptor
                .forClass(SearchCardsRequest.class);

        when(metavanteDAO.searchCards(captureSearchCardsRequest.capture())).thenReturn(mockSearchCardsResponse);

        cardFraudExclusionDAO.findCard(ACCT_NUMBER, "", "");

        verify(metavanteDAO, times(1)).searchCards(captureSearchCardsRequest.capture());
       
    }

    private SearchCardsResponse getMockSearchResponse() {
        StatType successfulStatType = new StatType();
        successfulStatType.setStatDesc(STAT_DESC);
        SearchCardsResponse mockSearchResponse = new SearchCardsResponse();

        mockSearchResponse.setStat(successfulStatType);

        ArrayOfCardNumbers arrayOfCardNumbers1 = new ArrayOfCardNumbers();
        arrayOfCardNumbers1.setCardNumber("123456789012");
        mockSearchResponse.getArrayOfCardNumbers().add(arrayOfCardNumbers1);

        ArrayOfCardNumbers arrayOfCardNumbers2 = new ArrayOfCardNumbers();
        arrayOfCardNumbers2.setCardNumber("432156789012");
        mockSearchResponse.getArrayOfCardNumbers().add(arrayOfCardNumbers2);
        return mockSearchResponse;
    }
    
    @Test
    public void testWasMetavanteCallSuccess() {
        StatType successfulStatType = new StatType();
        successfulStatType.setStatDesc(STAT_DESC);
        successfulStatType.setStatCd(0);
        Assert.isTrue(cardFraudExclusionDAO.wasMetavanteCallSuccess(successfulStatType));
        
        StatType notSuccessfulStatType = new StatType();
        notSuccessfulStatType.setStatDesc(STAT_DESC);
        notSuccessfulStatType.setStatCd(100);
        Assert.isTrue(!cardFraudExclusionDAO.wasMetavanteCallSuccess(notSuccessfulStatType));
        
        StatType nullStatType = null;
        Assert.isTrue(!cardFraudExclusionDAO.wasMetavanteCallSuccess(nullStatType));
    }
    
    @Test
    public void testIsHealthy() {
        when(metavanteDAO.isHealthy()).thenReturn(true);
        cardFraudExclusionDAO.isHealthy();
    }
    
    @Test(expected = ApiSystemException.class)
    public void testIsHealthyNo() {
        when(metavanteDAO.isHealthy()).thenReturn(false);
        cardFraudExclusionDAO.isHealthy();
    }
    
    @Test
    public void testFirstSixOfCard() {
        Assert.isTrue(cardFraudExclusionDAO.firstSixOfCard("").equals(""));
        Assert.isTrue(cardFraudExclusionDAO.firstSixOfCard("4321").equals(""));
        Assert.isTrue(cardFraudExclusionDAO.firstSixOfCard("43215").equals(""));
        Assert.isTrue(cardFraudExclusionDAO.firstSixOfCard("12345678901").equals("123456"));
    }
    
    @Test
    public void testLastFourOfCard() {
        Assert.isTrue(cardFraudExclusionDAO.lastFourOfCard("").equals(""));
        Assert.isTrue(cardFraudExclusionDAO.lastFourOfCard("4321").equals(""));
        Assert.isTrue(cardFraudExclusionDAO.lastFourOfCard("43215").equals(""));
        Assert.isTrue(cardFraudExclusionDAO.lastFourOfCard("12345678901").equals("8901"));
    }
}
