package com.capitalone.api.card.service.util.activities;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.MockitoAnnotations.initMocks;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.capitalone.api.card.model.v3.FraudExclusionRequest;
import com.capitalone.api.commons.model.EntityRequest;
import com.capitalone.epf.context.model.EPFContext;

public class DatesActivityWriterTest {

    private static final String INTERACTION_ID = "1234567";

    private static final String USER_ID = "zxy349";

    @InjectMocks
    private DatesActivityWriter datesActivityWriter;

    @Mock
    private ExclusionDatesActivity exclusionDatesActivity;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
    }

    @Test
    public void testWriteSuccess() {

        EPFContext epfContext = new EPFContext();
        epfContext.setUserId(USER_ID);

        FraudExclusionRequest request = new FraudExclusionRequest();

        EntityRequest entityRequest = new EntityRequest();
        entityRequest.setClientCorrelationId(INTERACTION_ID);
        entityRequest.setUserId(USER_ID);

        doNothing().when(exclusionDatesActivity).async(epfContext, request, "1234","123456789","1234567");
        datesActivityWriter.write(epfContext, request, entityRequest,"123456789","1234567");

        verify(exclusionDatesActivity, times(1)).async(epfContext, request, "123456789","1234567","1234567");
    }

}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */