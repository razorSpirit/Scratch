package com.capitalone.api.card.model.v3;


public enum ServicingNoteFormat {

    ALL("ALL"), LATEST("LATEST"), HISTORY("HISTORY"), NONOTIFICATIONS("NONOTIFICATIONS"), NONE("NONE");
    
    private String value;
    
    ServicingNoteFormat(String value){
    	this.value = value;
    }
    
    public static ServicingNoteFormat getEnum(String value) {
        for(ServicingNoteFormat format : values())
            if(format.getValue().equalsIgnoreCase(value))
            	return format;
        return NONE;
    }

	public String getValue() {
		return value;
	}

}