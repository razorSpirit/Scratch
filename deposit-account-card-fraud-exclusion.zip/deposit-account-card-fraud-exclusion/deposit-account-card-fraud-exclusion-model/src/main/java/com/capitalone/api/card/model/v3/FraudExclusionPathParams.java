package com.capitalone.api.card.model.v3;

import java.io.Serializable;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.capitalone.api.model.id.AccountReferenceId;
import com.capitalone.api.model.id.CardReferenceId;
import com.capitalone.api.model.id.ReferenceId;
import com.capitalone.epf.audit.annotation.Audited;
import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiParam;

/**
 * Bean to store the request ; extends from EntityRequest.
 * 
 * @author svo905 -
 * @since 1.0
 */
@Audited
@ApiModel(value = "Represents a request to exclude a card from fraud for a date range for Capital One")
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class FraudExclusionPathParams implements Serializable {

	private static final long serialVersionUID = 7087620422088774694L;

	private AccountReferenceId accountReferenceId;

	private CardReferenceId cardReferenceId;

	@ApiParam(value = "The format of the response includes ALL, LATEST, HISTORY.", name = "servicingNotesFormat", required = false, allowMultiple = false)
    @QueryParam("servicingNotesFormat")
    @DefaultValue("ALL")
    private String servicingNotesFormat;

	public AccountReferenceId getAccountReferenceId() {
		return accountReferenceId;
	}

	public CardReferenceId getCardReferenceId() {
		return cardReferenceId;
	}

	public ServicingNoteFormat getServicingNotesFormat(){
    	return ServicingNoteFormat.getEnum(servicingNotesFormat);
    }

    @ApiParam(value = "This identifier is a combination of SORID and Account Number. We need the SORID in orchestration to determine whether workflow is 360 and the account number is used to retrieve the debit card associated with an account.", name = "accountReferenceId", required = true, allowMultiple = false, defaultValue = "B9OfkiiPKEIVsVas%2FZLtkYgFzsxPuRCmX4Up%2B2%2FaeQ58xzYbMmbnVhPYdbcyHMg0")
	@PathParam("accountReferenceId")
	public void setAccountReferenceId(ReferenceId referenceId) {
		this.accountReferenceId = new AccountReferenceId(referenceId);
	}
    
    @ApiParam(value = "This denotes a unique number identifying the card in the cards collection.", name = "cardReferenceId", required = true, allowMultiple = false, defaultValue = "B9OfkiiPKEIVsVas%2FZLtkT9fy%2BZPJsGKXujbO4KStQZyTMoDbMSoObxXTdi8xNW4mcpI8yFdiyWYbAliTB8RNBctI7VstM%2FYPPodq5UbzgY%3D")
	@PathParam("cardReferenceId")
	public void setCardReferenceId(ReferenceId referenceId) {
		this.cardReferenceId = new CardReferenceId(referenceId);
	}
}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of
 * Capital One and is protected by law. It may not be copied or distributed in
 * any form or medium, disclosed to third parties, reverse engineered or used in
 * any manner without prior written authorization from Capital One.
 */
