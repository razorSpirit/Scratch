package com.capitalone.api.card.model.v3;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;

import com.capitalone.api.model.id.AccountReferenceId;
import com.capitalone.api.model.id.CardReferenceId;

/**
 * Bean to store the request ; extends from EntityRequest.
 * 
 * @author svo905 -
 * @since 1.0
 */

public class FraudExclusionRequest implements Serializable {

    private static final long serialVersionUID = -5187448317075229301L;

    private String exclusionStartDate;

    private String exclusionEndDate;

    private String cardActionCode;

    private String servicingNotes;

    private Boolean isEmailResponseRequired = false;

    private AccountReferenceId accountReferenceId;

    private CardReferenceId cardReferenceId;

    public String getExclusionStartDate() {
        return exclusionStartDate;
    }

    public void setExclusionStartDate(String exclusionStartDate) {
        this.exclusionStartDate = exclusionStartDate;
    }

    public String getExclusionEndDate() {
        return exclusionEndDate;
    }

    public void setExclusionEndDate(String exclusionEndDate) {
        this.exclusionEndDate = exclusionEndDate;
    }

    public String getCardActionCode() {
        return cardActionCode;
    }

    public void setCardActionCode(String cardActionCode) {
        this.cardActionCode = cardActionCode;
    }

    public String getServicingNotes() {
        return servicingNotes;
    }

    public void setServicingNotes(String servicingNotes) {
        this.servicingNotes = servicingNotes;
    }

    public Boolean isEmailResponseRequired() {
        return isEmailResponseRequired;
    }

    public void setIsEmailResponseRequired(Boolean isEmailResponseRequired) {
        this.isEmailResponseRequired = isEmailResponseRequired;
    }

    public AccountReferenceId getAccountReferenceId() {
        return accountReferenceId;
    }

    public void setAccountReferenceId(AccountReferenceId accountReferenceId) {
        this.accountReferenceId = accountReferenceId;
    }

    public String getAccountNumber() {
        return accountReferenceId.getAccountId();
    }

    public String getSorId() {
        return accountReferenceId.getSystemOfRecordId();
    }

    public String getReferenceIdValue() {
        return accountReferenceId.getReferenceId().getValue();
    }

    public CardReferenceId getCardReferenceId() {
        return cardReferenceId;
    }

    public void setCardReferenceId(CardReferenceId cardReferenceId) {
        this.cardReferenceId = cardReferenceId;
    }

    public CardActionType getCardActionType() {
        return CardActionType.valueFor(cardActionCode);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(safeString(exclusionStartDate)).append(safeString(exclusionEndDate))
                .append(safeString(cardActionCode)).append(safeString(servicingNotes));
        return sb.toString();
    }

    private String safeString(String value) {
        return StringUtils.isEmpty(value) ? "" : value;
    }
}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
