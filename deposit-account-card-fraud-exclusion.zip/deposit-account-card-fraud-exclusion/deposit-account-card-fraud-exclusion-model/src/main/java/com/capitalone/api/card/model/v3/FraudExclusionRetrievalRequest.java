package com.capitalone.api.card.model.v3;
import java.io.Serializable;

import com.capitalone.api.model.id.AccountReferenceId;
import com.capitalone.api.model.id.CardReferenceId;

/**
 * Bean to store the request for the GET ; extends from EntityRequest.
 * 
 * @author svo905 -
 * @since 1.0
 */

public class FraudExclusionRetrievalRequest implements Serializable {

	private static final long serialVersionUID = 1L;	

    private AccountReferenceId accountReferenceId;
    private CardReferenceId cardReferenceId;
    private ServicingNoteFormat servicingNotesFormat;

    public AccountReferenceId getAccountReferenceId() {
        return accountReferenceId;
    }

    public void setAccountReferenceId(AccountReferenceId accountReferenceId) {
        this.accountReferenceId = accountReferenceId;    
    }
    
	public String getAccountNumber() {
        return accountReferenceId.getAccountId();
    }

    public String getSorId() {
        return accountReferenceId.getSystemOfRecordId();
    }

    public String getReferenceIdValue() {
        return accountReferenceId.getReferenceId().getValue();
    }	

    public CardReferenceId getCardReferenceId() {
        return cardReferenceId;
    }
    
    public void setCardReferenceId(CardReferenceId cardReferenceId) {
        this.cardReferenceId = cardReferenceId;
    }

	public ServicingNoteFormat getServicingNotesFormat() {
		return servicingNotesFormat;
	}

	public void setServicingNotesFormat(ServicingNoteFormat servicingNotesFormat) {
		this.servicingNotesFormat = servicingNotesFormat;
	} 
	
}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
