/**
 * Model classes for deposit-account-card-fraud-exclusion functionality.
 */
package com.capitalone.api.card.model.v3;