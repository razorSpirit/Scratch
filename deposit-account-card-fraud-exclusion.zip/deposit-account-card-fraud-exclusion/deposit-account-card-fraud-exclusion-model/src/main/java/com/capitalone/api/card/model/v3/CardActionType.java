package com.capitalone.api.card.model.v3;

import java.util.HashMap;
import java.util.Map;

public enum CardActionType {
    TRAVEL_NOTIFICATION("TravelNotification", "TRAVLNOTE", "TRAVEL NOTIFICATION"),
    ANTI_FRAUD_SERVICING("AntiFraudServicing", "AFNOTICE", "TRANSACTION VERIFICATION"),
    OTHER("OTHER", "OTHER", "OTHER"),
    NONE("NONE", "NONE", "NONE");

    private final String code;

    private final String notesCode;

    private final String description;

    private static Map<String, CardActionType> types = new HashMap<String, CardActionType>();

    private static Map<String, CardActionType> noteTypes = new HashMap<String, CardActionType>();

    static {
        for (CardActionType type : CardActionType.values()) {
            types.put(type.code, type);
        }
        for (CardActionType type : CardActionType.values()) {
            noteTypes.put(type.notesCode, type);
        }
    }

    CardActionType(String type, String noteCode, String description) {
        code = type;
        notesCode = noteCode;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getNotesCode() {
        return notesCode;
    }

    public static CardActionType valueFor(String code) {
        CardActionType type = types.get(code);
        return null == type ? CardActionType.NONE : type;
    }

    public static CardActionType valueForNotesCode(String noteCode) {
        CardActionType type = noteTypes.get(noteCode);
        return null == type ? CardActionType.NONE : type;
    }

    public String getDescription() {
        return description;
    }
}