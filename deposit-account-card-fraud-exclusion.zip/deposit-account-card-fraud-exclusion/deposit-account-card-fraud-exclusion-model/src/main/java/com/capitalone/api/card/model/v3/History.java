package com.capitalone.api.card.model.v3;

import java.io.Serializable;
import java.util.List;

public class History implements Serializable {

	private static final long serialVersionUID = 1L;

	private String startDate;

    private String endDate;

    private CardActionType cardActionType;

    private List<FraudExclusionNoteDetail> servicingNotes;

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public List<FraudExclusionNoteDetail> getServicingNotes() {
        return servicingNotes;
    }

    public void setServicingNotes(List<FraudExclusionNoteDetail> servicingNotes) {
        this.servicingNotes = servicingNotes;
    }

    public CardActionType getCardActionType() {
        return cardActionType;
    }

    public void setCardActionType(CardActionType cardActionType) {
        this.cardActionType = cardActionType;
    }

}
