package com.capitalone.api.card.model.v3;

import java.io.Serializable;

public class FraudExclusionNoteDetail implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int lineNumber;
	private String note;
	
	public FraudExclusionNoteDetail() {
		//default constructor
		super();
	}
	
	public FraudExclusionNoteDetail(int lineNumber, String note) {
		this.lineNumber = lineNumber;
		this.note = note;
	}
	
	public int getServicingNotesLineNumber() {
		return lineNumber;
	}
	public void setServicingNotesLineNumber(int lineNumber) {
		this.lineNumber = lineNumber;
	}
	public String getServicingNote() {
		return note;
	}
	public void setServicingNote(String note) {
		this.note = note;
	}
}