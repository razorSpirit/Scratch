package com.capitalone.api.card.model.v3;

import java.io.Serializable;

import javax.ws.rs.HeaderParam;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.capitalone.epf.audit.annotation.Audited;
import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiParam;

/**
 * Bean to store the request ; extends from EntityRequest.
 * 
 * @author moh295 -
 * @since 1.0
 */

@Audited
@ApiModel(value = "Represents a request to exclude a card from fraud for a date range for Capital One")
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class FraudExclusionHeaderParams implements Serializable {

	private static final long serialVersionUID = 8087620422088774694L;

	private String userId;
	private String apiKey;
	private String clientCorrelationId;

	@ApiParam(defaultValue = "221655", value = "Unique identifier of the end user making the request. This could be a customer service representative or the customer themselves.  In case the request is coming from customer this field will be set with some pre-defined value.  e.g for client Transite this field should always be populated as 'Transite'", required = true, allowMultiple = false)
	@HeaderParam("User-Id")
	public void setUserId(String id) {
		this.userId = id;
	}

	public String getUserId() {
		return userId;
	}


	@ApiParam(defaultValue = "MOBILE", value = "TRANSITE or SASSY. This will be used to identify 'operated by' for the activity.  If client is is sending SASSY then User-Id will be used to log the activity in activity table.  If client is sending TRANSITE then 'TRANSITE' will be used to log the activity in activity table.", required = true, allowMultiple = false)
	@HeaderParam("Api-Key")
	public void setApiKey(String key) {
		this.apiKey = key;
	}

	public String getApiKey() {
		return apiKey;
	}


	@ApiParam(defaultValue = "99998888", value = "A client-generated ID that can be used to tie together everything a customer has done per login.", required = true, allowMultiple = false)
	@HeaderParam(value = "Client-Correlation-Id")
	public void setClientCorrelationId(String correlationId) {
		this.clientCorrelationId = correlationId;
	}

	public String getClientCorrelationId() {
		return clientCorrelationId;
	}

}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of
 * Capital One and is protected by law. It may not be copied or distributed in
 * any form or medium, disclosed to third parties, reverse engineered or used in
 * any manner without prior written authorization from Capital One.
 */