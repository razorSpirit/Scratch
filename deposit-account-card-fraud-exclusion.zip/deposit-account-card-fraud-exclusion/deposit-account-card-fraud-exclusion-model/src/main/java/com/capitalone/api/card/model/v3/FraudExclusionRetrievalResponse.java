package com.capitalone.api.card.model.v3;
import java.io.Serializable;
import java.util.List;

/**
 * Bean to store the response for the GET 
 * 
 * @author svo905 -
 * @since 1.0
 */

public class FraudExclusionRetrievalResponse implements Serializable {

	private static final long serialVersionUID = 1L;	
    private String exclusionStartDate;
    private String exclusionEndDate;
    private CardActionType cardActionType;
    private List<FraudExclusionNoteDetail> servicingNotes;
    private ServicingNoteFormat format;
    private List<History> history;


	public ServicingNoteFormat getServicingNoteFormat() {
		return format;
	}

	public void setServicingNoteFormat(ServicingNoteFormat format) {
		this.format = format;
	}

	public String getExclusionStartDate() {
		return exclusionStartDate;
	}

	public void setExclusionStartDate(String exclusionStartDate) {
		this.exclusionStartDate = exclusionStartDate;
	}

	public String getExclusionEndDate() {
		return exclusionEndDate;
	}

	public void setExclusionEndDate(String exclusionEndDate) {
		this.exclusionEndDate = exclusionEndDate;
	}

	public List<FraudExclusionNoteDetail> getServicingNotes() {
		return servicingNotes;
	}

	public void setServicingNotes(List<FraudExclusionNoteDetail> servicingNotes) {
		this.servicingNotes = servicingNotes;
	}

	public List<History> getHistory() {
		return history;
	}

	public void setHistory(List<History> history) {
		this.history = history;
	}

	public CardActionType getCardActionCode() {
		return cardActionType;
	}

	public void setCardActionCode(CardActionType cardActionType) {
		this.cardActionType = cardActionType;
	}    

}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
