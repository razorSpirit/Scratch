WESPSITE


....+SpringXX
....+....+local-logs
....+....+....+myaccount
....+....+....+openaccount
....+....+....+wespdgw  
....+....+local-settings

....+....+TranSite
....+....+WespSite 