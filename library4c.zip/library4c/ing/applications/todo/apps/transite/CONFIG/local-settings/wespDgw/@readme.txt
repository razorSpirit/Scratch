Edits:

dgw.properties :
       MQ settings
       Oracle, Profile, RSA

dgw-logging.properties :
   @logdir to C:/root/dev/workSpace-Europa/sprintXX/local-logs/wespdgw