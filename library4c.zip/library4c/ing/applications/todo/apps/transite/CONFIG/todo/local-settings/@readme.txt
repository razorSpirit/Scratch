
ref:
  <001> http://groups.google.com/group/riotfamily/browse_thread/thread/9a0edf69575d3ab6
  <002> http://forum.springframework.org/archive/index.php/t-24073.html
  
problem:  

java.lang.IllegalStateException: Web app root system property already set to different value: 'webapp.root' = [C:\root\dev\workSpace-Europa\transite\.metadata\.plugins\org.eclipse.wst.server.core\tmp0\wtpwebapps\TranSiteTPW\] instead of [C:\root\dev\workSpace-Europa\transite\.metadata\.plugins\org.eclipse.wst.server.core\tmp0\wtpwebapps\OpenAccountTPW\] - Choose unique values for the 'webAppRootKey' context-param in your web.xml files!


java.lang.IllegalStateException: 
   Web app root system property already set to different value: 
   'webapp.root' = 
      [C:\root\dev\workSpace-Europa\transite\.metadata\.plugins\org.eclipse.wst.server.core\tmp0\wtpwebapps\TranSiteTPW\] 
   instead of 
      [C:\root\dev\workSpace-Europa\transite\.metadata\.plugins\org.eclipse.wst.server.core\tmp0\wtpwebapps\OpenAccountTPW\] 
 - Choose unique values for the 'webAppRootKey' context-param in your web.xml files!


Solution:

<context-param>
  <param-name>webAppRootKey</param-name>
  <param-value>travel.root</param-value>
</context-param>


Hi all,

when deploying two applications build from the riot skeleton within  
the same Tomcat servlet container, you get an

IllegalStateException: Web app root system property already set to  
different value: 'webapp.root' = [/Users/joe/
Workspace/.metadata/.plugins/org.eclipse.wst.server.core/tmp0/webapps/
webapp-A/] instead of [/Users/joe/Workspace/.metadata/.plugins/
org.eclipse.wst.server.core/tmp0/webapps/webapp-B/] - Choose unique  
values for the 'webAppRootKey' context-param in your web.xml files!

I will try to explain where this comes from and how to circumvent it,  
but first the quick fix for the impatient reader: Place a context  
parameter named 'webAppRootKey' in every project's web.xml and assign  
a value to it, that is unique for every of your projects like the  
project name itself.

The webAppRootKey context parameter is introduced by Spring. Along  
with the WebAppRootListener it allows exposing the web applications  
root directory as a system property. The value of the context  
parameter 'webAppRootKey' names the system property to use. If the  
context parameter 'webAppRootKey' is not set in the application's  
web.xml, Spring chooses the default value 'app.root'. While some  
servlet containers like Resin do isolate each web application's  
system properties, others like Tomcat do not. And that's what the  
former mentioned IllegalStateException is telling us:  The system  
property 'app.root' already contains the root directory of the first  
web application when Spring tries to assign the root directoty of the  
second application to it.

Ok, that's the background information. A deeper look into the web.xml  
tells us, that there ist no WebAppRootListener configured. Why does  
this initialisation take place anyway? The stack trace from the  
exception reveals the culprit: The Log4jConfigListener also tries to  
set the webAppRootKey, because this is an interesting mechanism for  
the Spring/Log4j integration. It allows log and config file locations  
relative to the web applications root directory. The  
Log4jConfigListener supports three init parameters at the servlet  
context level: 'log4jConifgLocation', 'log4jRefreshInterval' and  
'log4jExposeWebAppRoot'. See JavaDocs for more informations.

But, none of these parameters are set in the riot project skeleton's  
web.xml and none of the Log4jWebConfigureres features are used by the  
riot project skeleton. As long as you do stay with default log4j  
setup, the Log4jConfigListener is superflous.

At the end there are three possible solutions for the initial problem:

(1) Provide any of your applications with a unique 'webAppRootKey'.
(2) Set the servlet context parameter 'log4jExposeWebAppRoot' to  
'false'. This eliminates the use of log file locations relative to  
the web application's root directory but still allows a log4j config  
location outside the classpath.
(3) Remove the 'Log4jConfigListener' from your application's web.xml.

What do you think is the best solution and should be incorporated  
into the riot skeleton project?

-alf

Alf Werder

Technische Leitung
Head of Engineering

http://www.glonz.co