--
-- -------------------------------------------------------------------------------------------------------
-- BACKOUT : Add entries into ABILITY_SET_WORK_GROUP table (Marry ability set TO each **NON-TERMINAL**Work Group)
-- -------------------------------------------------------------------------------------------------------
--
-- REMOVE Dispute Associate
DELETE FROM amg.ability_set_work_group
WHERE ABILITY_SET_ID = 1120;
--
-- -------------------------------------------------------------------------------------------------------
-- BACKOUT : Add entries into OPERATOR_GROUP_SYSTEM_ENV table  (MARRY operator group to Active Directory)
-- -------------------------------------------------------------------------------------------------------
DELETE FROM amg.operator_group_system_env WHERE operator_group_id = 1120;
--
-- ===============================================================
-- BACKOUT : Create Role : DisputeTran 
-- Assign to    :  Dispute Associate 1120
-- ===============================================================
-- 
DELETE FROM amg.ability_set_appl_role WHERE ability_set_id = 1120;
DELETE FROM APPL_ROLE  WHERE APPL_ROLE = 'DisputeTran';
--
-- =====================================
-- BACKOUT : Add entires into OPERATOR_GROUP_ABILITY_SET table (MARRY ABILITY_SET to OPERATOR_GROUP)
-- =====================================
DELETE FROM amg.operator_group_ability_set where operator_group_id = 1120;
--
-- =====================================
-- BACKOUT : Add entries into ABILITY_SET table
-- =====================================
DELETE FROM amg.ability_set where ability_set_id = 1120;
-- =====================================
-- BACKOUT : Add entries into OPERATOR_GROUP table
-- =====================================
DELETE FROM amg.operator_group where operator_group_id = 1120;
--
-- -------------------------------------------------------------------------------------------------------
-- BACKOUT : INSERT INTO WORK_TYPE_GROUP table : Marry Work_Type to Work_Group
-- -------------------------------------------------------------------------------------------------------
--
DELETE FROM WORK_TYPE_GROUP WHERE WORK_GROUP_CODE in (7080, 7081, 7082, 7083, 7084);
--
-- -------------------------------------------------------------------------------------------------------
-- BACKOUT : INSERT INTO WORK_TYPE_DESC table  (Status will represent work_type_id)
-- -------------------------------------------------------------------------------------------------------
--
DELETE FROM WORK_TYPE_DESC WHERE WORK_TYPE_ID = 270;
DELETE FROM WORK_TYPE WHERE WORK_TYPE_ID = 270;
--
-- -------------------------------------------------------------------------------------------------------
-- BACKOUT : INSERT INTO WORK_GROUP table (These are the Queues)
-- -------------------------------------------------------------------------------------------------------
--
DELETE FROM WORK_GROUP WHERE WORK_GROUP_CODE IN (7080, 7081, 7082, 7083, 7084);
--
-- -------------------------------------------------------------------------------------------------------
-- Commit
-- -------------------------------------------------------------------------------------------------------
commit;

