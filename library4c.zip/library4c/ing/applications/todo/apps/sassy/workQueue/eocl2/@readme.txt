--
-- doc : G:\Notes\enterprise\apps\sassy\workQueue\eocl2\@readme.txt
--
--
Work Queues are used to communicate work to be done manually.


All tables are in AMG, unless specified otherwise.

===================== WORK ==========================
WORK_GROUP (WG) THE QUEUES

   #WORK_GROUP_CODE #DESCRIPTION
 
   ***** NON-TERMINAL Q *******
   #7080  #Card Disputes: Pending
   #7081  #Card Disputes: Filed

   ***** TERMINAL Q     *******
   #7082  #Card Disputes:Comp-in customer favor
   #7083  #Card Disputes:Comp-not customer favor
   #7084  #Card Disputes:Cancelled

WORK_TYPE (WT)
   #WORK_TYPE_ID

   #270

WORK_TYPE_DESC (WT_DESC)
  #WORK_TYPE_ID #DESCRIPTION #REF_1_DESC #REF_2_DESC #REF_3_DESC  

  #270 #Card Dispute Item  #Account Number|Sequence Number #Reason Code|IsPinBased|AccountType #Merchant|sendMediaId


WORK_TYPE_GROUP (WT_GROUP) (====MARRIAGE=====)
  #WORK_TYPE_ID #WORK_GROUP

  #270#7080
  #270#7081
  #270#7082
  #270#7083
  #270#7084

===================== "WHAT GROUP" CAN DO THE "WORK" =========================

The "Dispute Associate" Group with the role "DisputeTran"

-------------------------------------------
An Operator GROUP IS GIVEN A SET OF ABLIITIES 

The set of abilities is assigned roles.

So, a role is tied to an ability set which is tied to an operator group which is tied to an LDAP entry.

LDAP
  OPERATOR GROUP
     ABILITY SET
        ROLE
-------------------------------------------

OPERATOR_GROUP (OG)
  #operator_group_id #description

  #1120 #Dispute Associate

ABILITY_SET (AS)
  #ability_set_id #description

  #1120 #Dispute Associate

OPERATOR_GROUP_ABILITY_SET (OG_AS) (====MARRIAGE=====)
  #operator_group_id #ability_set_id

  #1120 #1120

APPL_ROLE (AR)
  #APPL_ROLE

  #DisputeTran

ability_set_appl_role (AS_AR) (====MARRIAGE=====)
  #ability_set_id #appl_role

  #1120 #DisputeTran

*************************************************************************************************
*************************************************************************************************
*************************************************************************************************
*************************************************************************************************


-------------------------------------------------------------------------------
Assign the Operator Group to an LDAP entry, so it appears in Active Directory
Note, you must create an Active Directory Group, if one does not exist.
--------------------------------------------------------------------------------

===================== MARRY THE OPERATOR GROUP WITH LDAP  =========================

OPERATOR_GROUP_SYSTEM_ENV
  #operator_group_id #env_code #user_group_ldap

  #1120 #'T' #'cn=sassy card dispute queues,ou=security groups,ou=ing direct,dc=ingqa,dc=com'
  #1120 #'P' #'cn=sassy card dispute queues,ou=security groups,ou=ing direct,dc=ingdirect,dc=com'
  #1120 #'R' #'cn=sassy card dispute queues,ou=security groups,ou=ing direct,dc=ingdirect,dc=com'
  #1120 #'D' #'cn=sassy card dispute queues,ou=security groups,ou=ing direct,dc=ingdedev,dc=com'
  #1120 #'E' #'cn=sassy card dispute queues,ou=security groups,ou=ing direct,dc=ingdedev,dc=com'


   THIS IS THE ACTIVE DIRECTORY GROUP : sassy card dispute queues
     THAT YOU WILL FIND UNDER         : ING DIRECT

===================== MAKE THE WORK QUEUES NON-TERMINAL  =========================
ABILITY_SET_WORK_GROUP
  #ABILITY_SET_ID #WORK_GROUP_ID

  #1120 #7080
  #1120 #7081
