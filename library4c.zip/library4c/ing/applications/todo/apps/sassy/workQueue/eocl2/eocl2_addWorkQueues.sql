-- -------------------------------------------------------------------------------------------------------
-- INSERT INTO WORK_GROUP table (These are the Queues)
-- -------------------------------------------------------------------------------------------------------
-
-  NON-TERMINATING QUEUES
-
INSERT INTO WORK_GROUP ( WORK_GROUP_CODE, RANDOM_ACCESS_IND, CREATED_DATE,
MODIFIED_DATE, CREATED_BY, MODIFIED_BY, DESCRIPTION, TIMEOUT_MIN,
TIMEOUT_WORK_GROUP_CODE, MAX_OWNED_MIN )
VALUES ( 7080, 'Y',  sysdate,  sysdate, 'abrida', 'abrida',
'Card Disputes: Pending', NULL, NULL, 0); 
--
INSERT INTO WORK_GROUP ( WORK_GROUP_CODE, RANDOM_ACCESS_IND, CREATED_DATE,
MODIFIED_DATE, CREATED_BY, MODIFIED_BY, DESCRIPTION, TIMEOUT_MIN,
TIMEOUT_WORK_GROUP_CODE, MAX_OWNED_MIN )
VALUES ( 7081, 'Y',  sysdate,  sysdate, 'abrida', 'abrida',
'Card Disputes: Filed', NULL, NULL, 0); 
-
- TERMINATING QUEUES
-
INSERT INTO WORK_GROUP ( WORK_GROUP_CODE, RANDOM_ACCESS_IND, CREATED_DATE,
MODIFIED_DATE, CREATED_BY, MODIFIED_BY, DESCRIPTION, TIMEOUT_MIN,
TIMEOUT_WORK_GROUP_CODE, MAX_OWNED_MIN )
VALUES ( 7082, 'Y',  sysdate,  sysdate, 'abrida', 'abrida',
'Card Disputes:Comp-in customer favor', NULL, NULL, 0); 
--
INSERT INTO WORK_GROUP ( WORK_GROUP_CODE, RANDOM_ACCESS_IND, CREATED_DATE,
MODIFIED_DATE, CREATED_BY, MODIFIED_BY, DESCRIPTION, TIMEOUT_MIN,
TIMEOUT_WORK_GROUP_CODE, MAX_OWNED_MIN )
VALUES ( 7083, 'Y',  sysdate,  sysdate, 'abrida', 'abrida',
'Card Disputes:Comp-not customer favor', NULL, NULL, 0); 
--
INSERT INTO WORK_GROUP ( WORK_GROUP_CODE, RANDOM_ACCESS_IND, CREATED_DATE,
MODIFIED_DATE, CREATED_BY, MODIFIED_BY, DESCRIPTION, TIMEOUT_MIN,
TIMEOUT_WORK_GROUP_CODE, MAX_OWNED_MIN )
VALUES ( 7084, 'Y',  sysdate,  sysdate, 'abrida', 'abrida',
'Card Disputes:Cancelled', NULL, NULL, 0); 
--
-- -------------------------------------------------------------------------------------------------------
-- INSERT INTO WORK_TYPE table  (kinds of work (see def following))
--    (anyone in CustService role can create it)
-- -------------------------------------------------------------------------------------------------------
INSERT INTO WORK_TYPE ( WORK_TYPE_ID, WORK_ITEM_TYPE_CODE, COMBO_WORK_CODE,
CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, HAS_NOTE_IND, CAN_SCHEDULE_IND,
CREATION_ROLE )
VALUES ( 270, 'D', 'd-na-270', sysdate, sysdate, 'abrida', 'abrida','Y', 'N', 'CustService');
--
-- -------------------------------------------------------------------------------------------------------
-- INSERT INTO WORK_TYPE_DESC table  (Status will represent work_type_id)
-- -------------------------------------------------------------------------------------------------------
INSERT INTO WORK_TYPE_DESC ( WORK_TYPE_ID, LOCALE_CODE, DESCRIPTION,
CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, REF_1_DESC, REF_2_DESC, REF_3_DESC  )
VALUES ( 270, 'en-US',  'Card Dispute Item', sysdate,  sysdate, 'abrida', 'abrida',
'Account Number|Sequence Number', 'Reason Code|IsPinBased|AccountType','Merchant|sendMediaId' );
--
-- -------------------------------------------------------------------------------------------------------
-- INSERT INTO WORK_TYPE_GROUP table : Marry Work_Type to Work_Group
-- -------------------------------------------------------------------------------------------------------
-- =====================================
-- Work Queue 7080 - Pending Disputes
-- =====================================
INSERT INTO WORK_TYPE_GROUP ( WORK_TYPE_ID, WORK_GROUP_CODE, ALWAYS_IND,
CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY )
VALUES ( 270, 7080, 'Y' , sysdate,  sysdate, 'abrida', 'abrida' );
--
-- =====================================
---- Work Queue 7081 - Filed Disputes
-- =====================================
INSERT INTO WORK_TYPE_GROUP ( WORK_TYPE_ID, WORK_GROUP_CODE, ALWAYS_IND,
CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY )
VALUES ( 270, 7081, 'Y' , sysdate,  sysdate, 'abrida', 'abrida' );
--
-- =====================================
---- Work Queue 7082 - Card Disputes:Comp-in customer favor
-- =====================================
INSERT INTO WORK_TYPE_GROUP ( WORK_TYPE_ID, WORK_GROUP_CODE, ALWAYS_IND,
CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY )
VALUES ( 270, 7082, 'Y' , sysdate,  sysdate, 'abrida', 'abrida' );
--
-- =====================================
---- Work Queue 7083 - Card Disputes:Comp-not customer favor
-- =====================================
INSERT INTO WORK_TYPE_GROUP ( WORK_TYPE_ID, WORK_GROUP_CODE, ALWAYS_IND,
CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY )
VALUES ( 270, 7083, 'Y' , sysdate,  sysdate, 'abrida', 'abrida' );
--
-- =====================================
---- Work Queue 7084 - Card Disputes:Cancelled
-- =====================================
INSERT INTO WORK_TYPE_GROUP ( WORK_TYPE_ID, WORK_GROUP_CODE, ALWAYS_IND,
CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY )
VALUES ( 270, 7084, 'Y' , sysdate,  sysdate, 'abrida', 'abrida' );

--
-- -------------------------------------------------------------------------------------------------------
-- Create new user groups for Electric Orange Custom work screens/queues.
-- -------------------------------------------------------------------------------------------------------
-- =====================================
-- Add entries into OPERATOR_GROUP table
-- =====================================
INSERT INTO amg.operator_group (operator_group_id, description, created_by, created_date, modified_by, modified_date)
VALUES (1120, 'Dispute Associate', 'abrida',  sysdate, 'abrida',  sysdate);
--
-- =====================================
-- Add entries into ABILITY_SET table
-- =====================================
INSERT INTO amg.ability_set (ability_set_id, description, created_by, created_date, modified_by, modified_date)
VALUES (1120, 'Dispute Associate','abrida',  sysdate, 'abrida',  sysdate );
--
-- =====================================
-- Add entires into OPERATOR_GROUP_ABILITY_SET table (MARRY ABILITY_SET to OPERATOR_GROUP)
-- =====================================
INSERT INTO amg.operator_group_ability_set (operator_group_id, ability_set_id, created_by, created_date, modified_by, modified_date)
VALUES (1120, 1120, 'abrida',  sysdate, 'abrida',  sysdate);
--
-- ===============================================================
-- Create Role : DisputeTran 
-- Assign to    :  Dispute Associate 1120
-- ===============================================================
-- 
-- ==== Create Role ====
INSERT INTO APPL_ROLE ( APPL_ROLE, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, DESCRIPTION)
 VALUES ('DisputeTran',sysdate,sysdate,'abrida', 'abrida','Able to work Pending and Filed disputes.');
--
-- ==== Add Role to Dispute Associate  ====
INSERT INTO amg.ability_set_appl_role (ability_set_id, appl_role, created_by, created_date, modified_by, modified_date)
VALUES (1120, 'DisputeTran', 'abrida',  sysdate, 'abrida',  sysdate);
--
-- -------------------------------------------------------------------------------------------------------
-- Add entries into OPERATOR_GROUP_SYSTEM_ENV table  (MARRY operator group to Active Directory)
-- -------------------------------------------------------------------------------------------------------
INSERT INTO amg.operator_group_system_env (operator_group_id, env_code, user_group_ldap, created_by, created_date, modified_by, modified_date)
VALUES (1120, 'T', 'cn=sassy card dispute queues,ou=security groups,ou=ing direct,dc=ingqa,dc=com', 'abrida',  sysdate, 'abrida',  sysdate);
--
INSERT INTO amg.operator_group_system_env (operator_group_id, env_code, user_group_ldap, created_by, created_date, modified_by, modified_date)
VALUES (1120, 'P', 'cn=sassy card dispute queues,ou=security groups,ou=ing direct,dc=ingdirect,dc=com', 'abrida',  sysdate, 'abrida',  sysdate);
--
INSERT INTO amg.operator_group_system_env (operator_group_id, env_code, user_group_ldap, created_by, created_date, modified_by, modified_date)
VALUES (1120, 'V', 'cn=sassy card dispute queues,ou=security groups,ou=ing direct,dc=ingqa,dc=com', 'abrida',  sysdate, 'abrida',  sysdate);
--
INSERT INTO amg.operator_group_system_env (operator_group_id, env_code, user_group_ldap, created_by, created_date, modified_by, modified_date)
VALUES (1120, 'R', 'cn=sassy card dispute queues,ou=security groups,ou=ing direct,dc=ingdirect,dc=com', 'abrida',  sysdate, 'abrida',  sysdate);
--
INSERT INTO amg.operator_group_system_env (operator_group_id, env_code, user_group_ldap, created_by, created_date, modified_by, modified_date)
VALUES (1120, 'S', 'cn=sassy card dispute queues,ou=security groups,ou=ing direct,dc=ingqa,dc=com', 'abrida',  sysdate, 'abrida',  sysdate);
--
INSERT INTO amg.operator_group_system_env (operator_group_id, env_code, user_group_ldap, created_by, created_date, modified_by, modified_date)
VALUES (1120, 'D', 'cn=sassy card dispute queues,ou=security groups,ou=ing direct,dc=ingdedev,dc=com', 'abrida',  sysdate, 'abrida',  sysdate);
--
INSERT INTO amg.operator_group_system_env (operator_group_id, env_code, user_group_ldap, created_by, created_date, modified_by, modified_date)
VALUES (1120, 'E', 'cn=sassy card dispute queues,ou=security groups,ou=ing direct,dc=ingdedev,dc=com', 'abrida',  sysdate, 'abrida',  sysdate);
--
-- -------------------------------------------------------------------------------------------------------
-- Add entries into ABILITY_SET_WORK_GROUP table (Marry ability set TO each **NON-TERMINAL**Work Group)
-- -------------------------------------------------------------------------------------------------------
--
-- Dispute Associate
INSERT INTO amg.ability_set_work_group (ABILITY_SET_ID, WORK_GROUP_ID, MANAGER_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY)
VALUES (1120, 7080, 'N', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO amg.ability_set_work_group (ABILITY_SET_ID, WORK_GROUP_ID, MANAGER_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY)
VALUES (1120, 7081, 'N', sysdate, sysdate, 'abrida', 'abrida');
-- -------------------------------------------------------------------------------------------------------
-- Commit
-- -------------------------------------------------------------------------------------------------------
commit;