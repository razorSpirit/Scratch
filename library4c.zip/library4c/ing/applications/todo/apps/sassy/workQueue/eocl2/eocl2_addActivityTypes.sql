--
-- -------------------------------------------------------------------------------------------------------
-- Add Activity : Dispute created
-- -------------------------------------------------------------------------------------------------------
--
Insert into amg.ACTIVITY_TYPE
   (ACTIVITY_TYPE_CODE, OPERATOR_SUPPLIED_IND, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
 Values
   (4630, 'N', 'abrida', sysdate, 'abrida', sysdate);
--
INSERT INTO ACTIVITY_TYPE_DESC 
   (ACTIVITY_TYPE_CODE, LOCALE_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY,  SHORT_DESC, DESCRIPTION, SUBST_DESC, REF_1_DESC,REF_2_DESC)
 Values
  ( 4630, 'en-US',  sysdate,  sysdate, 'abrida', 'abrida','Dispute pending', 'Dispute pending', 'Dispute pending', 'Work item', 'History sequence'); 
--
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('all', 4630, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('hist', 4630, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('summ', 4630, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('wrapup', 4630, 'abrida', sysdate, 'abrida', sysdate);
--
-- -------------------------------------------------------------------------------------------------------
-- Add Activity : Dispute filed
-- -------------------------------------------------------------------------------------------------------
--
Insert into amg.ACTIVITY_TYPE
   (ACTIVITY_TYPE_CODE, OPERATOR_SUPPLIED_IND, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
 Values
   (4631, 'N', 'abrida', sysdate, 'abrida', sysdate);
--
INSERT INTO ACTIVITY_TYPE_DESC 
   (ACTIVITY_TYPE_CODE, LOCALE_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY,  SHORT_DESC, DESCRIPTION, SUBST_DESC, REF_1_DESC, REF_2_DESC)
 Values
  ( 4631, 'en-US',  sysdate,  sysdate, 'abrida', 'abrida','Dispute filed', 'Dispute filed', 'Dispute filed', 'Work item', 'History sequence'); 
--
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('all', 4631, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('hist', 4631, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('summ', 4631, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('wrapup', 4631, 'abrida', sysdate, 'abrida', sysdate);
--
-- -------------------------------------------------------------------------------------------------------
-- Add Activity : Dispute completed - in customer favor
-- -------------------------------------------------------------------------------------------------------
--
Insert into amg.ACTIVITY_TYPE
   (ACTIVITY_TYPE_CODE, OPERATOR_SUPPLIED_IND, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
 Values
   (4632, 'N', 'abrida', sysdate, 'abrida', sysdate);
--
INSERT INTO ACTIVITY_TYPE_DESC 
   (ACTIVITY_TYPE_CODE, LOCALE_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY,  SHORT_DESC, DESCRIPTION, SUBST_DESC, REF_1_DESC, REF_2_DESC)
 Values
  ( 4632, 'en-US',  sysdate,  sysdate, 'abrida', 'abrida','Dispute completed in favor', 'Dispute completed - in customer favor', 'Dispute completed in favor', 'Work item', 'History sequence'); 
--
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('all', 4632, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('hist', 4632, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('summ', 4632, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('wrapup', 4632, 'abrida', sysdate, 'abrida', sysdate);  
--
-- -------------------------------------------------------------------------------------------------------
-- Add Activity : Dispute completed - not in customer favor
-- -------------------------------------------------------------------------------------------------------
--
Insert into amg.ACTIVITY_TYPE
   (ACTIVITY_TYPE_CODE, OPERATOR_SUPPLIED_IND, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
 Values
   (4633, 'N', 'abrida', sysdate, 'abrida', sysdate);
--
INSERT INTO ACTIVITY_TYPE_DESC 
   (ACTIVITY_TYPE_CODE, LOCALE_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY,  SHORT_DESC, DESCRIPTION, SUBST_DESC, REF_1_DESC, REF_2_DESC)
 Values
  ( 4633, 'en-US',  sysdate,  sysdate, 'abrida', 'abrida','Dispute completed not in favor', 'Dispute completed - not in customer favor', 'Dispute completed not in favor', 'Work item', 'History sequence'); 
--
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('all', 4633, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('hist', 4633, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('summ', 4633, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('wrapup', 4633, 'abrida', sysdate, 'abrida', sysdate); 
--
-- -------------------------------------------------------------------------------------------------------
-- Add Activity : Dispute cancelled
-- -------------------------------------------------------------------------------------------------------
--
Insert into amg.ACTIVITY_TYPE
   (ACTIVITY_TYPE_CODE, OPERATOR_SUPPLIED_IND, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
 Values
   (4634, 'N', 'abrida', sysdate, 'abrida', sysdate);
--
INSERT INTO ACTIVITY_TYPE_DESC 
   (ACTIVITY_TYPE_CODE, LOCALE_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY,  SHORT_DESC, DESCRIPTION, SUBST_DESC, REF_1_DESC, REF_2_DESC)
 Values
  ( 4634, 'en-US',  sysdate,  sysdate, 'abrida', 'abrida','Dispute cancelled', 'Dispute cancelled', 'Dispute cancelled', 'Work item', 'History sequence'); 
--
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('all', 4634, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('hist', 4634, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('summ', 4634, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('wrapup', 4634, 'abrida', sysdate, 'abrida', sysdate);
--
-- -------------------------------------------------------------------------------------------------------
-- Add Activity : Card limit increased
-- -------------------------------------------------------------------------------------------------------
--
Insert into amg.ACTIVITY_TYPE
   (ACTIVITY_TYPE_CODE, OPERATOR_SUPPLIED_IND, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
 Values
   (4635, 'N', 'abrida', sysdate, 'abrida', sysdate);
--
INSERT INTO ACTIVITY_TYPE_DESC 
   (ACTIVITY_TYPE_CODE, LOCALE_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY,  SHORT_DESC, DESCRIPTION, SUBST_DESC, REF_1_DESC, REF_2_DESC)
 Values
  ( 4635, 'en-US',  sysdate,  sysdate, 'abrida', 'abrida','Card Limit Increase', 'Card Limit Increase', 'Card Limit Increase', 'Account','Amount'); 
--
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('all', 4635, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('hist', 4635, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('summ', 4635, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('wrapup', 4635, 'abrida', sysdate, 'abrida', sysdate);    
--
-- -------------------------------------------------------------------------------------------------------
-- Add Activity : Card limit decreased
-- -------------------------------------------------------------------------------------------------------
--
Insert into amg.ACTIVITY_TYPE
   (ACTIVITY_TYPE_CODE, OPERATOR_SUPPLIED_IND, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
 Values
   (4636, 'N', 'abrida', sysdate, 'abrida', sysdate);
--
INSERT INTO ACTIVITY_TYPE_DESC 
   (ACTIVITY_TYPE_CODE, LOCALE_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY,  SHORT_DESC, DESCRIPTION, SUBST_DESC, REF_1_DESC, REF_2_DESC)
 Values
  ( 4636, 'en-US',  sysdate,  sysdate, 'abrida', 'abrida','Card Limit Decrease', 'Card Limit Decrease', 'Card Limit Decrease', 'Account','Amount'); 
--
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('all', 4636, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('hist', 4636, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('summ', 4636, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('wrapup', 4636, 'abrida', sysdate, 'abrida', sysdate);
--
-- -------------------------------------------------------------------------------------------------------
-- Add Activity : Dispute Note Added
-- -------------------------------------------------------------------------------------------------------
--
Insert into amg.ACTIVITY_TYPE
   (ACTIVITY_TYPE_CODE, OPERATOR_SUPPLIED_IND, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
 Values
   (4637, 'N', 'abrida', sysdate, 'abrida', sysdate);
--
INSERT INTO ACTIVITY_TYPE_DESC 
   (ACTIVITY_TYPE_CODE, LOCALE_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY,  SHORT_DESC, DESCRIPTION, SUBST_DESC, REF_1_DESC, REF_2_DESC)
 Values
  ( 4637, 'en-US',  sysdate,  sysdate, 'abrida', 'abrida','Dispute Note Added', 'Dispute Note Added', 'Dispute Note Added', 'Work item', 'History sequence'); 
--
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('all', 4637, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('hist', 4637, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('summ', 4637, 'abrida', sysdate, 'abrida', sysdate);
Insert into amg.activity_filter_type (ACTIVITY_FILTER_CODE, ACTIVITY_TYPE_CODE, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
   Values ('wrapup', 4637, 'abrida', sysdate, 'abrida', sysdate);
--
-- -------------------------------------------------------------------------------------------------------
-- Commit
-- -------------------------------------------------------------------------------------------------------
COMMIT;
