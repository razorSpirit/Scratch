--
-- -------------------------------------------------------------------------------------------------------
-- BACKOUT:Add Activity : Dispute created
-- -------------------------------------------------------------------------------------------------------
--
DELETE FROM amg.activity_filter_type WHERE ACTIVITY_FILTER_CODE = 4630;
DELETE FROM ACTIVITY_TYPE_DESC WHERE ACTIVITY_TYPE_CODE = 4630; 
DELETE FROM amg.ACTIVITY_TYPE WHERE ACTIVITY_TYPE_CODE = 4630; 
--
-- -------------------------------------------------------------------------------------------------------
-- BACKOUT:Add Activity : Dispute filed
-- -------------------------------------------------------------------------------------------------------
--
DELETE FROM amg.activity_filter_type WHERE ACTIVITY_FILTER_CODE = 4631;
DELETE FROM ACTIVITY_TYPE_DESC WHERE ACTIVITY_TYPE_CODE = 4631; 
DELETE FROM amg.ACTIVITY_TYPE WHERE ACTIVITY_TYPE_CODE = 4631; 
--
-- -------------------------------------------------------------------------------------------------------
-- BACKOUT:Add Activity : Dispute completed - in customer favor
-- -------------------------------------------------------------------------------------------------------
--
DELETE FROM amg.activity_filter_type WHERE ACTIVITY_FILTER_CODE = 4632;
DELETE FROM ACTIVITY_TYPE_DESC WHERE ACTIVITY_TYPE_CODE = 4632; 
DELETE FROM amg.ACTIVITY_TYPE WHERE ACTIVITY_TYPE_CODE = 4632; 
--
-- -------------------------------------------------------------------------------------------------------
-- BACKOUT:Add Activity : Dispute completed - not in customer favor
-- -------------------------------------------------------------------------------------------------------
--
DELETE FROM amg.activity_filter_type WHERE ACTIVITY_FILTER_CODE = 4633;
DELETE FROM ACTIVITY_TYPE_DESC WHERE ACTIVITY_TYPE_CODE = 4633; 
DELETE FROM amg.ACTIVITY_TYPE WHERE ACTIVITY_TYPE_CODE = 4633; 
--
-- -------------------------------------------------------------------------------------------------------
-- BACKOUT:Add Activity : Dispute cancelled
-- -------------------------------------------------------------------------------------------------------
--
DELETE FROM amg.activity_filter_type WHERE ACTIVITY_FILTER_CODE = 4634;
DELETE FROM ACTIVITY_TYPE_DESC WHERE ACTIVITY_TYPE_CODE = 4634; 
DELETE FROM amg.ACTIVITY_TYPE WHERE ACTIVITY_TYPE_CODE = 4634; 

--
-- -------------------------------------------------------------------------------------------------------
-- BACKOUT:Add Activity : Card limit increased
-- -------------------------------------------------------------------------------------------------------
--
DELETE FROM amg.activity_filter_type WHERE ACTIVITY_FILTER_CODE = 4635;
DELETE FROM ACTIVITY_TYPE_DESC WHERE ACTIVITY_TYPE_CODE = 4635; 
DELETE FROM amg.ACTIVITY_TYPE WHERE ACTIVITY_TYPE_CODE = 4635; 

--
-- -------------------------------------------------------------------------------------------------------
-- BACKOUT: Add Activity : Card limit decreased
-- -------------------------------------------------------------------------------------------------------
--

DELETE FROM amg.activity_filter_type WHERE ACTIVITY_FILTER_CODE = 4636;
DELETE FROM ACTIVITY_TYPE_DESC WHERE ACTIVITY_TYPE_CODE = 4636; 
DELETE FROM amg.ACTIVITY_TYPE WHERE ACTIVITY_TYPE_CODE = 4636; 
--
-- -------------------------------------------------------------------------------------------------------
-- BACKOUT: Add Activity : Dispute Note Added
-- -------------------------------------------------------------------------------------------------------
   
Delete from amg.activity_filter_type   where ACTIVITY_TYPE_CODE = 4637;
DELETE FROM ACTIVITY_TYPE_DESC WHERE ACTIVITY_TYPE_CODE = 4637;
DELETE FROM amg.ACTIVITY_TYPE WHERE ACTIVITY_TYPE_CODE = 4637;
--
-- -------------------------------------------------------------------------------------------------------
-- Commit
-- -------------------------------------------------------------------------------------------------------
COMMIT;
