--
-- =========================================<< 10DayTCReminder >>=========================================================
--
-- xxxxxxxx<<BACKOUT STEP008>>xxxxxxx ======= Update Notification ID with new Template
--
UPDATE csp.csp_ext_corres_type
     SET TEMPLATE_ID = 506,
             MODIFIED_DATE = sysdate,
             MODIFIED_BY = 'abrida'
     WHERE
            EXT_SYSTEM_CODE = 1
        AND
           EXT_CORRES_TYPE_CODE = 6;
--
-- xxxxxxxx<<BACKOUT STEP007>>xxxxxxx ======= Create Parts Definitions for the Multipart 
--
DELETE FROM CSP.EMAIL_MULTIPART_PART WHERE EMAIL_MULTIPART_CODE  = 1566;
--
-- xxxxxxxx<<BACKOUT STEP006>>xxxxxxx ======= Add the EMPTY PARTS(plain, html) to be uploaded later
--
DELETE FROM csp.email_bodypart WHERE email_bodypart_code IN ( 1566, 1567);
--
-- xxxxxxxx<<BACKOUT STEP005>>xxxxxxx ======= Create email definition with Multipart definition
--
DELETE FROM EMAIL_DEF WHERE EMAIL_DEF_CODE = 1565 AND EMAIL_MULTIPART_CODE = 1566;
--
-- xxxxxxxx<<BACKOUT STEP004>>xxxxxxx ======= Create Multipart Definition
--
DELETE FROM EMAIL_MULTIPART WHERE EMAIL_MULTIPART_CODE = 1566;
 --
-- xxxxxxxx<<BACKOUT STEP003>>xxxxxxx ======= Marry template to email definition
--
DELETE FROM CSP.CORRES_GEN_TEMPLATE WHERE TEMPLATE_ID = 1506;
--
-- xxxxxxxx<<BACKOUT STEP002>>xxxxxxx ======= Add template PARAMS
--
DELETE FROM CSP.TEMPLATE_PARAM WHERE TEMPLATE_ID = 1506;
          
--
-- xxxxxxxx<<BACKOUT STEP001>>xxxxxxx ======= Create a NEW template and a template description 
--
DELETE FROM CSP.TEMPLATE_DESC WHERE TEMPLATE_ID = 1506;
DELETE FROM CSP.TEMPLATE WHERE TEMPLATE_ID = 1506;                 
--
-- =========================================<< 20DayTCReminder >>=========================================================
--
-- xxxxxxxx<<BACKOUT STEP008>>xxxxxxx ======= Update Notification ID with new Template
--
UPDATE csp.csp_ext_corres_type
     SET TEMPLATE_ID = 507,
             MODIFIED_DATE = sysdate,
             MODIFIED_BY = 'abrida'
     WHERE
            EXT_SYSTEM_CODE = 1
        AND
           EXT_CORRES_TYPE_CODE = 7;
--
-- xxxxxxxx<<BACKOUT STEP007>>xxxxxxx ======= Create Parts Definitions for the Multipart 
--
DELETE FROM CSP.EMAIL_MULTIPART_PART WHERE EMAIL_MULTIPART_CODE  = 1571;
--
-- xxxxxxxx<<BACKOUT STEP006>>xxxxxxx ======= Add the EMPTY PARTS(plain, html) to be uploaded later
--
DELETE FROM csp.email_bodypart WHERE email_bodypart_code IN ( 1571, 1572);
--
-- xxxxxxxx<<BACKOUT STEP005>>xxxxxxx ======= Create email definition with Multipart definition
--
DELETE FROM EMAIL_DEF WHERE EMAIL_DEF_CODE = 1570 AND EMAIL_MULTIPART_CODE = 1571;
--
-- xxxxxxxx<<BACKOUT STEP004>>xxxxxxx ======= Create Multipart Definition
--
DELETE FROM EMAIL_MULTIPART WHERE EMAIL_MULTIPART_CODE = 1571;
 --
-- xxxxxxxx<<BACKOUT STEP003>>xxxxxxx ======= Marry template to email definition
--
DELETE FROM CSP.CORRES_GEN_TEMPLATE WHERE TEMPLATE_ID = 1507;
--
-- xxxxxxxx<<BACKOUT STEP002>>xxxxxxx ======= Add template PARAMS
--
DELETE FROM CSP.TEMPLATE_PARAM WHERE TEMPLATE_ID = 1507;
          
--
-- xxxxxxxx<<BACKOUT STEP001>>xxxxxxx ======= Create a NEW template and a template description 
--
DELETE FROM CSP.TEMPLATE_DESC WHERE TEMPLATE_ID = 1507;
DELETE FROM CSP.TEMPLATE WHERE TEMPLATE_ID = 1507;                 
--
-- =========================================<< 30DayTCReminder >>=========================================================
--
-- xxxxxxxx<<BACKOUT STEP008>>xxxxxxx ======= Update Notification ID with new Template
--
UPDATE csp.csp_ext_corres_type
     SET TEMPLATE_ID = 508,
             MODIFIED_DATE = sysdate,
             MODIFIED_BY = 'abrida'
     WHERE
            EXT_SYSTEM_CODE = 1
        AND
           EXT_CORRES_TYPE_CODE = 8;
--
-- xxxxxxxx<<BACKOUT STEP007>>xxxxxxx ======= Create Parts Definitions for the Multipart 
--
DELETE FROM CSP.EMAIL_MULTIPART_PART WHERE EMAIL_MULTIPART_CODE  = 1576;
--
-- xxxxxxxx<<BACKOUT STEP006>>xxxxxxx ======= Add the EMPTY PARTS(plain, html) to be uploaded later
--
DELETE FROM csp.email_bodypart WHERE email_bodypart_code IN ( 1576, 1577);
--
-- xxxxxxxx<<BACKOUT STEP005>>xxxxxxx ======= Create email definition with Multipart definition
--
DELETE FROM EMAIL_DEF WHERE EMAIL_DEF_CODE = 1575 AND EMAIL_MULTIPART_CODE = 1576;
--
-- xxxxxxxx<<BACKOUT STEP004>>xxxxxxx ======= Create Multipart Definition
--
DELETE FROM EMAIL_MULTIPART WHERE EMAIL_MULTIPART_CODE = 1576;
 --
-- xxxxxxxx<<BACKOUT STEP003>>xxxxxxx ======= Marry template to email definition
--
DELETE FROM CSP.CORRES_GEN_TEMPLATE WHERE TEMPLATE_ID = 1508;
--
-- xxxxxxxx<<BACKOUT STEP002>>xxxxxxx ======= Add template PARAMS
--
DELETE FROM CSP.TEMPLATE_PARAM WHERE TEMPLATE_ID = 1508;
          
--
-- xxxxxxxx<<BACKOUT STEP001>>xxxxxxx ======= Create a NEW template and a template description 
--
DELETE FROM CSP.TEMPLATE_DESC WHERE TEMPLATE_ID = 1508;
DELETE FROM CSP.TEMPLATE WHERE TEMPLATE_ID = 1508;
-- == ============================================================================
-- == === File                            :  InitialCalltext.xsl
-- == ===  Name                         :  Init_CallCent
-- == ===  Email Subject            :  Power Up Your New Electric Orange
-- == ===  Notification ID (nid) :  31
-- == === Template ID (tid)       : 532 to 1532
-- == === Email ID (eid)            : 670 to 1670
-- == === MULTIPART              : 671 to 1671   PARTS 671 to 1671, 672 to 1672
-- == ============================================================================
--
-- =========================================<< InitialCall >>=========================================================
--
-- xxxxxxxx<<BACKOUT STEP008>>xxxxxxx ======= Update Notification ID with new Template
--
UPDATE csp.csp_ext_corres_type
     SET TEMPLATE_ID = 532,
             MODIFIED_DATE = sysdate,
             MODIFIED_BY = 'abrida'
     WHERE
            EXT_SYSTEM_CODE = 1
        AND
           EXT_CORRES_TYPE_CODE = 31;
--
-- xxxxxxxx<<BACKOUT STEP007>>xxxxxxx ======= Create Parts Definitions for the Multipart 
--
DELETE FROM CSP.EMAIL_MULTIPART_PART WHERE EMAIL_MULTIPART_CODE  = 1671 ;
--
-- xxxxxxxx<<BACKOUT STEP006>>xxxxxxx ======= Add the EMPTY PARTS(plain, html) to be uploaded later
--
DELETE FROM csp.email_bodypart WHERE email_bodypart_code IN (1671 , 1672);
--
-- xxxxxxxx<<BACKOUT STEP005>>xxxxxxx ======= Create email definition with Multipart definition
--
DELETE FROM EMAIL_DEF WHERE EMAIL_DEF_CODE = 1670 AND EMAIL_MULTIPART_CODE = 1671;
--
-- xxxxxxxx<<BACKOUT STEP004>>xxxxxxx ======= Create Multipart Definition
--
DELETE FROM EMAIL_MULTIPART WHERE EMAIL_MULTIPART_CODE = 1671;
 --
-- xxxxxxxx<<BACKOUT STEP003>>xxxxxxx ======= Marry template to email definition
--
DELETE FROM CSP.CORRES_GEN_TEMPLATE WHERE TEMPLATE_ID = 1532;
--
-- xxxxxxxx<<BACKOUT STEP002>>xxxxxxx ======= Add template PARAMS
--
DELETE FROM CSP.TEMPLATE_PARAM WHERE TEMPLATE_ID = 1532;
          
--
-- xxxxxxxx<<BACKOUT STEP001>>xxxxxxx ======= Create a NEW template and a template description 
--
DELETE FROM CSP.TEMPLATE_DESC WHERE TEMPLATE_ID = 1532;
DELETE FROM CSP.TEMPLATE WHERE TEMPLATE_ID = 1532;                 
--                
-- ================================================== COMMIT ========================================================
COMMIT;
-- ================================================== EOF =============================================================