-- Create template
-- Template ID is select max(template_id)+1 from CSP.TEMPLATE;
INSERT INTO CSP.TEMPLATE
VALUES (98030, sysdate, sysdate, 'pcimino', 'pcimino', null, null, 'E2', 0);

INSERT INTO CSP.TEMPLATE_DESC
VALUES (98030, 'en-US', 'Update Mailing Address prior to EO Card Reissue', 'Update Mailing Address prior to EO Card Reissue', 'pcimino', sysdate, 'pcimino', sysdate);

-- Map template to email definition
-- Corres_Generator_Code, E1 for OBM, E2 for EAlerts
-- EXTERNAL_REF is the Doc ID
INSERT INTO CSP.CORRES_GEN_TEMPLATE
VALUES ('E2', 98030, sysdate, sysdate, 'pcimino', 'pcimino', '0000000602');

--  Map parameters to template
INSERT INTO CSP.TEMPLATE_PARAM
VALUES (98030, 'cif', 0, 'Y', 'Y', sysdate, sysdate, 'pcimino', 'pcimino', 'N', 10);

INSERT INTO CSP.TEMPLATE_PARAM
VALUES (98030, 'fname', 0, 'Y', 'Y', sysdate, sysdate, 'pcimino', 'pcimino', 'S', null);

-- EXT_SYSTEM_CODE 1 for Profile
-- EXT_CORRES_TYPE_CODE is the Code Profile uses for this email
INSERT INTO CSP.CSP_EXT_CORRES_TYPE
VALUES (1, 82, 98030, sysdate, sysdate, 'pcimino', 'pcimino');

COMMIT;
