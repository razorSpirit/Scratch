--
-- =========================================<< backout_CheckWasNotSentFundshtml.xsl >>=========================================================
--
-- ============================================================================
-- ===  Email Subject              : **BACKOUT**  Notification That Check Was Not Sent
-- ===  Notification ID (nid)   :  33
-- ===  Template ID (tid)        : 518
-- ===  Email ID (eid)             : 599 
-- === MULTIPART                : 600   PARTS 600,601
-- ===
-- ===  Because of Funds
-- ============================================================================
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP001>>xxxxxxx =======Remove BODYPART AND MULTIPART
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--
DELETE FROM csp.email_bodypart WHERE email_bodypart_code in (600,601);
DELETE FROM CSP.EMAIL_MULTIPART_PART WHERE EMAIL_MULTIPART_CODE = 600;
DELETE FROM CSP.EMAIL_MULTIPART WHERE EMAIL_MULTIPART_CODE = 600;
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP002>>xxxxxxx =======Remove MARRIAGE of email definition to template definition
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--
DELETE FROM CSP.CORRES_GEN_TEMPLATE WHERE TEMPLATE_ID = 518;
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP003>>xxxxxxx =======Remove email definition
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--
DELETE FROM CSP.EMAIL_DEF WHERE EMAIL_DEF_CODE = 599;
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP004>>xxxxxxx =======Remove notification id
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--
DELETE FROM  CSP.CSP_EXT_CORRES_TYPE  WHERE EXT_CORRES_TYPE_CODE = 33;
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP005>>xxxxxxx =======Remove template definition
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--
DELETE FROM CSP.TEMPLATE_PARAM WHERE TEMPLATE_ID = 518;
DELETE FROM CSP.TEMPLATE_DESC  WHERE TEMPLATE_ID = 518;
DELETE FROM CSP.TEMPLATE WHERE TEMPLATE_ID = 518;
--
COMMIT;
end;
/
--