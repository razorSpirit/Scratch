-- ==
-- ============================================================================
-- == ===Fulfillment Doc     : {$docID}
-- ============================================================================
-- ==          ---------- CHANGES -----------
-- ==                         desc : {$desc}
-- == ===Template ID (tid)         : {$tid}
-- == ===Doc ID (did)              : {$docID}
-- == ===Template Group Code       : {$tgc}
-- == ===Template Group Code Sort  : {$tgcSort}
--
-- == NEW PARAMS {paramCode}, {paramDesc}
--
-- 
-- ============================================================================
--
-- xxxxxxxx<<STEP001>>xxxxxxx ======= Create a NEW template and a template description 
--
INSERT INTO CSP.TEMPLATE
(TEMPLATE_ID, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, POSTAL_GEN_CODE, PACKAGE_SORT_NUM) 
VALUES 
({$tid}, sysdate, sysdate, 'abrida', 'abrida', 'I2', 0);
--
INSERT INTO CSP.TEMPLATE_DESC 
(TEMPLATE_ID, LOCALE_CODE, SHORT_DESC, DESCRIPTION, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
({$tid}, 'en-US', '{$desc}', '{$desc}', sysdate, sysdate, 'abrida', 'abrida');
--
-- ****************** NEW PARAM ONLY *********************
--
INSERT INTO CSP.TEMPLATE_PARAM_DESC (PARAM_CODE, LOCALE_CODE, DESCRIPTION, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
('{paramCode}', 'en-US', '{paramDesc}', sysdate, sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP002>>xxxxxxx ======= Add template PARAMS
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
({$tid}, 'amt', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
({$tid}, 'cif', 0, 'Y', 'Y', 'N', '10.0', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
({$tid}, 'efd', 0, 'Y', 'Y', 'D', 'MMMM dd, yyyy', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
({$tid}, 'fname1', 102, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
({$tid}, 'payname', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP003>>xxxxxxx ======= Marry template to DocId
--
INSERT INTO CSP.CORRES_GEN_TEMPLATE
(TEMPLATE_ID, EXTERNAL_REF, CORRES_GENERATOR_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
({$tid}, '{$docID}', 'I2', sysdate, sysdate, 'abrida', 'abrida');

--
-- xxxxxxxx<<STEP004>>xxxxxxx ======= Optionally Add to Template_Template_Group
--
INSERT INTO CSP.TEMPLATE_TEMPLATE_GROUP
(TEMPLATE_GROUP_CODE, TEMPLATE_ID, SORT_NUM, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
('{$tgc}', {$tid}, {$tgcSort}, sysdate, sysdate, 'abrida', 'abrida');
      
--                
-- ================================================== COMMIT ========================================================
--
COMMIT;
-- ================================================== EOF =============================================================

-- ===============================================================================================================               
-- ================================================== CSV ========================================================
-- ===============================================================================================================               
--
-- xxxxxxxx<<STEP001>>xxxxxxx ======= Create a NEW template and a template description 
--
>>>>>>add to \WESP\Source\SQL\static_data\csp\csp-template.csv
{$tid},I2,$NULL,$NULL,0

>>>>>>add to \WESP\Source\SQL\static_data\csp\csp-template_desc.csv
{$tid},en-US,{$desc},{$desc}

--
-- ****************** NEW PARAM ONLY *********************
--  CSP.TEMPLATE_PARAM_DESC 
acctBal,en-US,ING Account Balance
acctNum,en-US,ING Account Number
acn,en-US,Customer Number
amt,en-US,Amount
amt1,en-US,Amount
--
-- xxxxxxxx<<STEP002>>xxxxxxx ======= Add template PARAMS
--
>>>>>>add to \WESP\Source\SQL\static_data\csp\csp-template_param.csv
{$tid},apy,0,Y,Y,S ,$NULL
{$tid},cif,0,Y,Y,N ,10
{$tid},date,0,Y,Y,D ,"MMMM dd, yyyy"
{$tid},fname1,102,Y,Y,S ,$NULL
{$tid},odt,0,Y,Y,D ,MM/dd/yyyy
{$tid},zeoacct,102,Y,Y,S ,$NULL
{$tid},zeofund,102,Y,Y,S ,$NULL

--
-- xxxxxxxx<<STEP003>>xxxxxxx ======= Marry template to DocId
--

>>>>>>add to \WESP\Source\SQL\static_data\csp\csp-corres_gen_template.csv
I2,{$tid},{$docID}

--
-- xxxxxxxx<<STEP004>>xxxxxxx ======= Optionally Add to Template_Template_Group
--

>>>>>>add to \WESP\Source\SQL\static_data\csp\csp-template_template_group.csv
{$tgc},{$tid},{$tgcSort}

--
-- xxxxxxxx<<STEP009>>xxxxxxx ======= 
-- *** From the WESP Directory ****
CreateDBDeployZip track oldTag local [INGDE\abrida svnpwd]