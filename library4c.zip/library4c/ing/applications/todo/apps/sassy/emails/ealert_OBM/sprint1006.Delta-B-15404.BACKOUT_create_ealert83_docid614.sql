-- Backout EALERT
-- 
-- TID : 98036 
-- EALERT: 83
--
DELETE FROM CSP.CSP_EXT_CORRES_TYPE
  WHERE EXT_SYSTEM_CODE = 1 AND
        EXT_CORRES_TYPE_CODE = 83;    
--
DELETE FROM CSP.TEMPLATE_PARAM
   WHERE  
     TEMPLATE_ID = 98036;
--     
-- ==== NEW PARAMS ONLY
--
DELETE FROM CSP.TEMPLATE_PARAM_DESC
   WHERE  
     PARAM_CODE = 'kfname';
--
DELETE FROM CSP.TEMPLATE_PARAM_DESC
   WHERE  
     PARAM_CODE = 'klname';          
--
DELETE FROM CSP.CORRES_GEN_TEMPLATE
   WHERE  
     TEMPLATE_ID = 98036;
--
DELETE FROM CSP.TEMPLATE_DESC
   WHERE  
     TEMPLATE_ID = 98036;          
--
DELETE FROM CSP.TEMPLATE
   WHERE  
     TEMPLATE_ID = 98036;
--
COMMIT;
-- ================================================== EOF =============================================================
