--
-- Create Directory,  body and file locators
--
create or replace directory EMAIL_UPLOAD as '/home/oracle/temp/email';
declare bodyLocator clob;
fileLocator bfile;
BEGIN
--
-- ============================= 1 10DayTCReminder =============================
--
DBMS_LOB.CREATETEMPORARY(bodyLocator,true); 

update CSP.EMAIL_BODYPART
   set BODY_TXT = empty_clob(),
   MODIFIED_BY = 'abrida',
   MODIFIED_DATE = sysdate
where EMAIL_BODYPART_CODE  = 1566
    and EMAIL_BODY_TYPE_CODE = 17
returning body_txt into bodyLocator;
 
fileLocator := bfilename('EMAIL_UPLOAD', '10DayTCRemindertext.xsl');
dbms_lob.fileOpen(fileLocator);
dbms_lob.loadFromFile(bodyLocator, fileLocator, dbms_lob.getLength(fileLocator));
dbms_lob.fileClose(fileLocator);
commit;
--
-- Update HTML
--
DBMS_LOB.CREATETEMPORARY(bodyLocator,true); 

update CSP.EMAIL_BODYPART
   set BODY_TXT = empty_clob(),
   MODIFIED_BY = 'abrida',
   MODIFIED_DATE = sysdate
where EMAIL_BODYPART_CODE  = 1567
    and EMAIL_BODY_TYPE_CODE = 17
returning body_txt into bodyLocator;
 
fileLocator := bfilename('EMAIL_UPLOAD', '10DayTCReminderhtml.xsl');
dbms_lob.fileOpen(fileLocator);
dbms_lob.loadFromFile(bodyLocator, fileLocator, dbms_lob.getLength(fileLocator));
dbms_lob.fileClose(fileLocator);
commit;
--
-- ============================= 2 20DayTCReminder =============================
--
DBMS_LOB.CREATETEMPORARY(bodyLocator,true); 

update CSP.EMAIL_BODYPART
   set BODY_TXT = empty_clob(),
   MODIFIED_BY = 'abrida',
   MODIFIED_DATE = sysdate
where EMAIL_BODYPART_CODE  = 1571
    and EMAIL_BODY_TYPE_CODE = 17
returning body_txt into bodyLocator;
 
fileLocator := bfilename('EMAIL_UPLOAD', '20DayTCRemindertext.xsl');
dbms_lob.fileOpen(fileLocator);
dbms_lob.loadFromFile(bodyLocator, fileLocator, dbms_lob.getLength(fileLocator));
dbms_lob.fileClose(fileLocator);
commit;
--
-- Update HTML
--
DBMS_LOB.CREATETEMPORARY(bodyLocator,true); 

update CSP.EMAIL_BODYPART
   set BODY_TXT = empty_clob(),
   MODIFIED_BY = 'abrida',
   MODIFIED_DATE = sysdate
where EMAIL_BODYPART_CODE  = 1572
    and EMAIL_BODY_TYPE_CODE = 17
returning body_txt into bodyLocator;
 
fileLocator := bfilename('EMAIL_UPLOAD', '20DayTCReminderhtml.xsl');
dbms_lob.fileOpen(fileLocator);
dbms_lob.loadFromFile(bodyLocator, fileLocator, dbms_lob.getLength(fileLocator));
dbms_lob.fileClose(fileLocator);
commit;
--
-- ============================= 3 30DayTCReminder =============================
--
DBMS_LOB.CREATETEMPORARY(bodyLocator,true); 

update CSP.EMAIL_BODYPART
   set BODY_TXT = empty_clob(),
   MODIFIED_BY = 'abrida',
   MODIFIED_DATE = sysdate
where EMAIL_BODYPART_CODE  = 1576
    and EMAIL_BODY_TYPE_CODE = 17
returning body_txt into bodyLocator;
 
fileLocator := bfilename('EMAIL_UPLOAD', '30DayTCRemindertext.xsl');
dbms_lob.fileOpen(fileLocator);
dbms_lob.loadFromFile(bodyLocator, fileLocator, dbms_lob.getLength(fileLocator));
dbms_lob.fileClose(fileLocator);
commit;
--
-- Update HTML
--
DBMS_LOB.CREATETEMPORARY(bodyLocator,true); 

update CSP.EMAIL_BODYPART
   set BODY_TXT = empty_clob(),
   MODIFIED_BY = 'abrida',
   MODIFIED_DATE = sysdate
where EMAIL_BODYPART_CODE  = 1577
    and EMAIL_BODY_TYPE_CODE = 17
returning body_txt into bodyLocator;
 
fileLocator := bfilename('EMAIL_UPLOAD', '30DayTCReminderhtml.xsl');
dbms_lob.fileOpen(fileLocator);
dbms_lob.loadFromFile(bodyLocator, fileLocator, dbms_lob.getLength(fileLocator));
dbms_lob.fileClose(fileLocator);
commit;
--
-- ============================= 4 InitialCallhtml =============================
--
DBMS_LOB.CREATETEMPORARY(bodyLocator,true); 

update CSP.EMAIL_BODYPART
   set BODY_TXT = empty_clob(),
   MODIFIED_BY = 'abrida',
   MODIFIED_DATE = sysdate
where EMAIL_BODYPART_CODE  = 1671
    and EMAIL_BODY_TYPE_CODE = 17
returning body_txt into bodyLocator;
 
fileLocator := bfilename('EMAIL_UPLOAD', 'InitialCalltext.xsl');
dbms_lob.fileOpen(fileLocator);
dbms_lob.loadFromFile(bodyLocator, fileLocator, dbms_lob.getLength(fileLocator));
dbms_lob.fileClose(fileLocator);
commit;
--
-- Update HTML
--
DBMS_LOB.CREATETEMPORARY(bodyLocator,true); 

update CSP.EMAIL_BODYPART
   set BODY_TXT = empty_clob(),
   MODIFIED_BY = 'abrida',
   MODIFIED_DATE = sysdate
where EMAIL_BODYPART_CODE  = 1672
    and EMAIL_BODY_TYPE_CODE = 17
returning body_txt into bodyLocator;
 
fileLocator := bfilename('EMAIL_UPLOAD', 'InitialCallhtml.xsl');
dbms_lob.fileOpen(fileLocator);
dbms_lob.loadFromFile(bodyLocator, fileLocator, dbms_lob.getLength(fileLocator));
dbms_lob.fileClose(fileLocator);
commit;
--
-- ============================= 5 WelcomeEO =============================
--
DBMS_LOB.CREATETEMPORARY(bodyLocator,true); 

update CSP.EMAIL_BODYPART
   set BODY_TXT = empty_clob(),
   MODIFIED_BY = 'abrida',
   MODIFIED_DATE = sysdate
where EMAIL_BODYPART_CODE  = 666
    and EMAIL_BODY_TYPE_CODE = 17
returning body_txt into bodyLocator;
 
fileLocator := bfilename('EMAIL_UPLOAD', 'WelcomeEOtext.xsl');
dbms_lob.fileOpen(fileLocator);
dbms_lob.loadFromFile(bodyLocator, fileLocator, dbms_lob.getLength(fileLocator));
dbms_lob.fileClose(fileLocator);
commit;
--
-- Update HTML
--
DBMS_LOB.CREATETEMPORARY(bodyLocator,true); 

update CSP.EMAIL_BODYPART
   set BODY_TXT = empty_clob(),
   MODIFIED_BY = 'abrida',
   MODIFIED_DATE = sysdate
where EMAIL_BODYPART_CODE  = 667
    and EMAIL_BODY_TYPE_CODE = 17
returning body_txt into bodyLocator;
 
fileLocator := bfilename('EMAIL_UPLOAD', 'WelcomeEOhtml.xsl');
dbms_lob.fileOpen(fileLocator);
dbms_lob.loadFromFile(bodyLocator, fileLocator, dbms_lob.getLength(fileLocator));
dbms_lob.fileClose(fileLocator);
commit;
--
-- ============================= 6 CheckWasNotSentFunds =============================
--
DBMS_LOB.CREATETEMPORARY(bodyLocator,true); 

update CSP.EMAIL_BODYPART
   set BODY_TXT = empty_clob(),
   MODIFIED_BY = 'abrida',
   MODIFIED_DATE = sysdate
where EMAIL_BODYPART_CODE  = 600
    and EMAIL_BODY_TYPE_CODE = 17
returning body_txt into bodyLocator;
 
fileLocator := bfilename('EMAIL_UPLOAD', 'CheckWasNotSentFundstext.xsl');
dbms_lob.fileOpen(fileLocator);
dbms_lob.loadFromFile(bodyLocator, fileLocator, dbms_lob.getLength(fileLocator));
dbms_lob.fileClose(fileLocator);
commit;
--
-- Update HTML
--
DBMS_LOB.CREATETEMPORARY(bodyLocator,true); 

update CSP.EMAIL_BODYPART
   set BODY_TXT = empty_clob(),
   MODIFIED_BY = 'abrida',
   MODIFIED_DATE = sysdate
where EMAIL_BODYPART_CODE  = 601
    and EMAIL_BODY_TYPE_CODE = 17
returning body_txt into bodyLocator;
 
fileLocator := bfilename('EMAIL_UPLOAD', 'CheckWasNotSentFundshtml.xsl');
dbms_lob.fileOpen(fileLocator);
dbms_lob.loadFromFile(bodyLocator, fileLocator, dbms_lob.getLength(fileLocator));
dbms_lob.fileClose(fileLocator);
commit;
--
-- ============================= 7 EmailMoney15Dayhtml =============================
--
DBMS_LOB.CREATETEMPORARY(bodyLocator,true); 

update CSP.EMAIL_BODYPART
   set BODY_TXT = empty_clob(),
   MODIFIED_BY = 'abrida',
   MODIFIED_DATE = sysdate
where EMAIL_BODYPART_CODE  = 586
    and EMAIL_BODY_TYPE_CODE = 17
returning body_txt into bodyLocator;
 
fileLocator := bfilename('EMAIL_UPLOAD', 'EmailMoney15Daytext.xsl');
dbms_lob.fileOpen(fileLocator);
dbms_lob.loadFromFile(bodyLocator, fileLocator, dbms_lob.getLength(fileLocator));
dbms_lob.fileClose(fileLocator);
commit;
--
-- Update HTML
--
DBMS_LOB.CREATETEMPORARY(bodyLocator,true); 

update CSP.EMAIL_BODYPART
   set BODY_TXT = empty_clob(),
   MODIFIED_BY = 'abrida',
   MODIFIED_DATE = sysdate
where EMAIL_BODYPART_CODE  = 587
    and EMAIL_BODY_TYPE_CODE = 17
returning body_txt into bodyLocator;
 
fileLocator := bfilename('EMAIL_UPLOAD', 'EmailMoney15Dayhtml.xsl');
dbms_lob.fileOpen(fileLocator);
dbms_lob.loadFromFile(bodyLocator, fileLocator, dbms_lob.getLength(fileLocator));
dbms_lob.fileClose(fileLocator);
commit;
--
-- End
--
END;
/
--