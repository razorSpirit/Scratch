2 batch jobs run :

   1. Payment Alerts (PaymentGetAlerts)
                         - takes transactions from PROFILE and adds these to CORRES tables
                           the notification id (nid) links the transaction to the email

   2.  Email Generator (CorresEmail)       - takes CORRES tables and generates emails


subject text: Bill Payment Has Been Sent
                        points to 550


CSP.EMAIL_DEF
   EMAIL_DEF_CODE                                            585
   EMAIL_MULTIPART_CODE                              *586
   
CSP.EMAIL_MULTIPART_PART
  EMAIL_MULTIPART_PART_ID
  EMAIL_MULTIPART_CODE                               *586
  PART_MULTIPART_CODE
  PART_BODYPART_CODE
  
CSP.CORRES_GEN_TEMPLATE
    CORRES_GENERATOR_CODE      E1
    TEMPLATE_ID                            510
    EXTERNAL_REF                          585
    
CSP.TEMPLATE_DESC
   TEMPLATE_ID                            510
   SHORT_DESC                             15 DAY EMAIL REMINDER      
   
   
   xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   
   <?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://www.w3.org/1999/xhtml">
  <xsl:output method="html" omit-xml-declaration="yes" media-type="text/plain"/>
  <xsl:param name="fname1"/>
  <xsl:param name="cif"/>
  <xsl:param name="payname"/>
  <xsl:param name="amt"/>
  <xsl:param name="efd"/>
  <xsl:template match="/">
  Dear <xsl:value-of select="$fname1"/>,
  Customer Number: XXXXXXX<xsl:value-of select="substring(format-number($cif,'0000000000'),8,3)"/>
  
  Date: <xsl:value-of select="$efd"/>
  
  This email is to let you know that your Electric Orange bill payment to <xsl:value-of select="$payname"/> for $<xsl:value-of select="format-number($amt,'#,##0.00')"/> has been sent.
  You can expect <xsl:value-of select="$payname"/> to receive it in 2-5 days
  
  For more information regarding when it will post to your account, you can contact <xsl:value-of select="$payname"/>.  To view
  your account balance or make more Paymnets, login to ingdirect.com.
  
  Thanks for using Electric Orange Bill Pay.

  P.S. Don't forget to check out our great rates:
  Today's CD Rates (http://home.ingdirect.com/products/products.asp?s=OrangeCD)
  Today's Mortgage Rates (http://home.ingdirect.com/products/products.asp?s=RatesandClosingCost)
  </xsl:template>
</xsl:stylesheet>


xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

CORRES correspondence.   DGW PayementGetAlerts posts to this table.

CORRES_PARAM correspondence parameters.  DGW PayementGetAlerts posts to this table.


CSP_EXT_SYSTEM 
 (PK1) EXT_SYSTEM_CODE  NUMBER(3)                    NOT NULL,
 
CSP_EXT_CORRES_TYPE
 (PK1) EXT_SYSTEM_CODE       NUMBER(3)               NOT NULL,
 (PK2) EXT_CORRES_TYPE_CODE  VARCHAR2(10)            NOT NULL,
          TEMPLATE_ID           NUMBER(10)              NOT NULL,

    

EMAIL_MULTIPART
    EMAIL_MULTIPART_CODE                   
     596  

EMAIL_MULTIPART_PART
     EMAIL_MULTIPART_CODE      EMAIL_MULTIPART_ID    PART_MULTIPART_ID       PART_MULTIPART_CODE
     596                       572                   596                     {BLANK}
     596                       573                   597                     {BLANK}
     
EMAIL_BODYPART    
     EMAIL_BODYPART_CODE      BODY_TXT
     596                      {CLOB}
     597                      {CLOB}

EMAIL_DEF
     EMAIL_DEF_CODE        EMAIL_MULTIPART_CODE       SUBJECT_TXT
     595                   596                        Bill Payment Scheduled

CORRES_GEN_TEMPLATE
     CORRES_GENERATOR_CODE       EXTERNAL_REF            TEMPLATE_ID 
     E1                          595                      512

CSP_EXT_CORRES_TYPE
      EXT_SYSTEM_CODE     EXT_CORRES_TYPE_CODE    TEMPLATE_ID
      1                                    12                                            512
      
where to store xsl for upload
C:\dev\dev_eocl\WESP\Source\SQL\scripts_by_schema\csp\email

 >>>>>>>>>>>>>>>>  EMAIL DEF CODE IS 6410
 >>>>>>>>>>>>>>>>>>>>>>>EMAIL MULTIPART CODE IS 6411
 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> EMAIL PLAIN TEXT IS 6411
 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> EMAIL HTML       IS 6412

<<STEP001>>
An Email can be either Plain Text or Html.
So, a multipart email definition record needs to created
in TABLE EMAIL_MULTIPART and given a unique code (MULTIPART CODE IS 6411).

<<STEP002>
Then a MULTIPART PART record needs to be created for each part (where part is text and html).
So, 2 PARTS RECORDS ARE CREATED in table EMAIL_MULTIPART_PART with unique codes,
EMAIL_MULTIPART_PART_ID 6411 and 6412.  AND both
these records will reference the TABLE EMAIL_MULTIPART with MULTIPART CODE IS 6411.

<<STEP003>>
Now that we have the parts defined, we need to create the actual parts.
So, we create a body part for each part in the csp.email_bodypart table.

<<STEP004>>

xxxxxxxxxxxxxxxxxxxxxxxxxx GET A NOTIFICATION ID !!!!!!!!!!!!!!!!!!


-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP001>>xxxxxxx =======Create a Multipart definition
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
INSERT INTO EMAIL_MULTIPART ( EMAIL_MULTIPART_CODE, MIME_SUBTYPE, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY )
VALUES (6411, 'alternative',  sysdate,  sysdate, 'abrida', 'abrida');
Commit;
/

-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP002>>xxxxxxx =======Create 2 Parts for TEXT and HTML MAILINGS and MARRY each to the EMAIL_MULTIPART table.
-- xxxxxxxxxxxxxxxxxxxxxxxxxx

-- ......<<STEP002A>>===== CREATE PART WITH PART_ID 6411 FOR MULTIPART_CODE 6411 (this will be for the TEXT EMAIL)
INSERT INTO EMAIL_MULTIPART_PART ( EMAIL_MULTIPART_PART_ID, EMAIL_MULTIPART_CODE, SORT_NUM,PART_MULTIPART_CODE, PART_BODYPART_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES (seq_email_multipart_part.nextval, 6411, 1, NULL, 6411,  sysdate,  sysdate, 'abrida', 'abrida'); 

-- ......<<STEP002B>>===== CREATE PART WITH PART_ID 6412 FOR MULTIPART_CODE 6411 (this will be for the HTML EMAIL)
INSERT INTO EMAIL_MULTIPART_PART ( EMAIL_MULTIPART_PART_ID, EMAIL_MULTIPART_CODE, SORT_NUM,PART_MULTIPART_CODE, PART_BODYPART_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES (seq_email_multipart_part.nextval, 6411, 1, NULL, 6412,  sysdate,  sysdate, 'abrida', 'abrida'); 
Commit;
/

-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP003>>xxxxxxx =======Create the body part for each part using the respective EMAIL_MULTIPART_PART_ID's
-- xxxxxxxxxxxxxxxxxxxxxxxxxx

-- ......<<STEP002A>>===== CREATE BODY PART WITH PART_ID 6411 (TEXT BODY PART)
declare bodyLocator clob; fileLocator bfile; begin
insert into csp.email_bodypart (email_bodypart_code,email_body_type_code,mime_type,mime_encoding,mime_disposition, body_txt,created_by,created_date,modified_by,modified_date)
values (6411, 17, 'text/plain; charset="iso-8859-1"', '7bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate)
returning body_txt into bodyLocator;
 
fileLocator := bfilename('EMAIL_UPLOAD', 'CustomerAcceptOMAtext.xsl');
dbms_lob.fileOpen(fileLocator);
dbms_lob.loadFromFile(bodyLocator, fileLocator, dbms_lob.getLength(fileLocator));
dbms_lob.fileClose(fileLocator);
commit;
end;
/

-- ......<<STEP002B>>===== CREATE BODY PART WITH PART_ID 6412 (HTML BODY PART)
declare bodyLocator clob; fileLocator bfile; begin
insert into csp.email_bodypart (email_bodypart_code,email_body_type_code,mime_type,mime_encoding,mime_disposition,body_txt,created_by,created_date,modified_by,modified_date)
values (6412, 17, 'text/html;"', '8bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate)
returning body_txt into bodyLocator;
 
fileLocator := bfilename('EMAIL_UPLOAD', 'CustomerAcceptOMAhtml.xsl');
dbms_lob.fileOpen(fileLocator);
dbms_lob.loadFromFile(bodyLocator, fileLocator, dbms_lob.getLength(fileLocator));
dbms_lob.fileClose(fileLocator);
commit;
end;
/

drop directory email_upload;

-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP004>>xxxxxxx =======Create an email definition and MARRY it to the EMAIL_MULTIPART table.
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
  
INSERT INTO EMAIL_DEF ( EMAIL_DEF_CODE, EMAIL_MULTIPART_CODE, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY, DESCRIPTION, FROM_TXT, REPLY_ADDRESS,SUBJECT_TXT )
VALUES (6410, 6411,  sysdate,  sysdate, 'abrida', 'abrida', 'Accept OMA', 'ING DIRECT', 'mortgages@ingdirect.com', 'ING DIRECT-You have Accepted Your Orange Mortgage Offer!!');
Commit;
/


-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP005>>xxxxxxx ======= Create a template and a template description 
-- xxxxxxxxxxxxxxxxxxxxxxxxxx

INSERT INTO TEMPLATE ( TEMPLATE_ID, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY,POSTAL_GEN_CODE, FAX_GEN_CODE, EMAIL_GEN_CODE, PACKAGE_SORT_NUM )
VALUES (9031, sysdate, sysdate, 'abrida', 'abrida', NULL, NULL, 'E1', 0);
Commit;
/
 
INSERT INTO TEMPLATE_DESC (TEMPLATE_ID, LOCALE_CODE, SHORT_DESC, DESCRIPTION, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE)
VALUES (9031, 'en-US', 'Accept OMA', 'Accept OMA', 'abrida',  sysdate, 'abrida',  sysdate);
Commit;
/

-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP006>>xxxxxxx ======= Create the parameters for the template AND MARRY each to the TEMPLATE table.
-- xxxxxxxxxxxxxxxxxxxxxxxxxx

INSERT INTO TEMPLATE_PARAM ( TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND,CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE,RESTRICT_DETAIL )
VALUES (9031, 'appl', 50, 'Y', 'Y',  sysdate,  sysdate, 'abrida', 'abrida', 'S ', NULL); 
INSERT INTO TEMPLATE_PARAM ( TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND,CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE,RESTRICT_DETAIL )
VALUES (9031, 'applt1', 50, 'Y', 'Y',  sysdate,  sysdate, 'abrida', 'abrida', 'S ', NULL); 
Commit;
/

-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP007>>xxxxxxx ======= Marry the TEMPLATE table to the EMAIL_DEF table
-- xxxxxxxxxxxxxxxxxxxxxxxxxx

INSERT INTO CORRES_GEN_TEMPLATE ( CORRES_GENERATOR_CODE, TEMPLATE_ID, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY, EXTERNAL_REF ) 
VALUES ('E1',9031,  sysdate,  sysdate, 'abrida', 'abrida', '6410');
Commit;
/