-- ==
-- ============================================================================
-- == ===File                      : PaymentScheduledhtml.xsl
-- == ===Name                      : BillPay_Rem_Mult
-- == ===Description               : Multiple Payments Scheduled
-- == ===Notification ID (nid)     : 13 
-- ============================================================================
-- ==          ---------- CHANGES -----------
-- ==                       ealert :  13
-- ==                         desc :  Multiple Payments Scheduled
-- ==                      subject :  You Have Payments Scheduled for {efd}
-- == ===Template ID (tid)         : 513 TO 1513
-- == ===Email ID (eid)            : 640 TO 1640
-- == ===MULTIPART_CODE            : 641  TO 1641
-- == ===BODY PART                 : 641,642 TO 1641,1642
-- ============================================================================
--
-- xxxxxxxx<<STEP001>>xxxxxxx ======= Create a NEW template and a template description 
--
INSERT INTO CSP.TEMPLATE
(TEMPLATE_ID, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, EMAIL_GEN_CODE, PACKAGE_SORT_NUM) 
VALUES 
(1513, sysdate, sysdate, 'abrida', 'abrida', 'E1', 0);
--
INSERT INTO CSP.TEMPLATE_DESC 
(TEMPLATE_ID, LOCALE_CODE, SHORT_DESC, DESCRIPTION, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'en-US', 'Multiple Payments Scheduled', 'Multiple Payments Scheduled', sysdate, sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP002>>xxxxxxx ======= Add template PARAMS
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'cif', 0, 'Y', 'Y', 'N', '10.0', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'efd', 0, 'Y', 'Y', 'D', 'MM/dd/yyyy', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'fname1', 102, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'funddate', 0, 'Y', 'Y', 'D', 'MM/dd/yyyy', sysdate, sysdate, 'abrida', 'abrida');
--

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'amt1', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'amt2', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'amt3', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'amt4', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'amt5', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'amt6', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'amt7', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'amt8', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'amt9', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'amt10', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'amt11', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'amt12', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'amt13', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'amt14', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'amt15', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'amt16', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'amt17', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'amt18', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'amt19', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'amt20', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname1', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname2', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname3', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname4', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname5', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname6', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname7', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname8', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname9', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname10', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname11', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname12', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname13', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname14', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname15', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname16', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname17', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname18', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname19', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, 'payname20', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
--
-- xxxxxxxx<<STEP003>>xxxxxxx ======= Marry template to email definition
--
INSERT INTO CSP.CORRES_GEN_TEMPLATE
(TEMPLATE_ID, EXTERNAL_REF, CORRES_GENERATOR_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1513, '1640', 'E1', sysdate, sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP004>>xxxxxxx ======= Create Multipart Definition
--
INSERT INTO EMAIL_MULTIPART 
(EMAIL_MULTIPART_CODE, MIME_SUBTYPE, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY)
VALUES (1641, 'alternative',  sysdate,  sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP005>>xxxxxxx ======= Create email definition with Multipart definition
--
INSERT INTO EMAIL_DEF 
(EMAIL_DEF_CODE, EMAIL_MULTIPART_CODE, DESCRIPTION, FROM_TXT, SUBJECT_TXT, REPLY_ADDRESS, SENDER_ADDRESS, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY)
VALUES (1640, 1641,  'Multiple Payments Scheduled', 'ING DIRECT', 'You Have Payments Scheduled for {efd}', 'sales@ingdirect.com', '', sysdate,  sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP006>>xxxxxxx ======= Add the EMPTY PARTS(plain, html) to be uploaded later
--
insert into csp.email_bodypart (email_bodypart_code, email_body_type_code,mime_type,mime_encoding,mime_disposition, body_txt,created_by,created_date,modified_by,modified_date)
values (1641, 17, 'text/plain; charset="iso-8859-1"', '7bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate);

insert into csp.email_bodypart (email_bodypart_code,email_body_type_code,mime_type,mime_encoding,mime_disposition,body_txt,created_by,created_date,modified_by,modified_date)
values (1642, 17, 'text/html;"', '8bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate);
--
-- xxxxxxxx<<STEP007>>xxxxxxx ======= Create Parts Definitions for the Multipart 
--
  
INSERT INTO EMAIL_MULTIPART_PART (EMAIL_MULTIPART_CODE, PART_BODYPART_CODE, PART_MULTIPART_CODE, EMAIL_MULTIPART_PART_ID, SORT_NUM,  CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES (1641, 1641,  NULL,  seq_email_multipart_part.nextval, 1, sysdate,  sysdate, 'abrida', 'abrida'); 
--
INSERT INTO EMAIL_MULTIPART_PART (EMAIL_MULTIPART_CODE, PART_BODYPART_CODE, PART_MULTIPART_CODE, EMAIL_MULTIPART_PART_ID, SORT_NUM,  CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES (1641, 1642,  NULL,  seq_email_multipart_part.nextval, 1, sysdate,  sysdate, 'abrida', 'abrida'); 

--
-- xxxxxxxx<<STEP008>>xxxxxxx ======= Update Notification ID with new Template
--
UPDATE csp.csp_ext_corres_type
     SET TEMPLATE_ID = 1513,
             MODIFIED_DATE = sysdate,
             MODIFIED_BY = 'abrida'
     WHERE
            EXT_SYSTEM_CODE = 1
        AND
           EXT_CORRES_TYPE_CODE = 13;      

--                
-- ================================================== COMMIT ========================================================
--
COMMIT;
-- ================================================== EOF =============================================================