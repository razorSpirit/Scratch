-- ========================================================================================
-- ==                                  Backout eAlert                                   ==
-- ========================================================================================
-- ==
-- ============================================================================
-- == ===Ext System   ID (sys)     : {$sys}
-- == ===Notification ID (nid)     : {$nid}
-- ============================================================================
-- ==          ---------- CHANGES -----------
-- ==                   ext system :  {$sys}
-- ==                       ealert :  {$nid}
-- ==                         desc :  --desc--
-- ==                      subject :  --subj--
-- == ===Template ID (tid)         : {$tid}
-- == ===Email ID (eid)            : {$eid}
-- == ===MULTIPART_CODE            : {$mpCode}
-- == ===BODY PART                 : {$bodypart1},{$bodypart2}
--
DELETE FROM EMAIL_MULTIPART_PART
   WHERE  
      EMAIL_MULTIPART_CODE = {$mpCode}
   AND
     PART_BODYPART_CODE in ({$bodypart1},{$bodypart2});
--
DELETE FROM EMAIL_BODYPART
   WHERE  
      EMAIL_BODY_TYPE_CODE = 17
   AND
     EMAIL_BODYPART_CODE in ({$bodypart1},{$bodypart2});
--
DELETE FROM EMAIL_DEF
   WHERE  
      EMAIL_DEF_CODE = {$eid}
   AND
     EMAIL_MULTIPART_CODE = {$mpCode};
--
DELETE FROM EMAIL_MULTIPART
   WHERE  
     EMAIL_MULTIPART_CODE = {$mpCode};
--
DELETE FROM CORRES_GEN_TEMPLATE
   WHERE  
     TEMPLATE_ID = {$tid};
--
DELETE FROM TEMPLATE_PARAM
   WHERE  
     TEMPLATE_ID = {$tid};
--
DELETE FROM TEMPLATE_DESC
   WHERE  
     TEMPLATE_ID = {$tid};
--
DELETE FROM TEMPLATE
   WHERE  
     TEMPLATE_ID = {$tid};
--
UPDATE csp.csp_ext_corres_type
     SET TEMPLATE_ID = {$tid},
             MODIFIED_DATE = sysdate,
             MODIFIED_BY = 'abrida'
     WHERE
            EXT_SYSTEM_CODE = {$sys}
        AND
           EXT_CORRES_TYPE_CODE = {$nid};

--                
-- ================================================== COMMIT ========================================================
--
COMMIT;
-- ================================================== EOF =============================================================
