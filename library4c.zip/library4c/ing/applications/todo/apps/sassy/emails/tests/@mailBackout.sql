--      
-- ===========================================================================================
-- =================================== BACKOUT for mail test =================================
-- ===========================================================================================
--
DELETE FROM CSP.DELIVERY
   WHERE delivery_id IN (9999990001);
--
--
DELETE FROM CSP.CORRES_PARAM
   WHERE corres_id IN (9999990001);
--
--                      
DELETE FROM CSP.CORRES 
   WHERE corres_id IN (9999990001);
--
--
DELETE FROM CST.PARTY_CONTACT
   WHERE party_contact_id = 9999999901;
--
--
DELETE FROM CST.CONTACT
   WHERE contact_id = 9999999901;
--
--
DELETE FROM CST.CONTACT_EADDRESS
   WHERE contact_eaddress_id = 9999999901;
--
--
DELETE FROM CST.PARTY 
    WHERE party_id = '9999991234';
--
--    
COMMIT;
--
--