doc: @@readme_mailTesting.txt

Sample of adding a new mailing and testing it.

Notes:
  1. mailBackout.sql - backs out both party and corres FOR a single correspondence
  2. mailCorres_22025 - specific testing for 22025
  3. Link QA Outlook : http://ingmnqa2x1.ingqa.com/exchange/

TaskManager :

<<Title>>
Sprint0904 Add and Test 22025 mail rev(0)

<<Desc>>
IN MNCSTQA2 with APPROVAL from Cheryl Mack

Purpose: Test mail for Account Access Locked

Execution: run the following scripts -

1. sprint0904.add_22025_AccountAccessLocked.sql
2. sprint0904.backout_22025_AccountAccessLocked.sql
3. **run this again to assure backout worked
   sprint0904.add_22025_AccountAccessLocked.sql
4. sprint0904.upload_22025_AccountAccessLocked.sql
5. mailBackout.sql 
6. mailParty.sql
7. mailCorres_22025.sql

<<Acceptance>>
attach all logs to this task

    