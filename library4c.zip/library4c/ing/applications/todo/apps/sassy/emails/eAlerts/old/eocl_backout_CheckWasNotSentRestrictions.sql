--
-- =========================================<< backout_CheckWasNotSentRestrictionshtml.xsl >>=========================================================
--
-- ============================================================================
-- ===  Email Subject               :  Notification That Check Was Not Sent
-- ===  Notification ID (nid)    :  34
-- ===  Template ID (tid)         : 519
-- ===  Email ID (eid)              : 600
-- === MULTIPART                 : 605   PARTS 606,607
-- ===
-- ===  Because of Restriction
-- ============================================================================
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP001>>xxxxxxx =======Remove BODYPART AND MULTIPART
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--
DELETE FROM csp.email_bodypart WHERE email_bodypart_code in (606,607);
DELETE FROM CSP.EMAIL_MULTIPART_PART WHERE EMAIL_MULTIPART_CODE = 605;
DELETE FROM CSP.EMAIL_MULTIPART WHERE EMAIL_MULTIPART_CODE = 605;
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP002>>xxxxxxx =======Remove MARRIAGE of email definition to template definition
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--
DELETE FROM CSP.CORRES_GEN_TEMPLATE WHERE TEMPLATE_ID = 519;
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP003>>xxxxxxx =======Remove email definition
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--
DELETE FROM CSP.EMAIL_DEF WHERE EMAIL_DEF_CODE = 600;
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP004>>xxxxxxx =======Remove notification id
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--
DELETE FROM  CSP.CSP_EXT_CORRES_TYPE  WHERE EXT_CORRES_TYPE_CODE = 34;
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP005>>xxxxxxx =======Remove template definition
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--
DELETE FROM CSP.TEMPLATE_PARAM WHERE TEMPLATE_ID = 519;
DELETE FROM CSP.TEMPLATE_DESC  WHERE TEMPLATE_ID = 519;
DELETE FROM CSP.TEMPLATE WHERE TEMPLATE_ID = 519;
--
COMMIT;
end;
/
--