--          
-- ===========================================================================================
-- ===================================== Mail Corres 22025 ===================================
-- ===========================================================================================
--
-- =======> CORRES
--
INSERT INTO CSP.CORRES
   ( corres_id, template_id, personid, 
     created_date, modified_date, created_by, modified_by    
    )
VALUES
   (  9999990001, 22025, '9999991234',
      to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'),  to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'), 'abrida', 'abrida'   
   );   
--
-- =======> CORRES_PARAM
--
INSERT INTO CSP.CORRES_PARAM
   (corres_id, param_code, param_value,
    created_date, modified_date, created_by, modified_by    
   )
VALUES
   (9999990001, 'cif', '9999991234',
    to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'),  to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'), 'abrida', 'abrida'   
   );
--
--   
INSERT INTO CSP.CORRES_PARAM
   (corres_id, param_code, param_value,
    created_date, modified_date, created_by, modified_by    
   )
VALUES
   (9999990001, 'efd', 'July 1, 2009',
    to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'),  to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'), 'abrida', 'abrida'   
   ); 
--
--   
INSERT INTO CSP.CORRES_PARAM
   (corres_id, param_code, param_value,
    created_date, modified_date, created_by, modified_by    
   )
VALUES
   (9999990001, 'fname1', 'Kristen',
    to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'),  to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'), 'abrida', 'abrida'   
   ); 
--
--   
INSERT INTO CSP.CORRES_PARAM
   (corres_id, param_code, param_value,
    created_date, modified_date, created_by, modified_by    
   )
VALUES
   (9999990001, 'submitTime', '10:15 PM',
    to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'),  to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'), 'abrida', 'abrida'   
   );
--
--   
INSERT INTO CSP.CORRES_PARAM
   (corres_id, param_code, param_value,
    created_date, modified_date, created_by, modified_by    
   )
VALUES
   (9999990001, 'test', '1',
    to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'),  to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'), 'abrida', 'abrida'   
   );     
--
-- =======> DELIVERY
--
INSERT INTO CSP.DELIVERY
   (delivery_id, corres_id, contact_id, delivery_status_code, 
    request_date, status_date, 
    external_identifier, delivery_method_code,   
    created_date, modified_date, created_by, modified_by    
   )
VALUES
   (9999990001, 9999990001, 9999999901, 'R',
    to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'),to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'),
    NULL, 'N',
    to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'),  to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'), 'abrida', 'abrida'   
   );
--      
-- ===========================================================================================
-- ====================================== COMMIT =============================================
-- ===========================================================================================
--
commit;
--    