--
-- =========================================<< backout_BillPaymentMultiReminderhtml.xsl >>=========================================================
--
-- ============================================================================
-- ===  Email Subject            :  **BACKOUT** Multiple Bill Payments Reminder
-- ===  Notification ID (nid) :  32
-- === Template ID (tid)       : 517
-- === Email ID (eid)            : 597
-- === MULTIPART              : 598   PARTS 598,599
-- ============================================================================
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP001>>xxxxxxx =======Remove BODYPART AND MULTIPART
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--
DELETE FROM csp.email_bodypart WHERE email_bodypart_code in (598, 599);
DELETE FROM CSP.EMAIL_MULTIPART_PART WHERE EMAIL_MULTIPART_CODE = 598;
DELETE FROM CSP.EMAIL_MULTIPART WHERE EMAIL_MULTIPART_CODE = 598;
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP002>>xxxxxxx =======Remove MARRIAGE of email definition to template definition
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--
DELETE FROM CSP.CORRES_GEN_TEMPLATE WHERE TEMPLATE_ID = 517;
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP003>>xxxxxxx =======Remove email definition
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--
DELETE FROM CSP.EMAIL_DEF WHERE EMAIL_DEF_CODE = 597;
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP004>>xxxxxxx =======Remove notification id
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--
DELETE FROM  CSP.CSP_EXT_CORRES_TYPE  WHERE EXT_CORRES_TYPE_CODE = 32;
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP005>>xxxxxxx =======Remove template definition
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--
DELETE FROM CSP.TEMPLATE_PARAM_DESC WHERE PARAM_CODE in ('list1', 'list2');
DELETE FROM CSP.TEMPLATE_PARAM WHERE TEMPLATE_ID = 517;
DELETE FROM CSP.TEMPLATE_DESC  WHERE TEMPLATE_ID = 517;
DELETE FROM CSP.TEMPLATE WHERE TEMPLATE_ID = 517;
--
COMMIT;
end;
/
--