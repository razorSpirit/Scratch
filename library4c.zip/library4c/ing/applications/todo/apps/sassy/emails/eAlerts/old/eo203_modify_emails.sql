--
-- =========================================<< 10DayTCReminder >>=========================================================
--
-- ============================================================================
-- == === File                            :  10DayTCRemindertext.xsl
-- == ===  Name                           : CallCent10
-- == ===  Email Subject                  : Reminder #1: Power Up Your New Electric Orange
-- == ===  Notification ID (nid)          : 6 
-- == === Template ID (tid)               : 506 to 1506
-- == === Email ID (eid)                  : 565 to 1565
-- == === MULTIPART                       : 566  to 1566  PART 566 to 1566, PART 567 to 1567
-- ============================================================================
--
-- xxxxxxxx<<STEP001>>xxxxxxx ======= Create a NEW template and a template description 
--
INSERT INTO CSP.TEMPLATE
(TEMPLATE_ID, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, EMAIL_GEN_CODE, PACKAGE_SORT_NUM) 
VALUES 
(1506, sysdate, sysdate, 'abrida', 'abrida', 'E1', 0);
--
INSERT INTO CSP.TEMPLATE_DESC 
(TEMPLATE_ID, LOCALE_CODE, SHORT_DESC, DESCRIPTION, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1506, 'en-US', 'Payments Have Been Sent', 'Payments Have Been Sent', sysdate, sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP002>>xxxxxxx ======= Add template PARAMS
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE) 
VALUES 
(1506, 'apy', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE, RESTRICT_DETAIL) 
VALUES 
(1506, 'cif', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'N', '10.0');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE, RESTRICT_DETAIL) 
VALUES 
(1506, 'date', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'D', 'MMMM dd, yyyy');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE) 
VALUES 
(1506, 'fname1', 102, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE, RESTRICT_DETAIL) 
VALUES 
(1506, 'odt', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'D', 'MM/dd/yyyy');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE) 
VALUES 
(1506, 'zeofund', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE) 
VALUES 
(1506, 'zeofacct', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S');
--
-- xxxxxxxx<<STEP003>>xxxxxxx ======= Marry template to email definition
--
INSERT INTO CSP.CORRES_GEN_TEMPLATE
(CORRES_GENERATOR_CODE, TEMPLATE_ID, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, EXTERNAL_REF) 
VALUES 
('E1', 1506, sysdate, sysdate, 'abrida', 'abrida', '1565');
--
-- xxxxxxxx<<STEP004>>xxxxxxx ======= Create Multipart Definition
--
INSERT INTO EMAIL_MULTIPART 
(EMAIL_MULTIPART_CODE, MIME_SUBTYPE, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY)
VALUES (1566, 'alternative',  sysdate,  sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP005>>xxxxxxx ======= Create email definition with Multipart definition
--
INSERT INTO EMAIL_DEF 
(EMAIL_DEF_CODE, EMAIL_MULTIPART_CODE, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY, DESCRIPTION, FROM_TXT, REPLY_ADDRESS,SUBJECT_TXT)
VALUES (1565, 1566,  sysdate,  sysdate, 'abrida', 'abrida', '10 Day Reminder to Accept T\&\C', 'ING DIRECT', 'sales@ingdirect.com', 'Reminder #1: Power Up Your New Electric Orange');
--
-- xxxxxxxx<<STEP006>>xxxxxxx ======= Add the EMPTY PARTS(plain, html) to be uploaded later
--
insert into csp.email_bodypart (email_bodypart_code,email_body_type_code,mime_type,mime_encoding,mime_disposition, body_txt,created_by,created_date,modified_by,modified_date)
values (1566, 17, 'text/plain; charset="iso-8859-1"', '7bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate);

insert into csp.email_bodypart (email_bodypart_code,email_body_type_code,mime_type,mime_encoding,mime_disposition,body_txt,created_by,created_date,modified_by,modified_date)
values (1567, 17, 'text/html;"', '8bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate);
--
-- xxxxxxxx<<STEP007>>xxxxxxx ======= Create Parts Definitions for the Multipart 
--
INSERT INTO EMAIL_MULTIPART_PART ( EMAIL_MULTIPART_PART_ID, EMAIL_MULTIPART_CODE, SORT_NUM,PART_MULTIPART_CODE, PART_BODYPART_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES (seq_email_multipart_part.nextval, 1566, 1, NULL, 1566, sysdate,  sysdate, 'abrida', 'abrida'); 
--
INSERT INTO EMAIL_MULTIPART_PART ( EMAIL_MULTIPART_PART_ID, EMAIL_MULTIPART_CODE, SORT_NUM,PART_MULTIPART_CODE, PART_BODYPART_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES (seq_email_multipart_part.nextval, 1566, 1, NULL, 1567, sysdate,  sysdate, 'abrida', 'abrida'); 
--
-- xxxxxxxx<<STEP008>>xxxxxxx ======= Update Notification ID with new Template
--
UPDATE csp.csp_ext_corres_type
     SET TEMPLATE_ID = 1506,
             MODIFIED_DATE = sysdate,
             MODIFIED_BY = 'abrida'
     WHERE
            EXT_SYSTEM_CODE = 1
        AND
           EXT_CORRES_TYPE_CODE = 6;      
--
-- =========================================<< 20DayTCReminder>>=========================================================
--
-- == ============================================================================
-- == ===  Name                         : CallCent20
-- == ===  Email Subject            : Reminder #2: Power Up Your New Electric Orange
-- == ===  Notification ID (nid) : 7 
-- ===== Template ID (tid)       : 507 to 1507
-- == === Email ID (eid)            : 570 to 1570
-- == === MULTIPART              : 571 to 1571   PART 571 to 1571, PART 572 to 1572
-- == ============================================================================
--
-- xxxxxxxx<<STEP001>>xxxxxxx ======= Create a NEW template and a template description 
--
INSERT INTO CSP.TEMPLATE
(TEMPLATE_ID, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, EMAIL_GEN_CODE, PACKAGE_SORT_NUM) 
VALUES 
(1507, sysdate, sysdate, 'abrida', 'abrida', 'E1', 0);
--
INSERT INTO CSP.TEMPLATE_DESC 
(TEMPLATE_ID, LOCALE_CODE, SHORT_DESC, DESCRIPTION, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1507, 'en-US', '20 Day T\&\C Reminder', '20 Day Reminder to Accept T\&\C', sysdate, sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP002>>xxxxxxx ======= Add template PARAMS
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE) 
VALUES 
(1507, 'apy', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE, RESTRICT_DETAIL) 
VALUES 
(1507, 'cif', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'N', '10.0');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE, RESTRICT_DETAIL) 
VALUES 
(1507, 'date', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'D', 'MMMM dd, yyyy');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE) 
VALUES 
(1507, 'fname1', 102, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE, RESTRICT_DETAIL) 
VALUES 
(1507, 'odt', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'D', 'MM/dd/yyyy');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE) 
VALUES 
(1507, 'zeofund', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE) 
VALUES 
(1507, 'zeofacct', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S');
--
-- xxxxxxxx<<STEP003>>xxxxxxx ======= Marry template to email definition
--
INSERT INTO CSP.CORRES_GEN_TEMPLATE
(CORRES_GENERATOR_CODE, TEMPLATE_ID, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, EXTERNAL_REF) 
VALUES 
('E1', 1507, sysdate, sysdate, 'abrida', 'abrida', '1570');
--
-- xxxxxxxx<<STEP004>>xxxxxxx ======= Create Multipart Definition
--
INSERT INTO EMAIL_MULTIPART 
(EMAIL_MULTIPART_CODE, MIME_SUBTYPE, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY)
VALUES (1571, 'alternative',  sysdate,  sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP005>>xxxxxxx ======= Create email definition with Multipart definition
--
INSERT INTO EMAIL_DEF 
(EMAIL_DEF_CODE, EMAIL_MULTIPART_CODE, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY, DESCRIPTION, FROM_TXT, REPLY_ADDRESS,SUBJECT_TXT)
VALUES (1570, 1571,  sysdate,  sysdate, 'abrida', 'abrida', '20 Day Reminder to Accept T\&\C', 'ING DIRECT', 'sales@ingdirect.com', 'Reminder #2: Power Up Your New Electric Orange');
--
-- xxxxxxxx<<STEP006>>xxxxxxx ======= Add the EMPTY PARTS(plain, html) to be uploaded later
--
insert into csp.email_bodypart (email_bodypart_code,email_body_type_code,mime_type,mime_encoding,mime_disposition, body_txt,created_by,created_date,modified_by,modified_date)
values (1571, 17, 'text/plain; charset="iso-8859-1"', '7bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate);

insert into csp.email_bodypart (email_bodypart_code,email_body_type_code,mime_type,mime_encoding,mime_disposition,body_txt,created_by,created_date,modified_by,modified_date)
values (1572, 17, 'text/html;"', '8bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate);
--
-- xxxxxxxx<<STEP007>>xxxxxxx ======= Create Parts Definitions for the Multipart 
--
INSERT INTO EMAIL_MULTIPART_PART ( EMAIL_MULTIPART_PART_ID, EMAIL_MULTIPART_CODE, SORT_NUM,PART_MULTIPART_CODE, PART_BODYPART_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES (seq_email_multipart_part.nextval, 1571, 1, NULL, 1571, sysdate,  sysdate, 'abrida', 'abrida'); 
--
INSERT INTO EMAIL_MULTIPART_PART ( EMAIL_MULTIPART_PART_ID, EMAIL_MULTIPART_CODE, SORT_NUM,PART_MULTIPART_CODE, PART_BODYPART_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES (seq_email_multipart_part.nextval, 1571, 1, NULL, 1572, sysdate,  sysdate, 'abrida', 'abrida'); 
--
-- xxxxxxxx<<STEP008>>xxxxxxx ======= Update Notification ID with new Template
--
UPDATE csp.csp_ext_corres_type
     SET TEMPLATE_ID = 1507,
             MODIFIED_DATE = sysdate,
             MODIFIED_BY = 'abrida'
     WHERE
            EXT_SYSTEM_CODE = 1
        AND
           EXT_CORRES_TYPE_CODE = 7; 
--
-- =========================================<< 30DayTCReminder >>=========================================================
--
-- == ============================================================================
-- == === File                            :  30DayTCReminderhtml.xsl
-- == ===  Name                         : CallCent30
-- == ===  Email Subject            : Last Chance to Power Up Your New Electric Orange
-- == ===  Notification ID (nid) : 8 
-- == === Template ID (tid)       : 508 to 1508
-- == === Email ID (eid)            : 575 to 1575
-- == === MULTIPART              : 576 to 1576   PART 576 to 1576, PART 577 to 1577
-- == ============================================================================
--
-- xxxxxxxx<<STEP001>>xxxxxxx ======= Create a NEW template and a template description 
--
INSERT INTO CSP.TEMPLATE
(TEMPLATE_ID, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, EMAIL_GEN_CODE, PACKAGE_SORT_NUM) 
VALUES 
(1508, sysdate, sysdate, 'abrida', 'abrida', 'E1', 0);
--
INSERT INTO CSP.TEMPLATE_DESC 
(TEMPLATE_ID, LOCALE_CODE, SHORT_DESC, DESCRIPTION, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1508, 'en-US', '30 Day T\&\C Reminder', '30 Day Reminder to Accept T\&\C', sysdate, sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP002>>xxxxxxx ======= Add template PARAMS
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE) 
VALUES 
(1508, 'apy', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE, RESTRICT_DETAIL) 
VALUES 
(1508, 'cif', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'N', '10.0');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE, RESTRICT_DETAIL) 
VALUES 
(1508, 'date', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'D', 'MMMM dd, yyyy');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE) 
VALUES 
(1508, 'fname1', 102, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE) 
VALUES 
(1508, 'zeofund', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE) 
VALUES 
(1508, 'zeofacct', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S');
--
-- xxxxxxxx<<STEP003>>xxxxxxx ======= Marry template to email definition 
--
INSERT INTO CSP.CORRES_GEN_TEMPLATE
(CORRES_GENERATOR_CODE, TEMPLATE_ID, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, EXTERNAL_REF) 
VALUES 
('E1', 1508, sysdate, sysdate, 'abrida', 'abrida', '1575');
--
-- xxxxxxxx<<STEP004>>xxxxxxx ======= Create Multipart Definition
--
INSERT INTO EMAIL_MULTIPART 
(EMAIL_MULTIPART_CODE, MIME_SUBTYPE, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY)
VALUES (1576, 'alternative',  sysdate,  sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP005>>xxxxxxx ======= Create email definition with Multipart definition
--
INSERT INTO EMAIL_DEF 
(EMAIL_DEF_CODE, EMAIL_MULTIPART_CODE, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY, DESCRIPTION, FROM_TXT, REPLY_ADDRESS,SUBJECT_TXT)
VALUES (1575, 1576,  sysdate,  sysdate, 'abrida', 'abrida', '30 Day Reminder to Accept T\&\C', 'ING DIRECT', 'sales@ingdirect.com', 'Reminder #3: Power Up Your New Electric Orange');
--
-- xxxxxxxx<<STEP006>>xxxxxxx ======= Add the EMPTY PARTS(plain, html) to be uploaded later
--
insert into csp.email_bodypart (email_bodypart_code,email_body_type_code,mime_type,mime_encoding,mime_disposition, body_txt,created_by,created_date,modified_by,modified_date)
values (1576, 17, 'text/plain; charset="iso-8859-1"', '7bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate);

insert into csp.email_bodypart (email_bodypart_code,email_body_type_code,mime_type,mime_encoding,mime_disposition,body_txt,created_by,created_date,modified_by,modified_date)
values (1577, 17, 'text/html;"', '8bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate);
--
-- xxxxxxxx<<STEP007>>xxxxxxx ======= Create Parts Definitions for the Multipart 
--
INSERT INTO EMAIL_MULTIPART_PART ( EMAIL_MULTIPART_PART_ID, EMAIL_MULTIPART_CODE, SORT_NUM,PART_MULTIPART_CODE, PART_BODYPART_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES (seq_email_multipart_part.nextval, 1576, 1, NULL, 1576, sysdate,  sysdate, 'abrida', 'abrida'); 
--
INSERT INTO EMAIL_MULTIPART_PART ( EMAIL_MULTIPART_PART_ID, EMAIL_MULTIPART_CODE, SORT_NUM,PART_MULTIPART_CODE, PART_BODYPART_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES (seq_email_multipart_part.nextval, 1576, 1, NULL, 1577, sysdate,  sysdate, 'abrida', 'abrida'); 
--
-- xxxxxxxx<<STEP008>>xxxxxxx ======= Update Notification ID with new Template
--
UPDATE csp.csp_ext_corres_type
     SET TEMPLATE_ID = 1508,
             MODIFIED_DATE = sysdate,
             MODIFIED_BY = 'abrida'
     WHERE
            EXT_SYSTEM_CODE = 1
        AND
           EXT_CORRES_TYPE_CODE = 8;      
--
-- =========================================<< InitialCall >>=========================================================
-- 
-- == ============================================================================
-- == === File                            :  InitialCalltext.xsl
-- == ===  Name                         :  Init_CallCent
-- == ===  Email Subject            :  Power Up Your New Electric Orange
-- == ===  Notification ID (nid) :  31
-- == === Template ID (tid)       : 532 to 1532
-- == === Email ID (eid)            : 670 to 1670
-- == === MULTIPART              : 671 to 1671   PARTS 671 to 1671, 672 to 1672
-- == ============================================================================
--
-- xxxxxxxx<<STEP001>>xxxxxxx ======= Create a NEW template and a template description 
--
INSERT INTO CSP.TEMPLATE
(TEMPLATE_ID, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, EMAIL_GEN_CODE, PACKAGE_SORT_NUM) 
VALUES 
(1532, sysdate, sysdate, 'abrida', 'abrida', 'E1', 0);
--
INSERT INTO CSP.TEMPLATE_DESC 
(TEMPLATE_ID, LOCALE_CODE, SHORT_DESC, DESCRIPTION, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1532, 'en-US', 'Initial Call', 'Initial Call', sysdate, sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP002>>xxxxxxx ======= Add template PARAMS
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE) 
VALUES 
(1532, 'apy', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE, RESTRICT_DETAIL) 
VALUES 
(1532, 'cif', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'N', '10.0');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE, RESTRICT_DETAIL) 
VALUES 
(1532, 'date', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'D', 'MMMM dd, yyyy');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE) 
VALUES 
(1532, 'fname1', 102, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE, RESTRICT_DETAIL) 
VALUES 
(1532, 'odt', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'D', 'MM/dd/yyyy');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE) 
VALUES 
(1532, 'zeofund', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S');

INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE) 
VALUES 
(1532, 'zeofacct', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S');
--
-- xxxxxxxx<<STEP003>>xxxxxxx ======= Marry template to email definition 
--
INSERT INTO CSP.CORRES_GEN_TEMPLATE
(CORRES_GENERATOR_CODE, TEMPLATE_ID, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, EXTERNAL_REF) 
VALUES 
('E1', 1532, sysdate, sysdate, 'abrida', 'abrida', '1670');
--
-- xxxxxxxx<<STEP004>>xxxxxxx ======= Create Multipart Definition
--
INSERT INTO EMAIL_MULTIPART 
(EMAIL_MULTIPART_CODE, MIME_SUBTYPE, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY)
VALUES (1671, 'alternative',  sysdate,  sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP005>>xxxxxxx ======= Create email definition with Multipart definition
--
INSERT INTO EMAIL_DEF 
(EMAIL_DEF_CODE, EMAIL_MULTIPART_CODE, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY, DESCRIPTION, FROM_TXT, REPLY_ADDRESS,SUBJECT_TXT)
VALUES (1670, 1671,  sysdate,  sysdate, 'abrida', 'abrida', 'Initial Call', 'ING DIRECT', 'sales@ingdirect.com', 'Power Up Your New Electric Orange');
--
-- xxxxxxxx<<STEP006>>xxxxxxx ======= Add the EMPTY PARTS(plain, html) to be uploaded later
--
insert into csp.email_bodypart (email_bodypart_code,email_body_type_code,mime_type,mime_encoding,mime_disposition, body_txt,created_by,created_date,modified_by,modified_date)
values (1671, 17, 'text/plain; charset="iso-8859-1"', '7bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate);

insert into csp.email_bodypart (email_bodypart_code,email_body_type_code,mime_type,mime_encoding,mime_disposition,body_txt,created_by,created_date,modified_by,modified_date)
values (1672, 17, 'text/html;"', '8bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate);
--
-- xxxxxxxx<<STEP007>>xxxxxxx ======= Create Parts Definitions for the Multipart 
--
INSERT INTO EMAIL_MULTIPART_PART ( EMAIL_MULTIPART_PART_ID, EMAIL_MULTIPART_CODE, SORT_NUM,PART_MULTIPART_CODE, PART_BODYPART_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES (seq_email_multipart_part.nextval, 1671, 1, NULL, 1671, sysdate,  sysdate, 'abrida', 'abrida'); 
--
INSERT INTO EMAIL_MULTIPART_PART ( EMAIL_MULTIPART_PART_ID, EMAIL_MULTIPART_CODE, SORT_NUM,PART_MULTIPART_CODE, PART_BODYPART_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES (seq_email_multipart_part.nextval, 1671, 1, NULL, 1672, sysdate,  sysdate, 'abrida', 'abrida'); 
--
-- xxxxxxxx<<STEP008>>xxxxxxx ======= Update Notification ID with new Template
--
UPDATE csp.csp_ext_corres_type
     SET TEMPLATE_ID = 1532,
             MODIFIED_DATE = sysdate,
             MODIFIED_BY = 'abrida'
     WHERE
            EXT_SYSTEM_CODE = 1
        AND
           EXT_CORRES_TYPE_CODE = 31;                       
--                
-- ================================================== COMMIT ========================================================
COMMIT;
-- ================================================== EOF =============================================================