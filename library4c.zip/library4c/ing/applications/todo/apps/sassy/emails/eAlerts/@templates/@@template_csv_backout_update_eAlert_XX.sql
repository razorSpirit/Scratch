--
-- ==  ======================== BACKOUT =======================================
--
-- == ===MULTIPART_CODE            : {$mpCode}
-- == ===BODY PART                 : {$bodypart1},{$bodypart2}
--
--
-- backout eAlert {$nid}
--
DELETE FROM EMAIL_MULTIPART_PART
   WHERE  
      EMAIL_MULTIPART_CODE = {$mpCode}
   AND
     PART_BODYPART_CODE in ({$bodypart1},{$bodypart2});
--
DELETE FROM EMAIL_BODYPART
   WHERE  
      EMAIL_BODY_TYPE_CODE = 17
   AND
     EMAIL_BODYPART_CODE in ({$bodypart1},{$bodypart2});
--
-- ==============>>>> IF ADDING NEW EALERT
--
DELETE FROM CSP.CSP_EXT_CORRES_TYPE
   WHERE EXT_CORRES_TYPE_CODE = {$nid};

--                
-- ================================================== COMMIT ========================================================
--
COMMIT;
-- ================================================== EOF =============================================================
