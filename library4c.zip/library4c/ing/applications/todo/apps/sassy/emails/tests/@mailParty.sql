Edits
   change @@email@@ to an email address eg   c /@@mail@@/csmack@ingqa.com

----------------------- REMOVE THIS LINE AND ALL THE LINES ABOVE IT ----------------------------
--      
-- ===========================================================================================
-- =================================== Add Party for mail ====================================
-- ===========================================================================================
--
INSERT INTO CST.PARTY
     (party_id, party_type_code, deleted_ind, tax_id_type_code, tax_id_crypt_code, tax_id, 
      cust_since_date, alert_note_id, vip_code,
       created_date, modified_date, created_by, modified_by
      )
VALUES
      ('9999991234', 'I', 'N', 'S', 1, 209129999,
        to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'),NULL, NULL,
        to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'),  to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'), 'abrida', 'abrida'        
      ); 
--      
-- ===========================================================================================
-- =================================== Contact Information ===================================
-- ===========================================================================================
--
INSERT INTO CST.CONTACT_EADDRESS
     ( contact_eaddress_id, eaddress_type_code, eaddress, eaddress_idx,
       created_date, modified_date, created_by, modified_by     
      )
VALUES
     (9999999901, 'M', '@@email@@', '@@email@@',
       to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'),  to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'), 'abrida', 'abrida'
     );     
--
INSERT INTO CST.CONTACT
     (contact_id, contact_phone_id, contact_postal_id, contact_eaddress_id, 
      created_date, modified_date, created_by, modified_by 
      )
VALUES
     (9999999901, NULL, NULL, 9999999901,
       to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'),  to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'), 'abrida', 'abrida'
     );     
--
INSERT INTO CST.PARTY_CONTACT
     (party_contact_id, party_id, contact_id, relation_code, contact_status_code, 
      valid_from_date, inbound_use_count, last_inbound_use_date, valid_to_date, 
      contact_verification_code, contact_verification_date, authorizing_party_id, 
      contact_verification_sent_date,
      created_date, modified_date, created_by, modified_by       
      )
VALUES
     (9999999901, '9999991234', 9999999901, 'H', 'A',
      to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'), NULL, NULL, NULL,
      12, to_date('2007/02/02:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'), NULL, 
      to_date('2007/02/02:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'),
      to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'),  to_date('2506/07/31:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'), 'abrida', 'abrida'
     );
--      
-- ===========================================================================================
-- ====================================== COMMIT =============================================
-- ===========================================================================================
--
commit;
--