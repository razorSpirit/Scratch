-- ==
-- ============================================================================
-- == ===File                      : OvernightCheckSenthtml.xsl
-- == ===Name                      : Exp_Check_Sent
-- == ===Description               : Expedited Check Sent over night
-- == ===Notification ID (nid)     : 4 
-- ============================================================================
-- ==          ---------- CHANGES -----------
-- ==                       ealert :  {$nid}
-- ==                         desc :  {$desc}
-- ==                      subject :  {$subject}
-- == ===Template ID (tid)         : 504 TO {$tid}
-- == ===Email ID (eid)            : 555 TO {$eid}
-- == ===MULTIPART_CODE            : 556  TO {$mpCode}
-- == ===BODY PART                 : 556,557 TO {$bodypart1},{$bodypart2}
-- ============================================================================
-- {$fromtid} {$nid} {$tid} {$eid} {$mpCode} {$bodypart1} {$bodypart2}
--
-- 8
UPDATE csp.csp_ext_corres_type
     SET TEMPLATE_ID = {$fromtid},
             MODIFIED_DATE = sysdate,
             MODIFIED_BY = 'abrida'
     WHERE
            EXT_SYSTEM_CODE = 1
        AND
           EXT_CORRES_TYPE_CODE = {$nid};      
--
-- 7
DELETE FROM EMAIL_MULTIPART_PART
   WHERE  
      EMAIL_MULTIPART_CODE = {$mpCode}
   AND
     PART_BODYPART_CODE in ({$bodypart1}, {$bodypart2});
--
-- 6
DELETE FROM csp.email_bodypart
   WHERE  
      email_body_type_code = 17
   AND
     email_bodypart_code in ({$bodypart1}, {$bodypart2});
--
-- 5
DELETE FROM EMAIL_DEF
   WHERE  
      EMAIL_DEF_CODE = {$eid}
   AND
     EMAIL_MULTIPART_CODE = {$mpCode};
--
-- 4
DELETE FROM EMAIL_MULTIPART
   WHERE  
     EMAIL_MULTIPART_CODE = {$mpCode};
--
-- 3
DELETE FROM CSP.CORRES_GEN_TEMPLATE
   WHERE  
     TEMPLATE_ID = {$tid}
   AND
     EXTERNAL_REF = '{$eid}';
--
-- 2
DELETE FROM CSP.TEMPLATE_PARAM 
   WHERE  
      TEMPLATE_ID = {$tid};
--
-- 1
DELETE FROM CSP.TEMPLATE_DESC 
   WHERE  
      TEMPLATE_ID = {$tid};
--
DELETE FROM  CSP.TEMPLATE 
   WHERE  
      TEMPLATE_ID = {$tid};
--
-- 0
update or delete
*** or DELETE
DELETE FROM CSP.CSP_EXT_CORRES_TYPE
    WHERE 
       TEMPLATE_ID = {$tid};
      
--                
-- ================================================== COMMIT ========================================================
--
COMMIT;
-- ================================================== EOF =============================================================
