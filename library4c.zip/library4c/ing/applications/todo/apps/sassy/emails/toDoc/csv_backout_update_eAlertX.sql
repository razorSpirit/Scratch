-- ==  ======================== BACKOUT =======================================
-- ============================================================================
-- == ===File                      : eAlert_01_H.xsl
-- ============================================================================
-- ==          ---------- CHANGES -----------
-- ==                       ealert :  {$nid}
-- ==                         desc :  {$desc}
-- ==                   short desc :  {$shortDesc}
-- ==                      subject :  {$subject}
-- == ===Template ID (tid)         : 504 TO {$tid}
-- == ===Email ID (eid)            : 555 TO {$eid}
-- == ===MULTIPART_CODE            : 556  TO {$mpCode}
-- == ===BODY PART                 : 556,557 TO {$bodypart1},{$bodypart2}
-- ============================================================================
-- {$fromtid} {$nid} {$tid} {$eid} {$mpCode} {$bodypart1} {$bodypart2}
--
-- 7
DELETE FROM EMAIL_MULTIPART_PART
   WHERE  
      EMAIL_MULTIPART_CODE = {$mpCode}
   AND
     PART_BODYPART_CODE in ({$bodypart1}, {$bodypart2});
--
-- 6
DELETE FROM csp.email_bodypart
   WHERE  
      email_body_type_code = 17
   AND
     email_bodypart_code in ({$bodypart1}, {$bodypart2});
--                
-- ================================================== COMMIT ========================================================
--
COMMIT;
-- ================================================== EOF =============================================================
