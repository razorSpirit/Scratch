Document

How to do eAlerts using CSV.

Note how order is changed by notify DBA in note section.