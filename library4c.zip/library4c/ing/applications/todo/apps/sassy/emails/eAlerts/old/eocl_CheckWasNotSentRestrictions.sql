--
-- =========================================<< CheckWasNotSentRestrictionshtml.xsl >>=========================================================
--
-- ============================================================================
-- ===  Email Subject               :  Notification That Check Was Not Sent
-- ===  Notification ID (nid)    :  34
-- ===  Template ID (tid)         : 519
-- ===  Email ID (eid)              : 600
-- === MULTIPART                 : 605   PARTS 606,607
-- ===
-- ===  Because of Restriction
-- ============================================================================
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP001>>xxxxxxx =======Create a Multipart definition 
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
INSERT INTO CSP.EMAIL_MULTIPART ( EMAIL_MULTIPART_CODE, MIME_SUBTYPE, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY )
VALUES (605, 'alternative',  sysdate,  sysdate, 'abrida', 'abrida');
Commit;
/
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP002>>xxxxxxx =======Create 2 Parts for TEXT and HTML MAILINGS and MARRY each to the EMAIL_MULTIPART table.
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--
-- ......<<STEP002A>>===== CREATE PART WITH PART_ID 606 for TEXT
INSERT INTO CSP.EMAIL_MULTIPART_PART ( EMAIL_MULTIPART_PART_ID, EMAIL_MULTIPART_CODE, SORT_NUM,PART_MULTIPART_CODE, PART_BODYPART_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES (seq_email_multipart_part.nextval, 605, 1, NULL, 606,  sysdate,  sysdate, 'abrida', 'abrida'); 
--
-- ......<<STEP002B>>===== CREATE PART WITH PART_ID 607 for HTML
INSERT INTO CSP.EMAIL_MULTIPART_PART ( EMAIL_MULTIPART_PART_ID, EMAIL_MULTIPART_CODE, SORT_NUM,PART_MULTIPART_CODE, PART_BODYPART_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES (seq_email_multipart_part.nextval, 605, 1, NULL, 607,  sysdate,  sysdate, 'abrida', 'abrida'); 
Commit;
/
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP003>>xxxxxxx =======Create the body part for each part using the respective EMAIL_MULTIPART_PART_ID's
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--
create or replace directory EMAIL_UPLOAD as '/home/oracle/temp/email';
--
-- ......<<STEP002A>>===== CREATE BODY PART WITH PART_ID 606 (TEXT BODY PART)
declare bodyLocator clob; fileLocator bfile; begin
insert into csp.email_bodypart (email_bodypart_code,email_body_type_code,mime_type,mime_encoding,mime_disposition, body_txt,created_by,created_date,modified_by,modified_date)
values (606, 17, 'text/plain; charset="iso-8859-1"', '7bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate)
returning body_txt into bodyLocator;
-- 
fileLocator := bfilename('EMAIL_UPLOAD', 'CheckWasNotSentRestrictionstext.xsl');
dbms_lob.fileOpen(fileLocator);
dbms_lob.loadFromFile(bodyLocator, fileLocator, dbms_lob.getLength(fileLocator));
dbms_lob.fileClose(fileLocator);
commit;
end;
/
--
-- ......<<STEP002B>>===== CREATE BODY PART WITH PART_ID 607 (HTML BODY PART)
declare bodyLocator clob; fileLocator bfile; begin
insert into csp.email_bodypart (email_bodypart_code,email_body_type_code,mime_type,mime_encoding,mime_disposition,body_txt,created_by,created_date,modified_by,modified_date)
values (607, 17, 'text/html;"', '8bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate)
returning body_txt into bodyLocator;
-- 
fileLocator := bfilename('EMAIL_UPLOAD', 'CheckWasNotSentRestrictionshtml.xsl');
dbms_lob.fileOpen(fileLocator);
dbms_lob.loadFromFile(bodyLocator, fileLocator, dbms_lob.getLength(fileLocator));
dbms_lob.fileClose(fileLocator);
commit;
end;
/
--
drop directory email_upload;
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP004>>xxxxxxx =======Create an email definition and MARRY it to the EMAIL_MULTIPART table.
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--  
INSERT INTO CSP.EMAIL_DEF ( EMAIL_DEF_CODE, EMAIL_MULTIPART_CODE, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY, DESCRIPTION, FROM_TXT, REPLY_ADDRESS,SUBJECT_TXT )
VALUES (600, 605,  sysdate,  sysdate, 'abrida', 'abrida', 'Notification That Check Was Not Sent', 'ING DIRECT', 'sales@ingdirect.com', 'Notification That Check Was Not Sent');
Commit;
/
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP005>>xxxxxxx ======= Create a template and a template description 
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
INSERT INTO CSP.TEMPLATE
(TEMPLATE_ID, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, EMAIL_GEN_CODE, PACKAGE_SORT_NUM) 
VALUES 
(519, sysdate, sysdate, 'abrida', 'abrida', 'E1', 0);
--
INSERT INTO CSP.TEMPLATE_DESC 
(TEMPLATE_ID, LOCALE_CODE, SHORT_DESC, DESCRIPTION, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(519, 'en-US', 'Check Was Not Sent', 'Notification That Check Was Not Sent', sysdate, sysdate, 'abrida', 'abrida');
Commit;
/
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP006>>xxxxxxx ======= Create template PARAMS
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE, RESTRICT_DETAIL) 
VALUES 
(519, 'cif', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'N', '10.0');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE) 
VALUES 
(519, 'fname1', 102, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE) 
VALUES 
(519, 'amt', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, RESTRICT_CODE) 
VALUES 
(519, 'payname', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S');
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP007>>xxxxxxx ======= Marry email definition to template definition
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--
INSERT INTO CSP.CORRES_GEN_TEMPLATE
(CORRES_GENERATOR_CODE, TEMPLATE_ID, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, EXTERNAL_REF) 
VALUES 
('E1', 519, sysdate, sysdate, 'abrida', 'abrida', '600');
--
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
-- xxxxxxxx<<STEP008>>xxxxxxx ======= Marry notification ID from Profile to template definition
-- xxxxxxxxxxxxxxxxxxxxxxxxxx
--
INSERT INTO CSP.CSP_EXT_CORRES_TYPE
(EXT_SYSTEM_CODE, EXT_CORRES_TYPE_CODE, TEMPLATE_ID, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1, 34, 519, sysdate, sysdate, 'abrida', 'abrida');
--
COMMIT;
/
--