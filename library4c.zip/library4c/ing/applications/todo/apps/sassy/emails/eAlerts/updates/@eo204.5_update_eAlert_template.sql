-- ==
-- ============================================================================
-- == ===Notification ID (nid)     : 4 
-- ============================================================================
-- ==          ---------- CHANGES -----------
-- ==                       ealert :  {$nid}
-- ==                         desc :  {$desc}
-- ==                      subject :  {$subject}
-- == ===Template ID (tid)         : 504 TO {$tid}
-- == ===Email ID (eid)            : 555 TO {$eid}
-- == ===MULTIPART_CODE            : 556  TO {$mpCode}
-- == ===BODY PART                 : 556,557 TO {$bodypart1},{$bodypart2}
--
-- == NEW PARAMS {paramCode}, {paramDesc}
-- ============================================================================
--
-- xxxxxxxx<<STEP001>>xxxxxxx ======= Create a NEW template and a template description 
--
INSERT INTO CSP.TEMPLATE
(TEMPLATE_ID, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, EMAIL_GEN_CODE, PACKAGE_SORT_NUM) 
VALUES 
({$tid}, sysdate, sysdate, 'abrida', 'abrida', 'E1', 0);
--
INSERT INTO CSP.TEMPLATE_DESC 
(TEMPLATE_ID, LOCALE_CODE, SHORT_DESC, DESCRIPTION, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
({$tid}, 'en-US', '{$desc}', '{$desc}', sysdate, sysdate, 'abrida', 'abrida');
--
-- ****************** NEW PARAM ONLY *********************
--
INSERT INTO CSP.TEMPLATE_PARAM_DESC (PARAM_CODE, LOCALE_CODE, DESCRIPTION, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
('{paramCode}', 'en-US', '{paramDesc}', sysdate, sysdate, 'abrida', 'abrida');

--
-- xxxxxxxx<<STEP002>>xxxxxxx ======= Add template PARAMS
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
({$tid}, 'amt', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
({$tid}, 'cif', 0, 'Y', 'Y', 'N', '10.0', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
({$tid}, 'efd', 0, 'Y', 'Y', 'D', 'MMMM dd, yyyy', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
({$tid}, 'fname1', 102, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
({$tid}, 'payname', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP003>>xxxxxxx ======= Marry template to email definition
--
INSERT INTO CSP.CORRES_GEN_TEMPLATE
(TEMPLATE_ID, EXTERNAL_REF, CORRES_GENERATOR_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
({$tid}, '{$eid}', 'E1', sysdate, sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP004>>xxxxxxx ======= Create Multipart Definition
--
INSERT INTO EMAIL_MULTIPART 
(EMAIL_MULTIPART_CODE, MIME_SUBTYPE, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY)
VALUES ({$mpCode}, 'alternative',  sysdate,  sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP005>>xxxxxxx ======= Create email definition with Multipart definition
--
INSERT INTO EMAIL_DEF 
(EMAIL_DEF_CODE, EMAIL_MULTIPART_CODE, DESCRIPTION, FROM_TXT, SUBJECT_TXT, REPLY_ADDRESS, SENDER_ADDRESS, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY)
VALUES ({$eid}, {$mpCode},  '{$desc}', 'ING DIRECT', '{$subject}', 'sales@ingdirect.com', '', sysdate,  sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP006>>xxxxxxx ======= Add the EMPTY PARTS(plain, html) to be uploaded later
--
insert into csp.email_bodypart (email_bodypart_code, email_body_type_code,mime_type,mime_encoding,mime_disposition, body_txt,created_by,created_date,modified_by,modified_date)
values ({$bodypart1}, 17, 'text/plain; charset="iso-8859-1"', '7bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate);

insert into csp.email_bodypart (email_bodypart_code,email_body_type_code,mime_type,mime_encoding,mime_disposition,body_txt,created_by,created_date,modified_by,modified_date)
values ({$bodypart2}, 17, 'text/html;"', '8bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate);
--
-- xxxxxxxx<<STEP007>>xxxxxxx ======= Create Parts Definitions for the Multipart 
--
  
INSERT INTO EMAIL_MULTIPART_PART (EMAIL_MULTIPART_CODE, PART_BODYPART_CODE, PART_MULTIPART_CODE, EMAIL_MULTIPART_PART_ID, SORT_NUM,  CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES ({$mpCode}, {$bodypart1},  NULL,  seq_email_multipart_part.nextval, 1, sysdate,  sysdate, 'abrida', 'abrida'); 
--
INSERT INTO EMAIL_MULTIPART_PART (EMAIL_MULTIPART_CODE, PART_BODYPART_CODE, PART_MULTIPART_CODE, EMAIL_MULTIPART_PART_ID, SORT_NUM,  CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES ({$mpCode}, {$bodypart2},  NULL,  seq_email_multipart_part.nextval, 1, sysdate,  sysdate, 'abrida', 'abrida'); 

--
-- xxxxxxxx<<STEP008>>xxxxxxx ======= Update Notification ID with new Template
--
UPDATE csp.csp_ext_corres_type
     SET TEMPLATE_ID = {$tid},
             MODIFIED_DATE = sysdate,
             MODIFIED_BY = 'abrida'
     WHERE
            EXT_SYSTEM_CODE = 1
        AND
           EXT_CORRES_TYPE_CODE = {$nid};      

--                
-- ================================================== COMMIT ========================================================
--
COMMIT;
-- ================================================== EOF =============================================================

-- ===============================================================================================================               
-- ================================================== CSV ========================================================
-- ===============================================================================================================               
--
-- xxxxxxxx<<STEP001>>xxxxxxx ======= Create a NEW template and a template description 
--
>>>>>>add to \WESP\Source\SQL\static_data\csp\csp-template.csv
{$tid},$NULL,$NULL,E1,0

>>>>>>add to \WESP\Source\SQL\static_data\csp\csp-template_desc.csv
{$tid},en-US,{$shortDesc},{$desc}

--
-- ****************** NEW PARAM ONLY *********************
--  CSP.TEMPLATE_PARAM_DESC 
INSERT INTO CSP.TEMPLATE_PARAM_DESC (PARAM_CODE, LOCALE_CODE, DESCRIPTION, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
{paramCode},en-US,{paramDesc}

--
-- xxxxxxxx<<STEP002>>xxxxxxx ======= Add template PARAMS
--

>>>>>>add to \WESP\Source\SQL\static_data\csp\csp-template_param.csv
3507,apy,0,Y,Y,S ,$NULL
3507,cif,0,Y,Y,N ,10
3507,date,0,Y,Y,D ,"MMMM dd, yyyy"
3507,fname1,102,Y,Y,S ,$NULL
3507,odt,0,Y,Y,D ,MM/dd/yyyy
3507,zeoacct,102,Y,Y,S ,$NULL
3507,zeofund,102,Y,Y,S ,$NULL

--
-- xxxxxxxx<<STEP003>>xxxxxxx ======= Marry template to email definition
--

>>>>>>add to \WESP\Source\SQL\static_data\csp\csp-corres_gen_template.csv
E1,{$tid},{$eid} 

--
-- xxxxxxxx<<STEP004>>xxxxxxx ======= Create Multipart Definition
--

>>>>>>add to \WESP\Source\SQL\static_data\csp\csp-email_multipart.csv
{$mpCode},alternative

--
-- xxxxxxxx<<STEP005>>xxxxxxx ======= Create email definition with Multipart definition
--


>>>>>>add to \WESP\Source\SQL\static_data\csp\csp-email_def.csv
{$eid},{$mpCode},{$desc},ING DIRECT,sales@ingdirect.com,{$subject}

--
-- xxxxxxxx<<STEP006>>xxxxxxx ======= Add the EMPTY PARTS(plain, html) to be uploaded later
--
insert into csp.email_bodypart (email_bodypart_code, email_body_type_code,mime_type,mime_encoding,mime_disposition, body_txt,created_by,created_date,modified_by,modified_date)
values ({$bodypart1}, 17, 'text/plain; charset="iso-8859-1"', '7bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate);

insert into csp.email_bodypart (email_bodypart_code,email_body_type_code,mime_type,mime_encoding,mime_disposition,body_txt,created_by,created_date,modified_by,modified_date)
values ({$bodypart2}, 17, 'text/html;"', '8bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate);
--
-- xxxxxxxx<<STEP007>>xxxxxxx ======= Create Parts Definitions for the Multipart 
--
INSERT INTO EMAIL_MULTIPART_PART (EMAIL_MULTIPART_CODE, PART_BODYPART_CODE, PART_MULTIPART_CODE, EMAIL_MULTIPART_PART_ID, SORT_NUM,  CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES ({$mpCode}, {$bodypart1},  NULL,  seq_email_multipart_part.nextval, 1, sysdate,  sysdate, 'abrida', 'abrida'); 
--
INSERT INTO EMAIL_MULTIPART_PART (EMAIL_MULTIPART_CODE, PART_BODYPART_CODE, PART_MULTIPART_CODE, EMAIL_MULTIPART_PART_ID, SORT_NUM,  CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES ({$mpCode}, {$bodypart2},  NULL,  seq_email_multipart_part.nextval, 1, sysdate,  sysdate, 'abrida', 'abrida'); 
--
-- xxxxxxxx<<STEP008>>xxxxxxx ======= Update Notification ID with new Template
--
>>>>>>add or change to \WESP\Source\SQL\static_data\csp\csp-csp_ext_corres_type.csv
1,{$nid},{$tid}
--
-- xxxxxxxx<<STEP009>>xxxxxxx ======= 
-- *** From the WESP Directory ****
CreateDBDeployZip oldTag local [svnuid svnpwd]