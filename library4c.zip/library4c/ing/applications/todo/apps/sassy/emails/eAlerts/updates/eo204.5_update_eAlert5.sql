-- ==
-- ============================================================================
-- == ===File                      : RegularCheckSenthtml.xsl
-- == ===Name                      : Reg_Check_Sent
-- == ===Description               : Regular check sent
-- == ===Notification ID (nid)     : 5 
-- ============================================================================
-- ==          ---------- CHANGES -----------
-- ==                       ealert :  5
-- == ===Template ID (tid)         : 505 TO 1505
-- == ===Email ID (eid)            : 560 TO 1560
-- == ===MULTIPART_CODE            : 561  TO 1561
-- == ===BODY PART                 : 561,562 TO 1561,1562
-- ============================================================================
--
-- xxxxxxxx<<STEP001>>xxxxxxx ======= Create a NEW template and a template description 
--
INSERT INTO CSP.TEMPLATE
(TEMPLATE_ID, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, EMAIL_GEN_CODE, PACKAGE_SORT_NUM) 
VALUES 
(1505, sysdate, sysdate, 'abrida', 'abrida', 'E1', 0);
--
INSERT INTO CSP.TEMPLATE_DESC 
(TEMPLATE_ID, LOCALE_CODE, SHORT_DESC, DESCRIPTION, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1505, 'en-US', 'Regular check sent', 'Regular check sent', sysdate, sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP002>>xxxxxxx ======= Add template PARAMS
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1505, 'amt', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1505, 'cif', 0, 'Y', 'Y', 'N', '10.0', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1505, 'efd', 0, 'Y', 'Y', 'D', 'MM/dd/yyyy', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1505, 'fname1', 102, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1505, 'payname', 0, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP003>>xxxxxxx ======= Marry template to email definition
--
INSERT INTO CSP.CORRES_GEN_TEMPLATE
(TEMPLATE_ID, EXTERNAL_REF, CORRES_GENERATOR_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1505, '1560', 'E1', sysdate, sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP004>>xxxxxxx ======= Create Multipart Definition
--
INSERT INTO EMAIL_MULTIPART 
(EMAIL_MULTIPART_CODE, MIME_SUBTYPE, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY)
VALUES (1561, 'alternative',  sysdate,  sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP005>>xxxxxxx ======= Create email definition with Multipart definition
--
INSERT INTO EMAIL_DEF 
(EMAIL_DEF_CODE, EMAIL_MULTIPART_CODE, DESCRIPTION, FROM_TXT, SUBJECT_TXT, REPLY_ADDRESS, SENDER_ADDRESS, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY)
VALUES (1560, 1561,  'Regular check sent', 'ING DIRECT', 'Check to {payname} Has Been Sent', 'sales@ingdirect.com', '', sysdate,  sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP006>>xxxxxxx ======= Add the EMPTY PARTS(plain, html) to be uploaded later
--
insert into csp.email_bodypart (email_bodypart_code, email_body_type_code,mime_type,mime_encoding,mime_disposition, body_txt,created_by,created_date,modified_by,modified_date)
values (1561, 17, 'text/plain; charset="iso-8859-1"', '7bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate);

insert into csp.email_bodypart (email_bodypart_code,email_body_type_code,mime_type,mime_encoding,mime_disposition,body_txt,created_by,created_date,modified_by,modified_date)
values (1562, 17, 'text/html;"', '8bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate);
--
-- xxxxxxxx<<STEP007>>xxxxxxx ======= Create Parts Definitions for the Multipart 
--
  
INSERT INTO EMAIL_MULTIPART_PART (EMAIL_MULTIPART_CODE, PART_BODYPART_CODE, PART_MULTIPART_CODE, EMAIL_MULTIPART_PART_ID, SORT_NUM,  CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES (1561, 1561,  NULL,  seq_email_multipart_part.nextval, 1, sysdate,  sysdate, 'abrida', 'abrida'); 
--
INSERT INTO EMAIL_MULTIPART_PART (EMAIL_MULTIPART_CODE, PART_BODYPART_CODE, PART_MULTIPART_CODE, EMAIL_MULTIPART_PART_ID, SORT_NUM,  CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES (1561, 1562,  NULL,  seq_email_multipart_part.nextval, 1, sysdate,  sysdate, 'abrida', 'abrida'); 

--
-- xxxxxxxx<<STEP008>>xxxxxxx ======= Update Notification ID with new Template
--
UPDATE csp.csp_ext_corres_type
     SET TEMPLATE_ID = 1505,
             MODIFIED_DATE = sysdate,
             MODIFIED_BY = 'abrida'
     WHERE
            EXT_SYSTEM_CODE = 1
        AND
           EXT_CORRES_TYPE_CODE = 5;      

--                
-- ================================================== COMMIT ========================================================
--
COMMIT;
-- ================================================== EOF =============================================================