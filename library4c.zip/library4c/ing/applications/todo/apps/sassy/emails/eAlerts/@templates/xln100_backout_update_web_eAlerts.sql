-- ========================================================================================
-- ==                                  Backout eAlerts                                   ==
-- ========================================================================================
--
-- backout eAlert 10032
--
DELETE FROM EMAIL_MULTIPART_PART
   WHERE  
      EMAIL_MULTIPART_CODE = 91032
   AND
     PART_BODYPART_CODE in (91032,91033);
--
DELETE FROM EMAIL_BODYPART
   WHERE  
      EMAIL_BODY_TYPE_CODE = 17
   AND
     EMAIL_BODYPART_CODE in (91032,91033);
--
DELETE FROM EMAIL_DEF
   WHERE  
      EMAIL_DEF_CODE = 91032
   AND
     EMAIL_MULTIPART_CODE = 91032;
--
DELETE FROM EMAIL_MULTIPART
   WHERE  
     EMAIL_MULTIPART_CODE = 91032;
--
DELETE FROM CORRES_GEN_TEMPLATE
   WHERE  
     TEMPLATE_ID = 10032;
--
DELETE FROM TEMPLATE_PARAM
   WHERE  
     TEMPLATE_ID = 10032;
--
DELETE FROM TEMPLATE_PARAM_DESC
   WHERE  
     PARAM_CODE IN ('decline1', 'decline2', 'decline3', 'fullname');
--
DELETE FROM TEMPLATE_DESC
   WHERE  
     TEMPLATE_ID = 10032;
--
DELETE FROM TEMPLATE
   WHERE  
     TEMPLATE_ID = 10032;
--                
-- ================================================== COMMIT ========================================================
--
COMMIT;
-- ================================================== EOF =============================================================
