-- Create template
-- 
-- TID : 98037 
-- DOCID : 0000000615
-- DESC : Kid is removed from KSA � for kid
-- EALERT: 84
--
-- Template ID is select max(template_id)+1 from CSP.TEMPLATE;
INSERT INTO CSP.TEMPLATE
VALUES (98037, sysdate, sysdate, 'abrida', 'abrida', null, null, 'E2', 0);

INSERT INTO CSP.TEMPLATE_DESC
VALUES (98037, 'en-US', 'Kid is removed from KSA � for kid', 'Kid is removed from KSA � for kid', 'abrida', sysdate, 'abrida', sysdate);

-- Map template to email definition
-- Corres_Generator_Code, E1 for OBM, E2 for EAlerts
-- EXTERNAL_REF is the Doc ID
INSERT INTO CSP.CORRES_GEN_TEMPLATE
VALUES ('E2', 98037, sysdate, sysdate, 'abrida', 'abrida', '0000000615');

-- New Parameters
INSERT INTO CSP.TEMPLATE_PARAM_DESC (PARAM_CODE, LOCALE_CODE, DESCRIPTION, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
('afname', 'en-US', 'Adult first name', sysdate, sysdate, 'abrida', 'abrida');
INSERT INTO CSP.TEMPLATE_PARAM_DESC (PARAM_CODE, LOCALE_CODE, DESCRIPTION, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
('alname', 'en-US', 'Adult last name', sysdate, sysdate, 'abrida', 'abrida');

--  *** VARIABLE *** Map parameters to template
INSERT INTO CSP.TEMPLATE_PARAM
VALUES (98037, 'fname', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S', null);
INSERT INTO CSP.TEMPLATE_PARAM
VALUES (98037, 'afname', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S', null);
INSERT INTO CSP.TEMPLATE_PARAM
VALUES (98037, 'alname', 0, 'Y', 'Y', sysdate, sysdate, 'abrida', 'abrida', 'S', null);


-- EXT_SYSTEM_CODE 1 for Profile
-- EXT_CORRES_TYPE_CODE is the Code Profile uses for this email
INSERT INTO CSP.CSP_EXT_CORRES_TYPE
VALUES (1, 84, 98037, sysdate, sysdate, 'abrida', 'abrida');

COMMIT;
