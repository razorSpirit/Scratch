-- Backout EALERT
-- 
-- TID : 98037 
-- EALERT: 84
--
DELETE FROM CSP.CSP_EXT_CORRES_TYPE
  WHERE EXT_SYSTEM_CODE = 1 AND
        EXT_CORRES_TYPE_CODE = 84;    
--
DELETE FROM CSP.TEMPLATE_PARAM
   WHERE  
     TEMPLATE_ID = 98037;
--     
-- ==== NEW PARAMS ONLY
--
DELETE FROM CSP.TEMPLATE_PARAM_DESC
   WHERE  
     PARAM_CODE in ( 'afname', 'alname');     
--
DELETE FROM CSP.CORRES_GEN_TEMPLATE
   WHERE  
     TEMPLATE_ID = 98037;
--
DELETE FROM CSP.TEMPLATE_DESC
   WHERE  
     TEMPLATE_ID = 98037;          
--
DELETE FROM CSP.TEMPLATE
   WHERE  
     TEMPLATE_ID = 98037;
--
COMMIT;
-- ================================================== EOF =============================================================
