-- ==
-- ============================================================================
-- == ===File                      : EOOODDepositOnlyhtml.xsl
-- == ===Name                      : EO_DepOnly
-- == ===Description               : Exceeded credit limit on Overdraft Line - make deposit
-- == ===Notification ID (nid)     : 16
-- ============================================================================
-- ==          ---------- CHANGES -----------
-- ==                       ealert :  16
-- ==                         desc :  Exceeded credit limit on Overdraft Line - make deposit
-- ==                      subject :  Please Make A Deposit to Your Electric Orange
-- == ===Template ID (tid)         : 516 TO 1516
-- == ===Email ID (eid)            : 655 TO 1655
-- == ===MULTIPART_CODE            : 656  TO 1656
-- == ===BODY PART                 : 656,657 TO 1656,1657
-- ============================================================================
--
-- xxxxxxxx<<STEP001>>xxxxxxx ======= Create a NEW template and a template description 
--
INSERT INTO CSP.TEMPLATE
(TEMPLATE_ID, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY, EMAIL_GEN_CODE, PACKAGE_SORT_NUM) 
VALUES 
(1516, sysdate, sysdate, 'abrida', 'abrida', 'E1', 0);
--
INSERT INTO CSP.TEMPLATE_DESC 
(TEMPLATE_ID, LOCALE_CODE, SHORT_DESC, DESCRIPTION, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1516, 'en-US', 'Exceeded credit limit on Overdraft Line - make deposit', 'Exceeded credit limit on Overdraft Line - make deposit', sysdate, sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP002>>xxxxxxx ======= Add template PARAMS
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1516, 'cif', 0, 'Y', 'Y', 'N', '10.0', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1516, 'dist1nd', 102, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1516, 'fname1', 102, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
INSERT INTO CSP.TEMPLATE_PARAM 
(TEMPLATE_ID, PARAM_CODE, SORT_NUM, REQUIRED_IND, SYSTEM_ONLY_IND, RESTRICT_CODE, RESTRICT_DETAIL, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1516, 'tdue', 102, 'Y', 'Y', 'S', '', sysdate, sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP003>>xxxxxxx ======= Marry template to email definition
--
INSERT INTO CSP.CORRES_GEN_TEMPLATE
(TEMPLATE_ID, EXTERNAL_REF, CORRES_GENERATOR_CODE, CREATED_DATE, MODIFIED_DATE, CREATED_BY, MODIFIED_BY) 
VALUES 
(1516, '1655', 'E1', sysdate, sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP004>>xxxxxxx ======= Create Multipart Definition
--
INSERT INTO EMAIL_MULTIPART 
(EMAIL_MULTIPART_CODE, MIME_SUBTYPE, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY)
VALUES (1656, 'alternative',  sysdate,  sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP005>>xxxxxxx ======= Create email definition with Multipart definition
--
INSERT INTO EMAIL_DEF 
(EMAIL_DEF_CODE, EMAIL_MULTIPART_CODE, DESCRIPTION, FROM_TXT, SUBJECT_TXT, REPLY_ADDRESS, SENDER_ADDRESS, CREATED_DATE, MODIFIED_DATE,CREATED_BY, MODIFIED_BY)
VALUES (1655, 1656,  'Exceeded credit limit on Overdraft Line - make deposit', 'ING DIRECT', 'Please Make A Deposit to Your Electric Orange', 'sales@ingdirect.com', '', sysdate,  sysdate, 'abrida', 'abrida');
--
-- xxxxxxxx<<STEP006>>xxxxxxx ======= Add the EMPTY PARTS(plain, html) to be uploaded later
--
insert into csp.email_bodypart (email_bodypart_code, email_body_type_code,mime_type,mime_encoding,mime_disposition, body_txt,created_by,created_date,modified_by,modified_date)
values (1656, 17, 'text/plain; charset="iso-8859-1"', '7bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate);

insert into csp.email_bodypart (email_bodypart_code,email_body_type_code,mime_type,mime_encoding,mime_disposition,body_txt,created_by,created_date,modified_by,modified_date)
values (1657, 17, 'text/html;"', '8bit', null, empty_clob(), 'abrida',sysdate,'abrida',sysdate);
--
-- xxxxxxxx<<STEP007>>xxxxxxx ======= Create Parts Definitions for the Multipart 
--
  
INSERT INTO EMAIL_MULTIPART_PART (EMAIL_MULTIPART_CODE, PART_BODYPART_CODE, PART_MULTIPART_CODE, EMAIL_MULTIPART_PART_ID, SORT_NUM,  CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES (1656, 1656,  NULL,  seq_email_multipart_part.nextval, 1, sysdate,  sysdate, 'abrida', 'abrida'); 
--
INSERT INTO EMAIL_MULTIPART_PART (EMAIL_MULTIPART_CODE, PART_BODYPART_CODE, PART_MULTIPART_CODE, EMAIL_MULTIPART_PART_ID, SORT_NUM,  CREATED_DATE, MODIFIED_DATE, CREATED_BY,MODIFIED_BY )
VALUES (1656, 1657,  NULL,  seq_email_multipart_part.nextval, 1, sysdate,  sysdate, 'abrida', 'abrida'); 

--
-- xxxxxxxx<<STEP008>>xxxxxxx ======= Update Notification ID with new Template
--
UPDATE csp.csp_ext_corres_type
     SET TEMPLATE_ID = 1516,
             MODIFIED_DATE = sysdate,
             MODIFIED_BY = 'abrida'
     WHERE
            EXT_SYSTEM_CODE = 1
        AND
           EXT_CORRES_TYPE_CODE = 16;      

--                
-- ================================================== COMMIT ========================================================
--
COMMIT;
-- ================================================== EOF =============================================================