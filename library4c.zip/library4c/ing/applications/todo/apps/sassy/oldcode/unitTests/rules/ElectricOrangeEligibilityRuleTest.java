package com.ingdirect.util.rules;

import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.w3c.dom.Document;

import java.util.Map;
import java.util.HashMap;
import java.io.FileInputStream;

import com.ingdirect.util.xml.ThreadLocalDocumentBuilder;

/**
 * @version $Revision: 615 $
 */
public class ElectricOrangeEligibilityRuleTest extends TestCase {
	// $NoKeywords $
	Document doc;
	static String id = ElectricOrangeEligibilityRuleTest.class.getName();
	
	RuleEngineImpl ruleEngine;
	RuleResult result;
	Map namedParamsMap;
	
	public ElectricOrangeEligibilityRuleTest(){
		super(id);
		
	}
	
	public void setUp() throws Exception {		
		doc = ThreadLocalDocumentBuilder.getDocumentBuilder(false).
		parse(new FileInputStream("unittest_data/infoForRules2.xml"));
		
		result = new RuleResult();
		ruleEngine = new RuleEngineImpl();
		namedParamsMap = new HashMap();
		
	}
	
	public void tearDown() {
		doc = null;
		namedParamsMap=null;
		ruleEngine=null;
		result=null;
		
	}

	public static void main(String[] args) throws Exception {
		//to run as an application
		new junit.textui.TestRunner().doRun(new TestSuite(ElectricOrangeEligibilityRuleTest.class));
	
		//! TODO 1. Need to test secondary customer
		//! TODO 2. Need to test dates using milliseconds
	}

	public void testElectricOrangeSuccess() {
		
		Rule rule = new ElectricOrangeEligibilityRule();

		//-- Success : Test using the Document --
		namedParamsMap.put( ElectricOrangeEligibilityRule.REQUIRED_FIRST_PARAMETER_CONTEXT_NODE, doc );
		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), true);
		
	}	
}
