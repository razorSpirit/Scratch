package com.ingdirect.util.rules;

//Standard Java
import java.util.List;
import java.util.ArrayList;
//   Third Party

//   ING DIRECT

/**
 * This class contains all the Public Constants used     
 * with the Rule Framework.
 *
 * Please refer to the the rule framework.
 *  
 * @see RuleEngineImpl, package.html
 * 
 * @author abrida
 * @version $Revision: 615 $
 */
public class RuleConstants {
	/**
	 * ***************************** XML Webtop CONSTANTS ************************************
	 */ 
	public static final String XML_EL_ACTIVITY = "OpenActivity";
	public static final String XML_EL_CIF = "CIF";
	public static final String XML_EL_CUST = "Customer";
	public static final String XML_EL_CUST2ND = "SecondaryCustomer";
	public static final String XML_EL_CUSTLIST = "CustomerList";
	public static final String XML_EL_DATE_OF_BIRTH = "DateOfBirth";	
	public static final String XML_EL_DETAIL = "Detail";	
	public static final String XML_EL_ELIGIBILITY = "Eligibility";	
	public static final String XML_EL_ELIGIBILITY_TYPE = "EligibilityType";	
	public static final String XML_EL_ELIGIBLE = "Eligible";	
	public static final String XML_EL_EXTERNAL_LINKS = "ExternalLinks";
	public static final String XML_EL_EXTERNAL_LINK = "ExternalLink";
	public static final String XML_EL_FAS_BUSINESS_NAME = "FasBusinessName";
	public static final String XML_EL_LINK_STATUS = "LinkStatus";
	public static final String XML_EL_RELATED_CUSTOMER = "RelatedCustomer";
	public static final String XML_EL_RESTRICTION = "Restriction";
	public static final String XML_EL_RESTRICTION_CODE = "RestrictionCode";
	public static final String XML_EL_ROOT = "Session";
	public static final String XML_EL_SCRATCH = "ScratchPads";
	public static final String XML_EL_STATIC = "StaticData";
	public static final String XML_EL_STATUS = "Status";	
	public static final String XML_EL_SUMMARIES = "Summaries";	
	public static final String XML_EL_SUMMARY = "Summary";	
	public static final String XML_EL_SYSTEM = "System";
	public static final String XML_EL_USER = "User";
	public static final String XML_EL_WORK_ITEM_INTERACTION ="WorkItemInteraction";

	/**
	 * ***************************** APPLICATION CONSTANTS ************************************
	 */ 
	//TODO ajb : Get the real EL Account Type AND NAME
	public static final String APP_EO_ACCOUNT_TYPE = "4000";
	public static final String APP_EO_ACCOUNT_TYPE_NAME = "EORANGE";
	
	/**
	 * ***************************** Rules ERROR CODE CONSTANTS ************************************
	 */ 
	public static final String ERROR_CODE_EXCEPTION             = "EXCEPTION";
	public static final String ERROR_CODE_INVALID_ACCOUNT_TYPE  = "INVALID_ACCOUNT_TYPE";
	public static final String ERROR_CODE_INVALID_DOCUMENT      = "INVALID_DOCUMENT";
	public static final String ERROR_CODE_INVALID_ELEMENT       = "INVALID_ELEMENT";
	public static final String ERROR_CODE_INVALID_METHOD        = "INVALID_METHOD";
	public static final String ERROR_CODE_INVALID_METHOD_CALL   = "INVALID_METHOD_CALL";
	public static final String ERROR_CODE_INVALID_NODE          = "INVALID_NODE";
	public static final String ERROR_CODE_INVALID_NODE_PATH     = "INVALID_NODE_PATH";
	public static final String ERROR_CODE_INVALID_PARAMETERS    = "INVALID_PARAMETERS";
	public static final String ERROR_CODE_INVALID_PARAMETER_VALUE  = "INVALID_PARAMETER_VALUE";
	public static final String ERROR_CODE_INVALID_VALUE            = "INVALID_VALUE";
	public static final String ERROR_CODE_NOT_FOUND                = "NOT_FOUND";
	public static final String ERROR_CODE_NULL_VALUE                = "NULL";
	public static final String ERROR_CODE_PROGRAMMER_ERROR         = "PROGRAMMER_ERROR";

	/**
	 * ***************************** Rules ERROR CODE CONSTANTS ************************************
	 */ 
	public static final String RETURN_CODE_ASSESSED_ALREADY            = "RAN_ALREADY";
	
	/**
	 * ***************************** SYSTEM PARAMETERS ************************************
	 */ 
	public static final String SYSTEM_PARAM_SUCCESSES             = "system.SUCCESSES.";
	public static final String SYSTEM_PARAM_DATA                  = "system.DATA.";
	public static final String SYSTEM_PARAM_PREFIX                = "system.PARAM.";
	public static final String SYSTEM_PARAM_CALLER_PREFIX         = "system.CALLER.PARAM.";
	public static final String SYSTEM_CHECKED_VALUE_PREFIX        = "system.CV.";
	public static final String SYSTEM_PARAM_FOUND_LIST            = "system.param.foundList";
	public static final String SYSTEM_PARAM_REQUIRED_LIST         = "system.param.requiredList";
	public static final String SYSTEM_PARAM_OPTIONAL_LIST         = "system.param.optionalList";
	
	public static final String SYSTEM_PARAM_NAME_TEST_VALUE       = "system.TestValue";
	/**
	 * ***************************** PARAMETER NAMES ************************************
	 */ 
	public static final String PARAM_NAME_CONTEXT_NODE              = "p.contextNode";
	public static final String PARAM_NAME_NODE_SPACE                = "p.nodeSpace";
	public static final String PARAM_NAME_NODE_LOCATION             = "p.nodeLocation";
	public static final String PARAM_NAME_NODE_PATH                 = "p.nodePath";

	public final static String PARAM_NAME_AGE = "p.age";	
	public final static String PARAM_NAME_AGE_UNITS = "p.ageUnits";	
	public static final String PARAM_NAME_COMMENTS = "p.comments";		
	public static final String PARAM_NAME_COUNT = "p.count";		
	public static final String PARAM_NAME_DATE_FORMAT = "p.dateFormat";		
	public final static String PARAM_NAME_END_DATE = "p.endDate";
	public static final String PARAM_NAME_END_DATE_FORMAT = "p.endDateFormat";
	public static final String PARAM_NAME_END_YYYY = "p.endYYYY";
	public final static String PARAM_NAME_LINKS = "p.links";	
	public final static String PARAM_NAME_NODE_LIST = "p.nodeList";	
	public final static String PARAM_NAME_NODE_NAME_IN_LIST = "p.nodeNameInList";	
	public final static String PARAM_NAME_OPERATOR = "p.operator";	
	public final static String PARAM_NAME_REGULAR_EXPRESSION = "p.regEx";
	public final static String PARAM_NAME_RELATED_CUSTOMER = "p.relatedCustomer";
	public final static String PARAM_NAME_SECONDARY_CUSTOMER = "p.secondaryCustomer";
	public final static String PARAM_NAME_START_DATE = "p.startDate";
	public static final String PARAM_NAME_START_DATE_FORMAT = "p.startDateFormat";	
	public static final String PARAM_NAME_START_YYYY = "p.startYYYY";
	public static final String PARAM_NAME_SUMMARIES = "p.summaries";
	public static final String PARAM_NAME_TEXT = "p.text";
	public static final String PARAM_NAME_USE_MILLISECONDS= "p.useMilliseconds";
	public static final String PARAM_NAME_VALUE = "p.value";
	public static final String PARAM_NAME_VALUES_MAP = "p.valuesMap";
	
	public final static String PARAM_NAME_TYPE_1 = "p.type1";
	public final static String PARAM_NAME_TYPE_2 = "p.type2";
	public final static String PARAM_NAME_TYPE_3 = "p.type3";
	public final static String PARAM_NAME_TYPE_4 = "p.type4";
	public final static String PARAM_NAME_TYPE_5 = "p.type5";
	public final static String PARAM_NAME_TYPE_6 = "p.type6";
	
	
	/**
	 *  Values 
 	 */
	public final static String OPERATOR_EQUALS = "=";
	public final static String OPERATOR_GREATER_THEN = ">";
	public final static String OPERATOR_GREATER_THEN_OR_EQUAL = ">=";	
	public final static String OPERATOR_LESS_THEN = "<";
	public final static String OPERATOR_LESS_THEN_OR_EQUAL = "<=";	
	public final static String OPERATOR_NOT_EQUALS = "!=";

	public final static int INT_EQUALS = 0;
	public final static int INT_GREATER_THEN = 1;
	public final static int INT_GREATER_THEN_OR_EQUAL = 2;
	public final static int INT_LESS_THEN = 3;
	public final static int INT_LESS_THEN_OR_EQUAL  = 4;
	public final static int INT_NOT_EQUALS = 5;
	
	public final static List OPERATORS_LIST = new ArrayList(){
		{
			add(INT_EQUALS, OPERATOR_EQUALS);		
			add(INT_GREATER_THEN, OPERATOR_GREATER_THEN);		
			add(INT_GREATER_THEN_OR_EQUAL, OPERATOR_GREATER_THEN_OR_EQUAL);		
			add(INT_LESS_THEN, OPERATOR_LESS_THEN);		
			add(INT_LESS_THEN_OR_EQUAL, OPERATOR_LESS_THEN_OR_EQUAL);		
			add(INT_NOT_EQUALS, OPERATOR_NOT_EQUALS);		
		}
	};

	public final static String UNIT_YEARS = "years";
	public final static String UNIT_DAYS = "days";
	public final static String TRUE_STRING = "1"; 	
	public final static String FALSE_STRING = "0";
	public final static String TRUE = "true";
	public final static String FALSE = "false";
	
	/**
	 *  Default values
 	 */
	public static RuleNodeSpace DEFAULT_NODE_SPACE = new SessionNodeSpace();
	public final static String DEFAULT_DATE_FORMAT = "YYYY-MM-DD";
	public final static String DEFAULT_AGE_UNITS = "";
}
