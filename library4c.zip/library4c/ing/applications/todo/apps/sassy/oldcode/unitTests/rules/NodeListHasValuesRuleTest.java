package com.ingdirect.util.rules;

import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.w3c.dom.Document;

import java.util.Map;
import java.util.HashMap;
import java.io.FileInputStream;

import com.ingdirect.util.xml.ThreadLocalDocumentBuilder;

/**
 * @version $Revision: 615 $
 */
public class NodeListHasValuesRuleTest extends TestCase {
	// $NoKeywords $
	Document doc;
	static String id = NodeListHasValuesRuleTest.class.getName();
	
	RuleEngineImpl ruleEngine;
	RuleResult result;
	Map namedParamsMap;
	
	public NodeListHasValuesRuleTest(){
		super(id);
		
	}
	
	public void setUp() throws Exception {		
		doc = ThreadLocalDocumentBuilder.getDocumentBuilder(false).
		parse(new FileInputStream("unittest_data/infoForRules2.xml"));
		
		result = new RuleResult();
		ruleEngine = new RuleEngineImpl();
		namedParamsMap = new HashMap();
		
	}
	
	public void tearDown() {
		doc = null;
		namedParamsMap=null;
		ruleEngine=null;
		result=null;
		
	}

	public static void main(String[] args) throws Exception {
		//to run as an application
		new junit.textui.TestRunner().doRun(new TestSuite(TextHasValueRuleTest.class));	
	}

	public void testValuesSuccess() {
		
		Rule rule = new NodeListHasValuesRule();

		//-- Success : Test two nodes in nodelist --
		Map valuesMap = new HashMap()
		{
			{
				put(RuleConstants.XML_EL_ELIGIBILITY_TYPE, "EORANGE");
				put(RuleConstants.XML_EL_ELIGIBLE, "true");
			}
		};
		
		
		namedParamsMap.put( NodeListHasValuesRule.REQUIRED_FIRST_PARAMETER_NODE_LIST, new RuleNodePathName(SessionNodePathMap.PATH_DETAIL_ELIGIBILITY));
		namedParamsMap.put( NodeListHasValuesRule.REQUIRED_SECOND_PARAMETER_VALUES_MAP, valuesMap);
		namedParamsMap.put( NodeListHasValuesRule.OPTIONAL_STANDARD_PARAMETER_CONTEXT_NODE, doc);
		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), true);

		//-- Fail : Test three nodes in nodelist --

		valuesMap.put("BadNode", "someValue");
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), false);
		
	}
	
}
