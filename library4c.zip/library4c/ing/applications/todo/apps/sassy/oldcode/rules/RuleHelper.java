package com.ingdirect.util.rules;

import org.w3c.dom.Node;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import com.ingdirect.util.xml.XmlHelper;
import com.ingdirect.util.StringUtil;

/**
 * @version $Revision: 577 $
 */
public class RuleHelper {
	private static final String CLASS_ID = RuleHelper.class.getName();
	private static final String LOG_NAME = CLASS_ID;
	private static final Logger log = Logger.getLogger(LOG_NAME);
	
	// $NoKeywords $
	// RuleHelper.checkNamedParameters(_namedParameters, getName(), 

	public static final boolean addNamedParametersList(Rule rule, boolean isOptional){
		RuleResult result = rule.getResult();
		result.setIsOk(true);
		
		String listPrefix;
		String[][] parameters;
		
		/** Get either the optional or required parameters */ 
		if(isOptional){
			parameters = rule.getOptionalParameters();
			listPrefix=RuleConstants.SYSTEM_PARAM_OPTIONAL_LIST;
		}else{
			parameters = rule.getRequiredParameters();		
			listPrefix=RuleConstants.SYSTEM_PARAM_REQUIRED_LIST;
		}
		
		/** If there are no parameters then return */
		if(parameters.length == 0){
			return true;
		}
		
		//Map map = RuleHelper.getSystemDataMap(rule);
		
		String[] parameterOptions;
		String parameterName;
		
		List foundList = new ArrayList();		
		List notFoundList = new ArrayList();
		boolean foundFlag;
		
		int nRows = parameters.length;
		int nCols;
		
		for(int i=0; i<nRows; i++){
			parameterOptions = parameters[i];
			nCols = parameterOptions.length;
			foundFlag = false;
			for(int j=0; j<nCols; j++){
				parameterName = parameterOptions[j];
				if( RuleHelper.parameterValueContainsKey(rule, parameterName) ){
						foundList.add(foundList.size(), parameterName);
						foundFlag=true;
				} 
			}
			if(!foundFlag){
				notFoundList.add(parameterOptions);
			}			
		}

		/**
		 * If the list is optional just add the foundList, otherwise,
		 * if there are items that were not found then return an error,
		 * otherwise, add the foundList.
 		 */		
		//Save the Paramters or add an error to the result
		if( notFoundList.isEmpty() || isOptional ){
			RuleHelper.putGlobalValue(rule, listPrefix, foundList);
		} else {
			StringBuffer sb = new StringBuffer();
			nRows = notFoundList.size();
			for(int i=0; i<nRows; i++){
				parameterOptions = (String[]) notFoundList.get(i);
				nCols = parameterOptions.length;
				if(nCols == 1){
					sb.append(parameterOptions[0]+", ");
				}else{
					sb.append("["+parameterOptions[0]);
					for(int j=1; j<nCols; j++){					
						sb.append(" or "+parameterOptions[j]);
					}
					sb.append("], ");					
				}
			}
			result.setIsOk(false);
			RuleError error = new RuleError();
			result.setCode(RuleConstants.ERROR_CODE_INVALID_PARAMETERS);
			result.setDescription("The following parameters were not supplied: "+sb.toString());
			error.setCode(result.getCode());
			error.setDescription(result.getDescription());
			result.getErrors().put(rule.getName()+":"+RuleConstants.ERROR_CODE_INVALID_PARAMETERS,error);			
		}
		
		return result.isOk();
	}
	
	public final static RuleResult hasRanAlready(Rule rule){
		RuleResult result = new RuleResult();
		
		//Lookup rule in SuccessMap
		if(rule.getRuleEngine().getSuccessMap().containsKey( rule.getName() ) ){
			result.setIsOk(true);			
			result.setCode(RuleConstants.RETURN_CODE_ASSESSED_ALREADY);
			return result;
		}
		return result;
	}


	public final static boolean resultAssert(boolean expectedResult, RuleResult result, String prefix, String ruleName){
		
		boolean ok = expectedResult == result.isOk();
		
		if(prefix == null){
			prefix = "";
		}
		
		String name = "<<<<<<<"+(ruleName == null ? "unknown" : ruleName)+">>>>>>>";
		
		if( ok ){
			log.finest(prefix+"******PASSED****** : "+ name );
		} else {
			log.finest(prefix+"******FAILED****** : "+ name );
		}
		
		return ok;
	}

	public final static RuleResult createInvalidMethodResult(String methodName) {
		RuleResult result = new RuleResult();
		result.setCode(	RuleConstants.ERROR_CODE_INVALID_METHOD_CALL );
		result.setDescription("The method("+methodName+") must not be called from the base class.");
		return result;		
	}
	
	public final static boolean addStandardOptions(Rule rule){

		RuleResult result = rule.getResult();
		result.setIsOk(true);

		//-- add contextNode --
		Object value = RuleHelper.getParameterValue( rule, RuleConstants.PARAM_NAME_CONTEXT_NODE );
		if(value == null){
			//No Default
			;
		} else {
			RuleParameterHelper.validateContextNode(rule, RuleConstants.PARAM_NAME_CONTEXT_NODE, value);	
		}
		
		if( !result.isOk() ){
			return false;
		}
		
		//-- add NodeSpace --
		value = RuleHelper.getParameterValue( rule, RuleConstants.PARAM_NAME_NODE_SPACE );
		if(value == null ){
			value = RuleConstants.DEFAULT_NODE_SPACE;
			RuleHelper.putGlobalValue(rule, RuleConstants.PARAM_NAME_NODE_SPACE, value);
		}
		
		RuleParameterHelper.validateNodeSpace(rule, RuleConstants.PARAM_NAME_NODE_SPACE, value);
		if( !result.isOk() ){
			return false;
		}
		
		//-- add Comments --
		value = RuleHelper.getParameterValue( rule, RuleConstants.PARAM_NAME_COMMENTS );
		if(value == null ){
			//No Default
			;
		}else{		
			RuleParameterHelper.validateString(rule, RuleConstants.PARAM_NAME_COMMENTS, value);
		}
		
		//done
		return result.isOk();		
	}
	public final static boolean addCheckedValue(Rule rule, String checkedValue){
		putSystemSuccess(rule, RuleConstants.SYSTEM_CHECKED_VALUE_PREFIX+checkedValue, null);
		return true;
	}
	public final static boolean wasValueChecked(Rule rule, String checkedValue){
		return rule.getRuleEngine().getSuccessMap().containsKey(RuleConstants.SYSTEM_CHECKED_VALUE_PREFIX+checkedValue);
	}
	
	public final static Object getSystemData(Rule rule, String key){
		return rule.getRuleEngine().getDataMap().get(key);
	}
	public final static Object putSystemData(Rule rule, Object key, Object value){
		return rule.getRuleEngine().getDataMap().put(key, value);
	}
	public final static Map getSystemDataMap(Rule rule) {  
		return rule.getRuleEngine().getDataMap(); 
	}	
	public final static boolean systemDataContainsKey(Rule rule, Object key){   return rule.getRuleEngine().getDataMap().containsKey(key); }
	
	public final static Object getParameterValue(Rule rule, String baseKey){
		String key=rule.getParameterName(baseKey);
		if( key == null){
			return null;
		}
		return rule.getRuleEngine().getDataMap().get(key);
	}
	public final static Object putParameterValue(Rule rule, String baseKey, Object value){
		String	key = rule.createParameterName(baseKey);
		return rule.getRuleEngine().getDataMap().put(key, value);
	}
	public final static boolean parameterValueContainsKey(Rule rule, String baseKey){
		String key=rule.getParameterName(baseKey);
		return !(key == null);		
	}
	
	public final static Object getGlobalValue(Rule rule, String baseKey){
		return rule.getRuleEngine().getDataMap().get(baseKey);
	}
	public final static Object putGlobalValue(Rule rule, String baseKey, Object value){
		return rule.getRuleEngine().getDataMap().put(baseKey, value);
	}
	
	public final static Object getSystemSuccess(Rule rule, String key){
		return rule.getRuleEngine().getSuccessMap().get(key);
	}
	public final static Object putSystemSuccess(Rule rule, Object key, Object value){
		return rule.getRuleEngine().getSuccessMap().put(key, value);
	}
	public final static boolean systemSuccessContainsKey(Rule rule, Object key){   return rule.getRuleEngine().getSuccessMap().containsKey(key); }
	public final static Map getSystemSuccessMap(Rule rule) {  return rule.getRuleEngine().getSuccessMap(); }	

	public final static String getContextPath(Node node){
		if(node == null){
			return null;
		}
		boolean isDocumentElement = false;
		Node parent = node.getParentNode();

		if(node.getNodeType() == Node.DOCUMENT_NODE){			
			return "#document";
		} else if(parent == null) {
			return node.getNodeName();
		} else if( parent.getNodeName().equals(node.getNodeName() ) ){
			isDocumentElement=true;
		}
		
		List parentList = new ArrayList();
		int nCount = 0;
		
		//FYI : The last node is the document node
		while(parent != null){
			parentList.add(nCount++, parent.getNodeName());
			parent=parent.getParentNode();
		}
		
		// Should be an element
		String suffix = "";
		if( (!isDocumentElement) && node.getNodeType() == Node.ELEMENT_NODE){
				suffix =  ( (Element) node).getTagName();				
		}
		
		//
		if( nCount == 0){
			return suffix.equals("") ? null : suffix;
		}
		
		//reverse the length
		StringBuffer sb = new StringBuffer();
		int i = nCount - 1;
		while(i > -1){
			sb.append(parentList.get(i--)+"/");
		}		
		
		if(suffix.equals("")){
			String temp = sb.toString();
			return temp.substring(0, temp.length()-1);
		} else {
			return sb.toString()+suffix;
		}

	}
	
	public final static String getNameSpaceForContextPath(Map nameSpaceMap, String path, String startingNameSpace){
		String[] paths = path.split("\\/");
		String nameSpace = startingNameSpace;
		int nCount = paths.length;
		
		//if the last Node has a prefix that look it up and return it.
		String tag = paths[nCount-1];
		String key;
		int pos = tag.indexOf(":");
		if(pos > -1){
			key = tag.substring(0, ++pos);
			key = (String) nameSpaceMap.get(key);
			return (key == null ? startingNameSpace : key);
		}
		
		//Step through the path and return last found namespace
		StringBuffer sb = new StringBuffer(paths[0]);
		key = sb.toString();
		if( nameSpaceMap.containsKey(key) ){
			nameSpace=(String) nameSpaceMap.get(key);
		}
		
		for(int i=1; i<nCount; i++){
			sb.append("/"+paths[i]);
			key = sb.toString();
			pos=key.indexOf(":");
			
			//Check for prefix (include the : in the key)
			if(pos > -1){
				key = tag.substring(0, ++pos);
			}
			
			if( nameSpaceMap.containsKey(key) ){
				nameSpace=(String) nameSpaceMap.get(key);
			}
			
		}
		
		return nameSpace;
	}
	
	public final static Object getObjectForPathFromContextNodeNS(RuleNodeSpace nodeSpace, Node contextNode, RuleNodePath nodePath){
		log.finest("000-Entered path("+StringUtil.fillNull( "" )+")");
		
		String contextPath = getContextPath(contextNode);
		
		log.finest("005-contextPath("+StringUtil.fillNull(contextPath)+")");
		
		Node node;
		NodeList nodeSet = null;
		Map nameSpaceMap = nodeSpace.getNameSpaceMap();
		String nameSpace;
		
		RuleNodePathMap nodePathMap = nodeSpace.getNodePathMap();
		RuleNodePath nodePathWork = new RuleNodePath(nodePath);
		
		if( nodePathWork.getPath() == null ){
			RuleNodePath temp = nodePathMap.get( nodePathWork.getPathName() );
			if(temp == null){
				log.finest("007-Path not found.");
				return null;
			}
			
			nodePathWork = new RuleNodePath(temp);
			
		}
		
		String pathToNode = nodePathWork.getPath();		
		
		//Check if the node is the target node
		if( pathToNode.equals(contextPath) ){
			log.finest("010-Done- node is contextNode.");
			nameSpace = getNameSpaceForContextPath(nameSpaceMap, contextPath, null);
			nodeSet = getElementUsingTagNameNS((Element) contextNode.getParentNode(), nameSpace, ((Element) contextNode).getTagName() );
		}else{
			boolean isGatewaymessage = false;
			//The path MUST START with contextPath unless we are processing a gatewayMessage
			if( ! pathToNode.startsWith(contextPath) ){
				log.finest("015- path does not start with contextPath.");
				if( contextNode.getParentNode() == null ){
					isGatewaymessage = true;
					log.finest("016- parent of context is null - assume gatewayMessage.");
				} else {
					log.finest("017- done - contextPath mismatch.");
					return null;
				}
			} 
	
			//Get the starting namespace for the contextPath
			nameSpace = getNameSpaceForContextPath(nameSpaceMap, contextPath, null);
	
			log.finest("019-nameSpace("+StringUtil.fillNull(nameSpace)+")");
			
			//Find the node in the path starting from the contextNode
			String fromPath;
			if( isGatewaymessage ){
				int pos = contextPath.indexOf("/");
				String findNode;
				if(pos == -1){
					findNode = contextPath;
				} else {
					findNode = contextPath.substring(0, pos);
				}
				pos = pathToNode.indexOf(findNode);
				if(pos == -1){
					log.finest("020- done - findNode("+findNode+") not in pathToNode. Bad contextNode.");
					return null;
				}
				fromPath = pathToNode.substring(pos+findNode.length()+1);
			} else {
				fromPath = pathToNode.substring(contextPath.length()+1);
			}
			
			log.finest("025-fromPath("+StringUtil.fillNull(fromPath)+")");
			
			String[] paths = fromPath.split("\\/");
			int nCount = paths.length; 
			
			String tagName = paths[0];
			StringBuffer sb = new StringBuffer(contextPath+"/"+tagName);
			String key = sb.toString();
			
			int pos=key.indexOf(":");
			
			//Check for prefix (include the : in the key)
			if(pos > -1){
				key = key.substring(0, ++pos);
			}
			
			if( nameSpaceMap.containsKey(key) ){
				nameSpace=(String) nameSpaceMap.get(key);
			}
			
			Element parent;
			if(contextNode.getNodeType() == Node.DOCUMENT_NODE){
				log.finest("040-parent is document.)");
				parent = ((Document) contextNode).getDocumentElement();
			} else {
				log.finest("041-parent not document.)");
				parent = (Element) contextNode;
			}
			
			if(parent.getTagName().equals(tagName)){
				node = parent;
			} else {
				nodeSet = getElementUsingTagNameNS(parent, nameSpace, tagName);
				node=nodeSet.item(0);
			}
			
			if(node == null){
				log.finest("050-Done-node is null for tagName("+StringUtil.fillNull(tagName)+") parent("+parent.getTagName()+") nameSpace("+nameSpace+")");
				return null;
			}
			
			//Get the NodeList at the end of the path
			//Return null if null encountered on path
			for(int i=1; i<nCount; i++){
				tagName = paths[i];
				sb.append("/"+ tagName);
				key = sb.toString();

				pos=key.indexOf(":");
				//Check for prefix (include the : in the key)
				if(pos > -1){
					key = key.substring(0, ++pos);
				}
				
				if( nameSpaceMap.containsKey(key) ){
					nameSpace=(String) nameSpaceMap.get(key);
				}
				nodeSet = getElementUsingTagNameNS(parent, nameSpace, tagName);
				if(nodeSet == null){
					log.finest("080-Done-node is null for tagName("+StringUtil.fillNull(tagName)+") parent("+parent.getTagName()+") nameSpace("+nameSpace+")");
					return null;
				}
				
			}
		}
		
		//Return the value defined by the nodePathWork
		Object value;
		
		if( nodePathWork.isTextType() ){
			value = XmlHelper.getNodeText(nodeSet.item(0));
			log.finest("996-text("+StringUtil.fillNull((String) value)+")");			
		} else if( nodePathWork.isNodeSetType() ){
			log.finest("997-NodeSet");
			value = nodeSet;
		} else {
			log.finest("998-Node");
			value =nodeSet.item(0);
		}
		
		return value;		
	}
	
	//TODO ajb : error handling
	public final static Element getElementWithValueForPath(RuleNodeSpace nodeSpace, Node contextNode, RuleNodePath nodePath, String elementName, String regex){
		if( nodeSpace == null){
			nodeSpace = RuleConstants.DEFAULT_NODE_SPACE;
		}
		
		NodeList nodeList = (NodeList) getObjectForPathFromContextNodeNS(nodeSpace, contextNode, nodePath);	

		if(nodeList == null){
			return null;
		}
		
		int nCount = nodeList.getLength();
		Element element = null;
		Node node;
		String text;
		boolean found = false;
		
		for(int i=0; i<nCount; i++){
			element = (Element) nodeList.item(i);
			node = element.getElementsByTagName(elementName).item(0);
			if(node != null){
				text=XmlHelper.getNodeText(node);
				if( text.matches(regex) ){
					found = true;
					break;
				}
			}
		}
		if(! found) {
			element = null;
		}
		
		return element;
	}
	
	public final static NodeList getElementUsingTagNameNS(Element parent, String nameSpace, String tagName){
		if(nameSpace == null){
			return parent.getElementsByTagName(tagName);			
		}
		return parent.getElementsByTagNameNS(nameSpace,tagName);		
	}
	
	public final static RuleNodeSpace getDefaultRuleNodeSpace() {  return RuleConstants.DEFAULT_NODE_SPACE; } 
}// ~
