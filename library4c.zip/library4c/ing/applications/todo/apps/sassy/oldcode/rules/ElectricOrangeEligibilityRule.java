package com.ingdirect.util.rules;

import com.ingdirect.dg.service.CustGetDetail;

import java.util.logging.Logger;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * @version $Revision: 615 $
 */
public class ElectricOrangeEligibilityRule extends Rule {
	// $NoKeywords $
		/* Required Parameter Names */
		public final static String REQUIRED_FIRST_PARAMETER_CONTEXT_NODE = RuleConstants.PARAM_NAME_CONTEXT_NODE;

		/* -- Optional Parameters -- */
		public final static String OPTIONAL_PARAMETER_SECONDARY_CUSTOMER = RuleConstants.PARAM_NAME_SECONDARY_CUSTOMER;
		public final static String OPTIONAL_PARAMETER_RELATED_CUSTOMER = RuleConstants.PARAM_NAME_RELATED_CUSTOMER;
		public final static String OPTIONAL_PARAMETER_LINKS = RuleConstants.PARAM_NAME_LINKS;
		public final static String OPTIONAL_PARAMETER_SUMMARIES = RuleConstants.PARAM_NAME_SUMMARIES;
	
		/* -- Standard Optional Parameters -- */
		public final static String OPTIONAL_STANDARD_PARAMETER_NODE_LOCATION = RuleConstants.PARAM_NAME_NODE_LOCATION;
		public final static String OPTIONAL_STANDARD_PARAMETER_COMMENTS = RuleConstants.PARAM_NAME_COMMENTS;

		/* Default Values */
		final String DEFAULT_SECONDARY_CUSTOMER = RuleConstants.FALSE_STRING;	
		final String DEFAULT_RELATED_CUSTOMER = RuleConstants.FALSE_STRING;	
	
		/**
		 * Constructor : default
		 */ 
		public ElectricOrangeEligibilityRule() { super(); }
	
		/**
		 * Constructor with engine parameter
		 * @param alwaysAssessRule - boolean flag that tells the <i>RuleEngineImpl<i>
		 *        that this rule will always be ran, even if it has run already.
		 *        When false, the <i>RuleEngineImpl<i> will check to see if this
		 *        rule ran successfully, and if so, it will <i>NOT</i> run this
		 *        rule and return a successful result, otherwise, the rule will be
		 *        ran.
		 */	
		ElectricOrangeEligibilityRule( boolean alwaysAssessRule){
			 super( alwaysAssessRule); 
		}

		ElectricOrangeEligibilityRule( Rule rule){
		    super( rule );
		}
	
		/**	
		 * Called by the contructor to define the 
		 * id of the rule, the log name, and the required and
		 * optional parameters.
		 */ 
		void init(){
			CLASS_ID = AgeFromDateRule.class.getName();
			logName = CLASS_ID;
			log = Logger.getLogger(logName);
		
			//Always assess this rule
			this.setAlwaysAssessRule(true);
		
			String[][] myParameterNames = { { REQUIRED_FIRST_PARAMETER_CONTEXT_NODE },
			                              };
		
			this.setRequiredParameters(myParameterNames);
		
			String [][] myOptionalParameterNames = { { OPTIONAL_PARAMETER_SECONDARY_CUSTOMER },
			                                         { OPTIONAL_PARAMETER_RELATED_CUSTOMER },
			                                         { OPTIONAL_PARAMETER_LINKS },
			                                         { OPTIONAL_PARAMETER_SUMMARIES },
												  };
			this.setOptionalParameters(myOptionalParameterNames);
		}

		/**
		 * Called by engine to validate the parameter values for this rule.
		 * If the parameter values were already check then we return a 
		 * successful result.
		 * 
		 */
		boolean checkParametersValues(){
		
			//Establish the result - false
			RuleResult result = getResult();
		
			//--  validate the optional parameters
			if( ! validateOptionalParameters() ) return false;
		
			//Validate the required parameter values
			if( ! validateRequiredParameterValues() ) return false;
		
			//done
		    return result.isOk();
	   }

		/**
		 * Called by engine to determine whether the rule applies to 
		 * the provided parameters.
		 * 
		 */	
		void applyRule(){
		
			RuleResult result;
			Rule rule;
			
			//-- Get the required parameters      --			
			//  Since the context node is a standard optional parameter, we don't have to get it.

			//-- Get the optional parameters      --		
			boolean isSecondaryCustomer = RuleConstants.TRUE_STRING.equals( fieldMap.get(OPTIONAL_PARAMETER_SECONDARY_CUSTOMER) );
			boolean isPrimaryCustomer = RuleConstants.FALSE_STRING.equals( fieldMap.get(OPTIONAL_PARAMETER_RELATED_CUSTOMER) );
			String suffix = isSecondaryCustomer ? "2" : "";
			
			Object links = fieldMap.get(OPTIONAL_PARAMETER_LINKS);;
			if(links == null){
				links =new RuleNodePathName(SessionNodePathMap.PATH_EXTERNAL_LINK+suffix);	
			}
			
			Object summaries = fieldMap.get(OPTIONAL_PARAMETER_SUMMARIES);
			if(summaries == null){
				summaries =new RuleNodePathName(SessionNodePathMap.PATH_SUMMARIES_SUMMARY+suffix);	
			}
			
			String comments = (String) fieldMap.get(OPTIONAL_STANDARD_PARAMETER_COMMENTS);
			if(comments == null) {
				comments = "";
			}else{
				comments="<<"+comments+">>";
			}
			Map mapValues = new HashMap();
			
			
			//-- Run all the rules --

			//-- Rule 1 : Must not have an EO account    --
			rule = new NodeListHasValuesRule(this);
			mapValues.clear();	
			mapValues.put("Type",RuleConstants.APP_EO_ACCOUNT_TYPE);
				
			RuleHelper.putParameterValue(rule, NodeListHasValuesRule.REQUIRED_FIRST_PARAMETER_NODE_LIST, summaries );
			RuleHelper.putParameterValue(rule, NodeListHasValuesRule.REQUIRED_SECOND_PARAMETER_VALUES_MAP, mapValues );			
				
			result = engine.assess(rule);
				
			if( ! RuleHelper.resultAssert(false, result, comments+"010 Rule 01: ", "Must not have an EO account") ) return;
			
			//-- Rule 2 : Primary must be invited    --
			if(isPrimaryCustomer){
				rule = new NodeListHasValuesRule(this);
				
				mapValues.clear();	
				mapValues.put("InvitationType",CustGetDetail.TYPE_ELECTRIC_ORANGE);
				mapValues.put("Invited","true");
				
				RuleHelper.putParameterValue(rule, NodeListHasValuesRule.REQUIRED_FIRST_PARAMETER_NODE_LIST, new RuleNodePathName( SessionNodePathMap.PATH_DETAIL_INVITATIONS+suffix ));
				RuleHelper.putParameterValue(rule, NodeListHasValuesRule.REQUIRED_SECOND_PARAMETER_VALUES_MAP, mapValues );			
				
				result = engine.assess(rule);
				
				if( ! RuleHelper.resultAssert(true, result, comments+"020 Rule 02: ", "Primary must be invited") ) return;
			} else {
				log.finest(comments+"020 Rule 02: ******PASSED****** : SKIP Primary must be invited" );
			}
			
			//-- Rule 3 : Must be a customer    --
			rule = new TextHasValueRule(this);

			RuleHelper.putParameterValue(rule, TextHasValueRule.REQUIRED_FIRST_PARAMETER_TEXT, new RuleNodePathName(SessionNodePathMap.PATH_DETAIL_STATUS+suffix) );
			RuleHelper.putParameterValue(rule, TextHasValueRule.REQUIRED_SECOND_PARAMETER_REGULAR_EXPRESSION, "customer");
			
			result = engine.assess(rule);
			
			if( ! RuleHelper.resultAssert(true, result, comments+"030 Rule 03: ", "Must be a customer") ) return;
			
			//-- Rule 4 : Must be 18 or over    --
			rule = new AgeFromDateRule(this);
			RuleHelper.putParameterValue(rule, AgeFromDateRule.REQUIRED_FIRST_PARAMETER_START_DATE, new RuleNodePathName(SessionNodePathMap.PATH_DETAIL_DATE_OF_BIRTH+suffix));
			RuleHelper.putParameterValue(rule, AgeFromDateRule.REQUIRED_SECOND_PARAMETER_AGE, new Long(18));
			
			result = engine.assess(rule);	
			
			if( ! RuleHelper.resultAssert(true, result, comments+"040 Rule 04: ", "Must be 18 or over") ) return;
			
			//-- Rule 5 : Must have at least 1 verifiable link    --
			rule = new CountForValueRule(this);
			RuleHelper.putParameterValue(rule, CountForValueRule.REQUIRED_FIRST_PARAMETER_NODE_LIST, links);
			RuleHelper.putParameterValue(rule, CountForValueRule.REQUIRED_SECOND_PARAMETER_NODE_NAME_IN_LIST, RuleConstants.XML_EL_LINK_STATUS);
			RuleHelper.putParameterValue(rule, CountForValueRule.REQUIRED_THIRD_PARAMETER_REGULAR_EXPRESSION, "verified");
			RuleHelper.putParameterValue(rule, CountForValueRule.REQUIRED_FOURTH_PARAMETER_COUNT, new Integer(1));
			
			result = engine.assess(rule);	
			
			if( ! RuleHelper.resultAssert(true, result, comments+"050 Rule 05: ", "Must have at least 1 verifiable link") ) return;

			//-- Rule 6 : Must have at least 1 open ING account    --
			
			rule = new CountForValueRule(this);
			RuleHelper.putParameterValue(rule, CountForValueRule.REQUIRED_FIRST_PARAMETER_NODE_LIST, summaries);
			RuleHelper.putParameterValue(rule, CountForValueRule.REQUIRED_SECOND_PARAMETER_NODE_NAME_IN_LIST, RuleConstants.XML_EL_STATUS);
			RuleHelper.putParameterValue(rule, CountForValueRule.REQUIRED_THIRD_PARAMETER_REGULAR_EXPRESSION, "Open");
			RuleHelper.putParameterValue(rule, CountForValueRule.REQUIRED_FOURTH_PARAMETER_COUNT, new Integer(1));
			
			result = engine.assess(rule);	
			
			if( ! RuleHelper.resultAssert(true, result, comments+"060 Rule 06: ", "Must have at least 1 open ING account") ) return;

			//-- Rule 7 : No Cif level restrictions    --
			rule = new CountForValueRule(this);
			RuleHelper.putParameterValue(rule, CountForValueRule.REQUIRED_FIRST_PARAMETER_NODE_LIST, new RuleNodePathName(SessionNodePathMap.PATH_DETAIL_RESTRICTION+suffix));
			RuleHelper.putParameterValue(rule, CountForValueRule.REQUIRED_SECOND_PARAMETER_NODE_NAME_IN_LIST, RuleConstants.XML_EL_RESTRICTION_CODE);
			RuleHelper.putParameterValue(rule, CountForValueRule.REQUIRED_THIRD_PARAMETER_REGULAR_EXPRESSION, ".*");
			RuleHelper.putParameterValue(rule, CountForValueRule.REQUIRED_FOURTH_PARAMETER_COUNT, new Integer(0));
			RuleHelper.putParameterValue(rule, CountForValueRule.OPTIONAL_PARAMETER_OPERATOR, CountForValueRule.OPTIONAL_OPERATOR_VALUE_EQUALS);
			
			result = engine.assess(rule);	
			
			if(! RuleHelper.resultAssert(true, result, comments+"070 Rule 07: ", "No Cif level restrictions") ) return;

			//-- Rule 8 : No Account level restrictions    --
			rule = new CountForValueRule(this);
			RuleHelper.putParameterValue(rule, CountForValueRule.REQUIRED_FIRST_PARAMETER_NODE_LIST, summaries);
			RuleHelper.putParameterValue(rule, CountForValueRule.REQUIRED_SECOND_PARAMETER_NODE_NAME_IN_LIST, RuleConstants.XML_EL_RESTRICTION_CODE);
			RuleHelper.putParameterValue(rule, CountForValueRule.REQUIRED_THIRD_PARAMETER_REGULAR_EXPRESSION, ".*");
			RuleHelper.putParameterValue(rule, CountForValueRule.REQUIRED_FOURTH_PARAMETER_COUNT, new Integer(0));
			RuleHelper.putParameterValue(rule, CountForValueRule.OPTIONAL_PARAMETER_OPERATOR, CountForValueRule.OPTIONAL_OPERATOR_VALUE_EQUALS);
			
			result = engine.assess(rule);	
			
			if(! RuleHelper.resultAssert(true, result, comments+"080 Rule 08: ", "No Account level restrictions") ) return;

			//-- Rule 9 : Not a FAS customer    --
			rule = new CountForValueRule(this);
			RuleHelper.putParameterValue(rule, CountForValueRule.REQUIRED_FIRST_PARAMETER_NODE_LIST, new RuleNodePathName(SessionNodePathMap.PATH_DETAIL_FAS_AGENT+suffix));
			RuleHelper.putParameterValue(rule, CountForValueRule.REQUIRED_SECOND_PARAMETER_NODE_NAME_IN_LIST, RuleConstants.XML_EL_FAS_BUSINESS_NAME);
			RuleHelper.putParameterValue(rule, CountForValueRule.REQUIRED_THIRD_PARAMETER_REGULAR_EXPRESSION, ".*");
			RuleHelper.putParameterValue(rule, CountForValueRule.REQUIRED_FOURTH_PARAMETER_COUNT, new Integer(0));
			RuleHelper.putParameterValue(rule, CountForValueRule.OPTIONAL_PARAMETER_OPERATOR, CountForValueRule.OPTIONAL_OPERATOR_VALUE_EQUALS);
			
			result = engine.assess(rule);	
			
			if(! RuleHelper.resultAssert(true, result, comments+"090 Rule 09: ", "Not a FAS customer") ) return;

			
			//Passed them all !
			log.finest("999 - Done - "+ result.isOk()+".");		
		}
	
		/**
		 * 
		  */	
		void reset(){
	
			Map fieldMap = getFieldMap();
			fieldMap.clear();
			
			fieldMap.put(OPTIONAL_PARAMETER_SECONDARY_CUSTOMER, DEFAULT_SECONDARY_CUSTOMER);
			fieldMap.put(OPTIONAL_PARAMETER_RELATED_CUSTOMER, DEFAULT_RELATED_CUSTOMER);
		
			getResult().setIsOk(false);
		
		 }

		private boolean validateRequiredParameterValues(){
			RuleResult result = getResult();
		
			Object value;
			String paramName;
		
			//Get the required parameter list 
			ArrayList parameterNames = (ArrayList) RuleHelper.getSystemData(this, RuleConstants.SYSTEM_PARAM_REQUIRED_LIST);
		
			//Required Parameter 1 : REQUIRED_FIRST_PARAMETER_TEXT
			paramName = (String) parameterNames.get(0);
			value = RuleHelper.getParameterValue( this, paramName );
			if(value == null){
				result.setCode(RuleConstants.ERROR_CODE_INVALID_VALUE);
				result.setDescription("Null value. Value for parameter name("+paramName+") must resolve to a String.");
				result.setIsOk(false);
				return false;
			} else {
				if( ! RuleParameterHelper.validateContextNode( this, paramName, value ) ) return false;
			}
		
			result.setIsOk(true);
			return true;
		}
	private boolean validateOptionalParameters(){
		RuleResult result = getResult();
		
		Object value;		
		
		//OPTIONAL_PARAMETER_SECONDARY_CUSTOMER
		value = RuleHelper.getParameterValue( this, OPTIONAL_PARAMETER_SECONDARY_CUSTOMER );
		if(value != null){
			if( ! RuleParameterHelper.validateString( this, OPTIONAL_PARAMETER_SECONDARY_CUSTOMER, value) ) return false;
			//Make sure value is true or false
			String text = (String) fieldMap.get(OPTIONAL_PARAMETER_SECONDARY_CUSTOMER);
			if( RuleConstants.TRUE_STRING.equals(text) || RuleConstants.FALSE_STRING.equals(text) ){
				;
			}else if( RuleConstants.TRUE.equals(text) ){
				fieldMap.put(OPTIONAL_PARAMETER_SECONDARY_CUSTOMER, RuleConstants.TRUE_STRING);
			}else if( RuleConstants.FALSE.equals(text) ){
				fieldMap.put(OPTIONAL_PARAMETER_SECONDARY_CUSTOMER, RuleConstants.FALSE_STRING);
			}else {
				result.setCode(RuleConstants.ERROR_CODE_INVALID_VALUE);
				result.setDescription("Value for optional parameter secondary customer must evaluate to true or false. Value("+text+") is invalid.");
				result.setIsOk(false);
				return false;
			}
		}

		//OPTIONAL_PARAMETER_RELATED_CUSTOMER
		value = RuleHelper.getParameterValue( this, OPTIONAL_PARAMETER_RELATED_CUSTOMER );
		if(value != null){
			if( ! RuleParameterHelper.validateString( this, OPTIONAL_PARAMETER_RELATED_CUSTOMER, value) ) return false;
		}

		// OPTIONAL_PARAMETER_LINKS 
		value = RuleHelper.getParameterValue( this, OPTIONAL_PARAMETER_LINKS );
		if(value != null){
			if( ! RuleParameterHelper.validateNodeList( this, OPTIONAL_PARAMETER_LINKS, value ) ) return false;			
		}
		
		// OPTIONAL_PARAMETER_SUMMARIES
		value = RuleHelper.getParameterValue( this, OPTIONAL_PARAMETER_SUMMARIES );
		if(value != null){
			if( ! RuleParameterHelper.validateNodeList( this, OPTIONAL_PARAMETER_SUMMARIES, value ) ) return false;			
		}
		
		// done !
		result.setIsOk(true);
		return true;
	}
	
}