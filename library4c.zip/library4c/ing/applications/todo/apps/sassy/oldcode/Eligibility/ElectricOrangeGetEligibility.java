package com.ingdirect.dg.service;

import com.ingdirect.dg.xmlbind.AutoMarshallGatewayMessage;
import com.ingdirect.dg.xmlbind.XMLBindException;
import com.ingdirect.dg.xmlbind.data.ElectricOrangeEligibilityResp;
import com.ingdirect.dg.xmlbind.data.CustId;
import com.ingdirect.dg.util.Operator;
import com.ingdirect.dg.util.DgwRequestHelper;
import com.ingdirect.dg.client.DirectGatewayClient;
import com.ingdirect.dg.DirectGatewayException;
import com.ingdirect.util.rules.RuleEngineImpl;
import com.ingdirect.util.rules.Rule;
import com.ingdirect.util.rules.ElectricOrangeEligibilityRule;
import com.ingdirect.util.rules.RuleResult;
import com.ingdirect.util.rules.RuleConstants;
import com.ingdirect.util.xml.SimpleElement;
import com.ingdirect.util.xml.SimpleBooleanElement;

import java.util.logging.Logger;
import java.util.logging.Level;
import java.util.Map;
import java.util.HashMap;

import org.w3c.dom.Element;

//   Standard Java
//   Third Party
//   ING DIRECT
public class ElectricOrangeGetEligibility  extends SimpleAbstractService{
	//** The name of the class and the name used by the logger. */
	final String CLASS_ID = ElectricOrangeGetEligibility.class.getName();
	final String logName = CLASS_ID;

	//** Standard Logger  */
	Logger log = Logger.getLogger(logName);

	//** DG Service Names  */
	private static final String DGW_SERVICE_NAME = "ElectricOrangeGetEligibility";

	//** DG Service Names  */
	public static final String DGW_TRAN_PRIMARY = DGW_SERVICE_NAME;
	public static final String DGW_TRAN_RELATED = "RelatedEoEligibility";

	private final String XML_ELIGIBILITY = "Eligibility";
	public static final String TYPE_ELECTRIC_ORANGE = RuleConstants.APP_EO_ACCOUNT_TYPE_NAME;
	
	/* (non-Javadoc)
	 * @see com.ingdirect.dg.service.SimpleAbstractService#configBaseName()
	 */
	protected String configBaseName() {
		return DGW_SERVICE_NAME;
	}
	
	/* (non-Javadoc)
	 * @see com.ingdirect.dg.service.GatewayService#execute(java.lang.String, java.lang.String, java.util.Map, java.util.Map)
	 */
	public String execute(String transaction, 
	                      String request, 
						  Map requestOptions, 
						  Map responseOptions
	)
		throws DirectGatewayException
	{
		try {
			if(log.isLoggable(Level.FINEST)) log.finest( request );

			// -- Unmarshall the GatewayMessage request to an XmlData request --
			AutoMarshallGatewayMessage reqGwMsg = new AutoMarshallGatewayMessage();
			unmarshall(request, requestOptions, reqGwMsg);
			CustId reqId = new CustId();
			reqGwMsg.fillBodyData(reqId);
			
			Operator operator = Operator.fromGatewayMessage(reqGwMsg);
			
			// -- Obtain the response from the request --
			ElectricOrangeEligibilityResp response = processService(transaction, reqId, operator, requestOptions, reqGwMsg);
			
			// -- Marshall the XmlData response to a GatewayMessage response --
			AutoMarshallGatewayMessage gwMsg = new AutoMarshallGatewayMessage();
			gwMsg.initNew();
			gwMsg.setResponse();
			gwMsg.setResponseType(AutoMarshallGatewayMessage.RESTYPE_RESULT);			
			gwMsg.setBodyData( response, XML_ELIGIBILITY ); 
			String responseString =  marshall(gwMsg, responseOptions);

			// -- finest --
			if(log.isLoggable(Level.FINEST)) log.finest( responseString );
			
			// -- done --
			return responseString;
		} catch(Exception err) {
			// Superclass takes care of this, including logging.
			return generateError(err, responseOptions);
		}
	}
	
	private ElectricOrangeEligibilityResp processService(String transaction, CustId reqId, Operator operator, Map requestOptions, AutoMarshallGatewayMessage reqGwMsg) 
		throws  DirectGatewayException, XMLBindException
	{
		String cif;
	
		try {
			cif = reqId.CIF.toString();
			Integer.parseInt( cif );
		} catch(Exception err) {
			// could not convert CIF to string (or it was absent)
			throw new DirectGatewayException("Invalid request: must contain valid CIF. OperatorId("+operator.getOperatorId()+")" );
		}
		// DGW_TRAN_PRIMARY   
		
		//-- Get the data Asynchronously --
		Object handleCustDetail = null;
		Element gwDetailElement = null;
		String responseCustDetail = null;
		String requestXml;
		
		if(DGW_TRAN_RELATED.equals(transaction)){
			requestXml = DgwRequestHelper.getRequestForCustDetailByCif(CustGetDetail.TRAN_RELATED_DETAIL, cif, null, reqGwMsg);
			handleCustDetail = DirectGatewayClient.invokeAsync(requestXml, requestOptions);
		} else {
			gwDetailElement = (Element) requestOptions.get(CustGetDetail.ARG_DETAIL_ELEMENT);
			if( gwDetailElement == null ){
				throw new DirectGatewayException("Invalid request: must contain detail Element in requestMap for transaction ("+DGW_TRAN_PRIMARY+"). OperatorId("+operator.getOperatorId()+")" );
			}
		}
		requestXml = DgwRequestHelper.getRequestForCustSummariesByCif(cif, reqGwMsg);
		Object handleCustSummaries = DirectGatewayClient.invokeAsync(requestXml, requestOptions);
		
		requestXml = DgwRequestHelper.getRequestForExternalLinksByCif(cif, reqGwMsg);
		Object handleCustExternalLinks = DirectGatewayClient.invokeAsync(requestXml, requestOptions);
		
		//-- Get the response for the data --
		if(DGW_TRAN_RELATED.equals(transaction)){
			responseCustDetail = DirectGatewayClient.completeAsync(handleCustDetail, requestOptions);
		}
		String responseCustSummaries = DirectGatewayClient.completeAsync(handleCustSummaries, requestOptions);
		String responseCustExternalLinks = DirectGatewayClient.completeAsync(handleCustExternalLinks, requestOptions);
		
		//-- unmarshall the response for the data - DirectGatewayException is thrown for errors --
		if(DGW_TRAN_RELATED.equals(transaction)){
			gwDetailElement = DgwRequestHelper.unmarshallResponse(responseCustDetail, null, validateXml);
		}
		Element gwLinksList = DgwRequestHelper.unmarshallResponse(responseCustExternalLinks, null, validateXml);
		Element gwSummariesList = DgwRequestHelper.unmarshallResponse(responseCustSummaries, null, validateXml);		
		
		//-- Run the ElectricOrangeEligibilityRule --
		Map namedParamsMap = new HashMap();
		RuleEngineImpl ruleEngine = new RuleEngineImpl();
		Rule rule = new ElectricOrangeEligibilityRule();
		
		namedParamsMap.put( ElectricOrangeEligibilityRule.REQUIRED_FIRST_PARAMETER_CONTEXT_NODE, gwDetailElement );
		namedParamsMap.put( ElectricOrangeEligibilityRule.OPTIONAL_PARAMETER_LINKS, gwLinksList );
		namedParamsMap.put( ElectricOrangeEligibilityRule.OPTIONAL_PARAMETER_SUMMARIES, gwSummariesList );
		namedParamsMap.put( ElectricOrangeEligibilityRule.OPTIONAL_STANDARD_PARAMETER_COMMENTS,  "cif("+cif+")" );
		
		RuleResult result = ruleEngine.assess(rule, namedParamsMap, false);		
		
		boolean ok = result.isOk();

		if(log.isLoggable(Level.FINEST) ) log.finest("900 - EO Eligibility for CIF("+cif+") OK("+ok+").");
		
		//-- prepare the response --
		ElectricOrangeEligibilityResp response = new ElectricOrangeEligibilityResp();
		response.Eligibility = new ElectricOrangeEligibilityResp.Eligibility();
		response.Eligibility.EligibilityType = new SimpleElement(TYPE_ELECTRIC_ORANGE);
		response.Eligibility.Eligible = new SimpleBooleanElement(ok);
		
		//-- done --
		return response;
	}

} //~
