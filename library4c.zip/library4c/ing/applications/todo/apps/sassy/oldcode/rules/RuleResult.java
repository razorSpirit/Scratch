package com.ingdirect.util.rules;

import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;

/**
 * @version $Revision: 214 $
 */
public class RuleResult {

	Map errorMap = new HashMap();
	Map dataMap = new HashMap();
	String description;
	String code;
	boolean ok = false;
	
	RuleResult(){super();}
	
	RuleResult(boolean ok){
		super();
		setIsOk(ok);
	}
	
	public boolean isOk() { return ok && ! hasErrors(); }
	public boolean getIsOk() { return isOk(); }
	void setIsOk(boolean isOk) { 
		ok = isOk;
		if(ok){
			errorMap.clear();
		}
	}

	public String getDescription() { return description; }
	public void setDescription(String description) { this.description = description; }

	public String getCode() { return code; }
	public void setCode(String code) { this.code = code; }
	
	public Map getErrors() { return errorMap;}
	public Object getError(Object key) { return errorMap.get(key); }
	public void putError(Object key, Object value) { errorMap.put(key, value); }
	
	        
	public Map getData() { return dataMap; }
	public Object getData(Object key) { return dataMap.get(key); }
	public void putData(Object key, Object value) { dataMap.put(key, value); }
	
	public boolean hasErrors() {   return ! errorMap.isEmpty(); }
	public boolean hasData() {   return ! dataMap.isEmpty(); }
	
	public void reset() {
		errorMap.clear();
		dataMap.clear();
		description = null;
		code = null;
		ok = false;
	}
	
	public String toString() {
		StringBuffer sb = new StringBuffer();
		
		sb.append("\nisApplicable : "+ getIsOk() );
		sb.append("\nhasErrors : "+ hasErrors() );
		if( hasErrors() ){
			String key;
			RuleError error;			
			for(Iterator it=errorMap.keySet().iterator();it.hasNext();){
				key=(String) it.next();
				error= (RuleError) errorMap.get(key);
				sb.append("\n========= Error key("+key+") =======");
				sb.append("\n"+error.toString());
			}
		}
		
		return sb.toString();		
	}	
}
