package com.ingdirect.dg.util;

// Standard Java 
import java.util.logging.Logger;
//   Third Party
// ING Direct
import com.ingdirect.dg.xmlbind.data.CustDetail;
import com.ingdirect.util.xml.SimpleElement;
import com.ingdirect.util.xml.SimpleBooleanElement;

/**
 * This class determines the customer's eligibility for Electric Orange.
 *  
 * @version $Revision: $
 */
public class EligibilityForEORANGE extends EligibilityForProduct{
	/**
	 * The ClassId for this Class
	 */ 
	private final static String CLASS_ID = EligibilityForEORANGE.class.getName();
	/**
	 * The logName given to the logger
	 */ 
	private final static String LOG_NAME = CLASS_ID;
	/**
	 * The logger
	 */ 
	private final static Logger log = Logger.getLogger(LOG_NAME);
	
	public static final String PRODUCT_TYPE = "EORANGE";

	/**
	 * 
	 * @param cif - Customer's CIF.
	 * @return CustDetail.Eligibility
	 */ 
	public CustDetail.Eligibility getEligibility(String cif) {
		//TODO ajb : add MRPC to get Eligibility
		log.finest("Start collecting "+PRODUCT_TYPE+" eligibility.");

		CustDetail.Eligibility eligibility = new CustDetail.Eligibility();
		eligibility.EligibilityType = new SimpleElement(PRODUCT_TYPE);
		eligibility.Eligible = new SimpleBooleanElement(true);
		
		log.finest("Finished collecting "+PRODUCT_TYPE+" eligibility.");
		return eligibility;
	}
	
} //~
