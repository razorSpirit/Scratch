package com.ingdirect.util.rules;

//	Standard Java
import java.util.logging.Logger;
import java.util.Map;
import java.util.ArrayList;
import java.util.Iterator;
//   Third Party
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
//   ING DIRECT
import com.ingdirect.util.xml.XmlHelper;

/**
 * This class is a Rule which must be ran using a RuleEngine according to 
 * the rule framework. @see RuleEngineImpl, package.html
 * 
 * The <I>NodeListHasValuesRule</I> determines whether <U>all</U> the values specified in the
 * required values <U>map</U> are found in the node list. The keys in the map are used to 
 * locate the cooresponding node with the key name in the nodelist, if found, a match using
 * a <U>regular expression</U> is performed.  If at anytime a node is not found or a regular expression
 * does not match the value in the node, then the test fails.  The test will pass if all Nodes are
 * found and their values match the corresponding <U>regular expressions</U>.
 * 
 *
 * <B><U>Parameter Requirements:</U></B>
 * 
 * required : node list, values map
 * 
 * optional : no options
 *
 * defaults : no default other then the standard defaults
 * 
 * <B><U>Parameter typing:</U></B>
 *                                
 * The following types - NodeList, RuleNodePathName, RuleNodePath, RuleNodeLocation
 * can be applied to parameters - node list
 * 
 * The following types - Map, Node, RuleNodePathName, RuleNodePath, RuleNodeLocation
 * can be applied to parameter values map
 * 
 * <B><U>Notes:</U></B>
 *    1. The values map has keys which are to match the corresponding Node names
 *       in the node list.  The values in the values map are regular expressions.
 *     
 * @author abrida
 * @version $Revision: 409 $
 */
public class NodeListHasValuesRule extends Rule {

	/* Required Parameter Names */
	public final static String REQUIRED_FIRST_PARAMETER_NODE_LIST = RuleConstants.PARAM_NAME_NODE_LIST;
	public final static String REQUIRED_SECOND_PARAMETER_VALUES_MAP = RuleConstants.PARAM_NAME_VALUES_MAP;
	
	/* -- Standard Optional Parameter Names -- */
	public final static String OPTIONAL_STANDARD_PARAMETER_COMMENTS = RuleConstants.PARAM_NAME_COMMENTS;
	public final static String OPTIONAL_STANDARD_PARAMETER_CONTEXT_NODE = RuleConstants.PARAM_NAME_CONTEXT_NODE;
	public final static String OPTIONAL_STANDARD_PARAMETER_NODE_LOCATION = RuleConstants.PARAM_NAME_NODE_LOCATION;
	
	/**
	 * Constructor : default
	 */ 
	public NodeListHasValuesRule() { super(); }
	
	/**
	 * Constructor with engine parameter
	 * @param alwaysAssessRule - boolean flag that tells the <i>RuleEngineImpl<i>
	 *        that this rule will always be ran, even if it has run already.
	 *        When false, the <i>RuleEngineImpl<i> will check to see if this
	 *        rule ran successfully, and if so, it will <i>NOT</i> run this
	 *        rule and return a successful result, otherwise, the rule will be
	 *        ran.
	 */	
	NodeListHasValuesRule( boolean alwaysAssessRule){
		 super( alwaysAssessRule); 
		}
	
	/**
	 * This constructor must be used to create this rule from within 
	 * another rule.
	 * 
	 * @param rule - the rule from which this rule is being created.
	 */	
	NodeListHasValuesRule( Rule rule){
		 super( rule );
	}
		
	/**	
	 * Called by the contructor to define the 
	 * id of the rule, the log name, and the required and
	 * optional parameters.
	 */
	void init(){
		CLASS_ID = CountForValueRule.class.getName();
		logName = CLASS_ID;
		log = Logger.getLogger(logName);
		
		//Always assess this rule
		this.setAlwaysAssessRule(true);
		
		String[][] myParameterNames = { { REQUIRED_FIRST_PARAMETER_NODE_LIST},
										{ REQUIRED_SECOND_PARAMETER_VALUES_MAP},
		                              };
		
		this.setRequiredParameters(myParameterNames);
		
		String [][] myOptionalParameterNames = { {},
											  };
		this.setOptionalParameters(myOptionalParameterNames);
	}

	/**
	 * Called by the RuleEngine to validate the parameter values for this rule.
	 * 
	 * @return true  - if all the parameters are valid
	 *         false - if any of the parameters are invalid
	 */ 
	boolean checkParametersValues(){
		
		//Establish the result - false
		RuleResult result = getResult();
		
		//Validate the optional parameters
		//if( ! validateOptionalParameters() ) return false;
		
		//Validate the required parameter values
		if( ! validateRequiredParameterValues() ) return false;
		
		//done
	    return result.isOk();
   }
	
	/**
	 * Called by the RuleEngine to apply the rule. 
	 * The RuleResult object in the RuleEngine is used to
	 * report the result.
	 * 
	 */
	void applyRule(){
		
		RuleResult result = getResult();
		result.setIsOk(true);
		Map fieldMap = getFieldMap();
		
		//-- Get the required parameters from the fieldMap      --
		NodeList nodeList = (NodeList) fieldMap.get(REQUIRED_FIRST_PARAMETER_NODE_LIST);
		Map valuesMap = (Map) fieldMap.get(REQUIRED_SECOND_PARAMETER_VALUES_MAP);
		Iterator valuesIterator;
		
		//-- Calculate the number of times the value is found -- 
		
		int countNodes = nodeList.getLength();
		int countValues = valuesMap.size();
		int countFound;
		boolean ok = false;		
		String regex;
		String nodeName;
		Node node;
		Element el;
		String text;

		for(int i=0; i<countNodes; i++){
			el = (Element) nodeList.item(i);
			valuesIterator = valuesMap.keySet().iterator();
			countFound = 0;
			while( valuesIterator.hasNext() ){
				nodeName = (String) valuesIterator.next();
				regex = (String) valuesMap.get(nodeName);
				node = el.getElementsByTagName(nodeName).item(0);
				if(node != null){
					text=XmlHelper.getNodeText(node);
					if(text.matches(regex)){
						++countFound;
					} else {
						break;
					}
				} else {
					break;
				}
			}
			if(countValues == countFound){
				ok = true;
			}
			
		}

		//-- done --
		result.setIsOk(ok);
		
		log.finest("999 - Done - "+ result.isOk()+".");		
	}
	
	/**
	 * The fieldMap taken from the Rule base class is reset
	 * with the optional and default values.  The fieldMap is 
	 * used to hold the values rendered from the passed parameters.
	 * 
 	 */	
	void reset(){	
		Map fieldMap = getFieldMap();
		fieldMap.clear();

		getResult().setIsOk(false);		
	 }

	/**
	 * This method validates the required parameters and places their derived
	 * values in the Rules fieldMap.
	 * @return
	 */ 
	private boolean validateRequiredParameterValues(){
		RuleResult result = getResult();
		
		Object value;
		String paramName;
		
		//Get the required parameter list 
		ArrayList parameterNames = (ArrayList) RuleHelper.getSystemData(this, RuleConstants.SYSTEM_PARAM_REQUIRED_LIST);

		//Required Parameter 1 : REQUIRED_FIRST_PARAMETER_NODE_LIST
		paramName = (String) parameterNames.get(0);
		value = RuleHelper.getParameterValue( this, paramName );
		if(value == null){
			result.setCode(RuleConstants.ERROR_CODE_INVALID_VALUE);
			result.setDescription("Null value. Value for parameter name("+paramName+") must resolve to a NodeList.");
			result.setIsOk(false);
			return false;
		} else {
			if( ! RuleParameterHelper.validateNodeList( this, paramName, value) ) return false;
		}

		//Required Parameter 2 : REQUIRED_SECOND_PARAMETER_VALUES_MAP
		paramName = (String) parameterNames.get(1);
		value = RuleHelper.getParameterValue( this, paramName );
		if(value == null){
			result.setCode(RuleConstants.ERROR_CODE_INVALID_VALUE);
			result.setDescription("Null value. Value for parameter name("+paramName+") must resolve to a Map.");
			result.setIsOk(false);
			return false;
		} else {
			if( ! RuleParameterHelper.validateMap( this, paramName, value) ) return false;
		}


		// Done !
		result.setIsOk(true);
		return true;
	}

} //~
