package com.ingdirect.util.rules;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.logging.Logger;

/**
 * @version $Revision: 323 $
 */
public class RuleEngineImpl implements RuleEngine{
	// $NoKeywords $
	private Map m_Successes = new HashMap();
	private final static String CLASS_ID = RuleEngineImpl.class.getName();
	private final static String LOG_NAME = CLASS_ID;
	private final static Logger log = Logger.getLogger(LOG_NAME);
	
	private Map dataMap = new HashMap();
	private Map activeDataMap = dataMap; 
	
	private Map successMap = new HashMap();
	private Map activeSuccessMap = successMap; 
	
	private List rules_Path = new ArrayList();
	
	private int ruleCount = 0;
	
	private RuleResult result;
	
	public String getName() { return CLASS_ID;}

	public String toString(){   return super.toString(); }
	
	/**
	 * Called outside of rule
	 * @param rule
	 * @param namedParams
	 * @param reuseRules
	 * @return
	 */ 
	public RuleResult assess(Rule rule, Map namedParams, boolean reuseRules){
		log.finest("000 - Entered. rule("+rule.getName()+")");
		
		result = new RuleResult();

		try{
			//Other Rules cannot call this method
			//they must call assess(Rule rule)
			if(ruleCount != 0 ){
				result.setCode(RuleConstants.ERROR_CODE_INVALID_METHOD_CALL);
				result.setDescription("005 -Illegal method call - already running a rule ruleCount("+ruleCount+")");
				log.finest( result.getDescription() );
				return result;
			}			
			
			//if reusing rules then Check if this rule already ran successfully.
			if(reuseRules && m_Successes.containsKey( rule.getName()) ){
				result = new RuleResult(true);
				result.setCode(RuleConstants.RETURN_CODE_ASSESSED_ALREADY);
				log.finest("010 - DONE - ("+RuleConstants.RETURN_CODE_ASSESSED_ALREADY+") .");
				return result;
			}
			
			//Reuse accumulated information 
			if( reuseRules ){
				activeSuccessMap = successMap;
				activeDataMap = dataMap;
			} else {
				activeSuccessMap = new HashMap();
				activeDataMap = new HashMap();
			}
			
			rules_Path = new ArrayList();
			
			//Copy the passed parameters
			activeDataMap.putAll(namedParams);
			
			//Assess the rule
				log.finest("030 - assessing rule.");
				result = assess(rule);	
		
		} catch(Exception exception){
			RuleError error = new RuleError();
			error.setCode(RuleConstants.ERROR_CODE_EXCEPTION);
			error.setDescription("Exception encountered.");
			error.setException(exception);
			result.getErrors().put(CLASS_ID+":"+RuleConstants.ERROR_CODE_EXCEPTION, exception);			
			log.severe("990 - "+error.toString());
		} finally{
			ruleCount = 0;				
		}

		//Done 
		log.finest("999 - Done - OK("+result.isOk()+").");
		
		return result;
	}
	
	/**
	 * Called by rules
	 * @param rule
	 * @return
	 */ 
	public final RuleResult assess(Rule rule){
		log.finest("000 - Entered.");
		
		result.setIsOk(true);
		
		//count the number of rules
		ruleCount++;
		
		//Track rules ran
		rules_Path.add(rules_Path.size(), rule.getName() );
		
		//Should we always assess this rule ?
		if( rule.alwaysAssessRule() ){
			;
		} else {
			//Should we assess this rule again ?
			result = RuleHelper.hasRanAlready(rule);
			if( result.isOk() ){
				log.finest("015 - Done - "+RuleConstants.RETURN_CODE_ASSESSED_ALREADY+" .");
				return result;
			}
		}
		
		//allow rules to run other rules
		rule.setRuleEngine(this);
		rule.reset();
		
		/**
		 * 
		 * Add the required parameter(s) and check both required and
		 * optional parameter values.
 		 */ 
		if( RuleHelper.addNamedParametersList(rule, false) ){
			if( RuleHelper.addStandardOptions( rule ) ) {							
				rule.checkParametersValues();
			}
		}   
		
		//apply the rule if the Parameters are valid
		if( result.isOk() ){
			
			log.finest("010 - applying rule.");
			rule.applyRule();			
			log.finest("900 - Done - applying rule.");
			
			//track successes 
			if( result.isOk() ){
				getSuccessMap().put(getName(), null);
			}
			return result;
			
		} else {
			log.finest( "999 - Done - "+result.getDescription() );
			return result;
		}

	}
	
	public final Map getSuccessMap() {   return activeSuccessMap; } 
	public final Map getDataMap() {return activeDataMap; }
	
	public final int getRuleCount() { return ruleCount;}			
	
	public final RuleResult getResult(){ return result; }
	
} //~~
