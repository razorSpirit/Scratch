package com.ingdirect.util.rules;

//	Standard Java
import java.util.Map;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.logging.Logger;

//   Third Party

//   ING DIRECT
import com.ingdirect.util.DateUtil;

/**
 * This class is a Rule which must be ran using a RuleEngine according to 
 * the rule framework. @see RuleEngineImpl, package.html
 * 
 * The ageFromDateRule compares two ages using a comparison operator and
 * returns the result of this comparison.   
 * 
 * Two parameters are required, endDate and age.  The required age parameter is compared 
 * to a calculated age.  The calculated age is derived by subtracting the startDate from
 * the required endDate. The default startDate is the current date.
 *
 * <B><U>Parameter Requirements:</U></B>
 * 
 *  required : endDate, age
 *  optional : startDate, startDateFormat,
 *             endDateFormat, operator,
 *             useMilliseconds, ageUnitIsDays, *ageUnitIsYears
 *
 * defaults :  startDate is today's <I>date</I>
 *             startDateFormat, endDateFormat  is <I>YYYY-MM-DD</I>
 *             operator is <I>OPTIONAL_OPERATOR_VALUE_GREATER_THEN_OR_EQUAL</I> (>=)
 *             useMilliseconds is <I>FALSE_STRING</I>
 *             ageUnitIsYears
 * 
 * <B><U>Parameter typing:</U></B>
 *                                
 * These following types - String, Calendar, Node, RuleNodePathName, RuleNodePath, RuleNodeLocation
 * can be applied to parameters - endDate, startDate
 * 
 * The following types - String, Long, Node, RuleNodePathName, RuleNodePath, RuleNodeLocation
 * can be applied to parameters - age
 * 
 * The following types - String, Node, RuleNodePathName, RuleNodePath, RuleNodeLocation
 * can be applied to parameters - endDateFormat, startDateFormat, operator, useMilliseconds
 * 
 * The following parameters have NO types - ageUnitIsDays, ageUnitIsYears
 * 
 * <B><U>Notes:</U></B>
 *    1. If dates are expressed as Strings then a ~DateFormat will be used to evaluate the date.  The
 *       default format is YYYY-MM-DD.
 * 
 *    2. The presence of the parameter ageUnitIsDays will use days for calculating the age.
 *
 *     
 * @author abrida
 * @version $Revision: 409 $
 */

public class AgeFromDateRule extends Rule{
	
	/* Required Parameter Names */
	public final static String REQUIRED_FIRST_PARAMETER_START_DATE = RuleConstants.PARAM_NAME_START_DATE;
	public final static String REQUIRED_SECOND_PARAMETER_AGE = RuleConstants.PARAM_NAME_AGE;

	/* Optional Parameter Names */
	public final static String OPTIONAL_PARAMETER_AGE_UNIT = RuleConstants.PARAM_NAME_AGE_UNITS;

	public static final String OPTIONAL_PARAMETER_END_DATE = RuleConstants.PARAM_NAME_END_DATE;
	public static final String OPTIONAL_PARAMETER_END_DATE_FORMAT = RuleConstants.PARAM_NAME_END_DATE_FORMAT;

	public static final String OPTIONAL_PARAMETER_START_DATE_FORMAT = RuleConstants.PARAM_NAME_START_DATE_FORMAT;
	
	public final static String OPTIONAL_PARAMETER_OPERATOR = RuleConstants.PARAM_NAME_OPERATOR;

	public final static String OPTIONAL_PARAMETER_USE_MILLISECONDS = RuleConstants.PARAM_NAME_USE_MILLISECONDS;
	
	/* -- Standard Optional Parameter Names -- */
	public final static String OPTIONAL_STANDARD_PARAMETER_COMMENTS = RuleConstants.PARAM_NAME_COMMENTS;
	public final static String OPTIONAL_STANDARD_PARAMETER_CONTEXT_NODE = RuleConstants.PARAM_NAME_CONTEXT_NODE;
	public final static String OPTIONAL_STANDARD_PARAMETER_NODE_LOCATION = RuleConstants.PARAM_NAME_NODE_LOCATION;
	
	/* Optional Values */
	public final static String OPTIONAL_OPERATOR_VALUE_EQUALS = RuleConstants.OPERATOR_EQUALS;
	public final static String OPTIONAL_OPERATOR_VALUE_GREATER_THEN = RuleConstants.OPERATOR_GREATER_THEN;
	public final static String OPTIONAL_OPERATOR_VALUE_GREATER_THEN_OR_EQUAL = RuleConstants.OPERATOR_GREATER_THEN_OR_EQUAL;	
	public final static String OPTIONAL_OPERATOR_VALUE_LESS_THEN = RuleConstants.OPERATOR_LESS_THEN;
	public final static String OPTIONAL_OPERATOR_VALUE_LESS_THEN_OR_EQUAL = RuleConstants.OPERATOR_LESS_THEN_OR_EQUAL;	
	public final static String OPTIONAL_OPERATOR_VALUE_NOT_EQUALS = RuleConstants.OPERATOR_NOT_EQUALS;
	
	/* Default Values */
	public final String DEFAULT_DATE_FORMAT = RuleConstants.DEFAULT_DATE_FORMAT;	
	public final String DEFAULT_OPERATOR = OPTIONAL_OPERATOR_VALUE_GREATER_THEN_OR_EQUAL;	
	public final Calendar DEFAULT_END_DATE = DateUtil.nowCalendar();	
	public final String DEFAULT_USE_MILLISECONDS = RuleConstants.FALSE_STRING;
	public final String DEFAULT_AGE_UNITS = RuleConstants.UNIT_YEARS;
	
	/* Misc */
	//private final DateFormat dateFormat =
	//            DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
	private final int ONE_SECOND_IN_MILLIS = 1000;
	private final int ONE_HOUR_IN_SECONDS = 60*60;
	private final int ONE_YEAR_IN_DAYS= 24*365;
	private final int ONE_DAY_IN_HOURS = 24;
	
	/**
	 * Default Constructor.
	 */ 
	public AgeFromDateRule() { super(); }
	
	/**
	 * Constructor with engine parameter
	 * @param alwaysAssessRule - boolean flag that tells the <i>RuleEngineImpl<i>
	 *        that this rule will always be ran, even if it has run already.
	 *        When false, the <i>RuleEngineImpl<i> will check to see if this
	 *        rule ran successfully, and if so, it will <i>NOT</i> run this
	 *        rule and return a successful result, otherwise, the rule will be
	 *        ran.
	 */	
	AgeFromDateRule( boolean alwaysAssessRule){
		 super( alwaysAssessRule); 
	}

	/**
	 * This constructor must be used to create this rule from within 
	 * another rule.
	 * 
	 * @param rule - the rule from which this rule is being created.
	 */ 
	AgeFromDateRule( Rule rule){
		 super();
		this.setRuleEngine( rule.getRuleEngine() );
	}
	
	/**	
	 * Called by the contructor to define the 
	 * id of the rule, the log name, and the required and
	 * optional parameters.
	 */ 
	void init(){
		CLASS_ID = AgeFromDateRule.class.getName();
		logName = CLASS_ID;
		log = Logger.getLogger(logName);
		
		//Always assess this rule
		this.setAlwaysAssessRule(true);
		
		String[][] myParameterNames = { { REQUIRED_FIRST_PARAMETER_START_DATE},
		                                {REQUIRED_SECOND_PARAMETER_AGE},
		                              };
		
		this.setRequiredParameters(myParameterNames);
		
		String [][] myOptionalParameterNames = { {OPTIONAL_PARAMETER_AGE_UNIT},
												 {OPTIONAL_PARAMETER_END_DATE}, 
		                                         {OPTIONAL_PARAMETER_END_DATE_FORMAT},
		                                         {OPTIONAL_PARAMETER_START_DATE_FORMAT},
		                                         {OPTIONAL_PARAMETER_OPERATOR},
		                                         {OPTIONAL_PARAMETER_USE_MILLISECONDS},
											  };
		this.setOptionalParameters(myOptionalParameterNames);
	}

	/**
	 * Called by the RuleEngine to validate the parameter values for this rule.
	 * 
	 * @return true  - if all the parameters are valid
	 *         false - if any of the parameters are invalid
	 */ 
	boolean checkParametersValues(){
		
		//Establish the result - false
		RuleResult result = getResult();
		
		//Validate the optional parameters
		if( ! validateOptionalParameters() ) return false;
		
		//Validate the required parameter values
		if( ! validateRequiredParameterValues() ) return false;
		
		//done
	    return result.isOk();
   }

	/**
	 * Called by the RuleEngine to apply the rule. 
	 * The RuleResult object in the RuleEngine is used to
	 * report the result.
	 * 
	 */	
	void applyRule(){
		
		RuleResult result = getResult();
		result.setIsOk(true);
		Map fieldMap = getFieldMap();
		Long longValue;
		
		//-- Get the required parameters      --
		Calendar startDate = (Calendar) fieldMap.get(REQUIRED_FIRST_PARAMETER_START_DATE);
		longValue = (Long) fieldMap.get(REQUIRED_SECOND_PARAMETER_AGE);
		long requiredAge = longValue.longValue();
		
		//-- Get the optional parameters      --
		int operator = RuleConstants.OPERATORS_LIST.indexOf( fieldMap.get(OPTIONAL_PARAMETER_OPERATOR) );		
		Calendar endDate = (Calendar) fieldMap.get(OPTIONAL_PARAMETER_END_DATE);
		boolean ageIsYears = RuleConstants.UNIT_YEARS.equals((String) fieldMap.get(OPTIONAL_PARAMETER_AGE_UNIT));
		boolean useMilliseconds = RuleConstants.TRUE_STRING.equals((String) fieldMap.get(OPTIONAL_PARAMETER_USE_MILLISECONDS));
		
		//-- Calculate the age 
		long age;
		if( ageIsYears && !useMilliseconds){
			age = endDate.get(Calendar.YEAR) - startDate.get(Calendar.YEAR);			
		}else{
			long seconds  = (endDate.getTimeInMillis() - startDate.getTimeInMillis())/ONE_SECOND_IN_MILLIS;
			long hours = seconds/ONE_HOUR_IN_SECONDS;
			if(ageIsYears){
				age =  hours/ONE_YEAR_IN_DAYS;
			} else {
				age = hours/ONE_DAY_IN_HOURS ;
				if( ! useMilliseconds && age == 0){
					if(endDate.get(Calendar.DATE) - startDate.get(Calendar.DATE) == 1){
						age = 1;
					}
				}
			}
		}		
		
		//--Make the assessment
		
		boolean ok = false;

		switch(operator){
			
			case RuleConstants.INT_EQUALS:
				ok = (age == requiredAge); 
				break;
			case RuleConstants.INT_GREATER_THEN:
				ok = (age > requiredAge); 
				break;
			case RuleConstants.INT_GREATER_THEN_OR_EQUAL:
				ok = (age >= requiredAge); 
				break;
			case RuleConstants.INT_LESS_THEN:
				ok = (age < requiredAge); 
				break;
			case RuleConstants.INT_LESS_THEN_OR_EQUAL:
				ok = (age <= requiredAge); 
				break;
			case RuleConstants.INT_NOT_EQUALS:
				ok = (age != requiredAge); 
				break;
				
			default:				
				result.setCode(RuleConstants.ERROR_CODE_PROGRAMMER_ERROR);
				result.setDescription("900 - Programmer Error. operator("+operator+")");
				log.finest(result.getDescription());
				
		}		

		//done		
		result.setCode((String) RuleConstants.OPERATORS_LIST.get(operator));		
		result.setIsOk(ok);
		
		log.finest("999 - Done - "+ result.isOk()+".");		
	}
	
	/**
	 * The fieldMap taken from the Rule base class is reset
	 * with the optional and default values.  The fieldMap is 
	 * used to hold the values rendered from the passed parameters.
	 * 
 	 */	
	void reset(){
	
		Map fieldMap = getFieldMap();
		fieldMap.clear();
		fieldMap.put(OPTIONAL_PARAMETER_END_DATE, DEFAULT_END_DATE);
		fieldMap.put(OPTIONAL_PARAMETER_END_DATE_FORMAT, DEFAULT_DATE_FORMAT);		
		fieldMap.put(OPTIONAL_PARAMETER_START_DATE_FORMAT, DEFAULT_DATE_FORMAT);		
		fieldMap.put(OPTIONAL_PARAMETER_OPERATOR, DEFAULT_OPERATOR);		
		fieldMap.put(OPTIONAL_PARAMETER_USE_MILLISECONDS, DEFAULT_USE_MILLISECONDS);		
		fieldMap.put(OPTIONAL_PARAMETER_AGE_UNIT, DEFAULT_AGE_UNITS);
		
		getResult().setIsOk(false);
		
	 }

	/**
	 * This method validates the chosen optional parameters and places
	 * their values in the Rules FieldMap.  The RuleResult is used to
	 * report the success or failure to the RuleEngine.
	 * 
	 * @return  true  - validation passed
	 *          false - validation failed.
	 */ 
	private boolean validateOptionalParameters(){
		RuleResult result = getResult();
		
		Object value;
		
		//OPTIONAL_PARAMETER_AGE_UNIT
		value = RuleHelper.getParameterValue( this, OPTIONAL_PARAMETER_AGE_UNIT );
		if(value != null){
			if( RuleParameterHelper.validateString( this, OPTIONAL_PARAMETER_AGE_UNIT, value) ) {
				String ageUnit = (String) this.getFieldMap().get(OPTIONAL_PARAMETER_AGE_UNIT);
				if(RuleConstants.UNIT_YEARS.equals(ageUnit)){
					;
				} else if(RuleConstants.UNIT_DAYS.equals(ageUnit)){
					;
				} else {
					result.setIsOk(false);
					result.setCode(RuleConstants.ERROR_CODE_INVALID_VALUE);
					result.setDescription("Parameter("+OPTIONAL_PARAMETER_AGE_UNIT+") must be one of ("+RuleConstants.UNIT_DAYS
					                     + RuleConstants.UNIT_YEARS+")");
					return false;
				}
			}
			
		}		
		
		//OPTIONAL_PARAMETER_END_DATE_FORMAT
		value = RuleHelper.getParameterValue( this, OPTIONAL_PARAMETER_END_DATE_FORMAT );
		if(value != null){
			if( ! RuleParameterHelper.validateDateFormat( this, OPTIONAL_PARAMETER_END_DATE_FORMAT, value) ) return false;
		}

		//OPTIONAL_PARAMETER_END_DATE
		//MUST validate after FORMAT for chance to override default
		value = RuleHelper.getParameterValue( this, OPTIONAL_PARAMETER_END_DATE );
		if(value != null){
			String dateFormat = (String) this.getFieldMap().get(OPTIONAL_PARAMETER_END_DATE_FORMAT);
			if( ! RuleParameterHelper.validateCalendar( this, OPTIONAL_PARAMETER_END_DATE, value, dateFormat) ) return false;
		}		
		
		//OPTIONAL_PARAMETER_START_DATE_FORMAT
		value = RuleHelper.getParameterValue( this, OPTIONAL_PARAMETER_START_DATE_FORMAT );
		if(value != null){
			if( ! RuleParameterHelper.validateDateFormat( this, OPTIONAL_PARAMETER_START_DATE_FORMAT, value) ) return false;
		}

		//OPTIONAL_PARAMETER_OPERATOR
		value = RuleHelper.getParameterValue( this, OPTIONAL_PARAMETER_OPERATOR );
		if(value != null){
			if( ! RuleParameterHelper.validateOperator( this, OPTIONAL_PARAMETER_OPERATOR, value ) ) return false;
		}
		
		result.setIsOk(true);
		return true;
	}

	/**
	 * This method validates the required parameters and places their derived
	 * values in the Rules fieldMap.
	 * @return
	 */ 
	private boolean validateRequiredParameterValues(){
		RuleResult result = getResult();
		
		Object value;
		String paramName;
		
		//Get the required parameter list 
		ArrayList parameterNames = (ArrayList) RuleHelper.getSystemData(this, RuleConstants.SYSTEM_PARAM_REQUIRED_LIST);
		
		//Required Parameter 1 : REQUIRED_FIRST_PARAMETER_START_DATE
		paramName = (String) parameterNames.get(0);
		value = RuleHelper.getParameterValue( this, paramName );
		if(value != null){
			String dateFormat =  (String) this.getFieldMap().get(OPTIONAL_PARAMETER_START_DATE_FORMAT);
			if( ! RuleParameterHelper.validateCalendar( this, paramName, value, dateFormat) ) return false;
		}
		
		//Required Parameter 2 : REQUIRED_SECOND_PARAMETER_AGE
		paramName = (String) parameterNames.get(1);
		value = RuleHelper.getParameterValue( this, paramName );
		if(value != null){
			if( ! RuleParameterHelper.validateLong( this, paramName, value) ) return false;
		}
		
		result.setIsOk(true);
		return true;
	}
} //~