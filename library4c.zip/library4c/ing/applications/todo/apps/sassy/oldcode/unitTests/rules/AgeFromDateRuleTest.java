package com.ingdirect.util.rules;

import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import com.ingdirect.util.xml.ThreadLocalDocumentBuilder;

import java.io.FileInputStream;
import java.util.Map;
import java.util.HashMap;
import java.util.Calendar;
//  java -Djava.util.logging.config.file=C:\dev\ajb\misc\logging.properties test.rules.RuleTest C:\dev\dev_eo100_1\WESP\Source\Java\src\test\rules\info.xml

// Standard Java


public class AgeFromDateRuleTest extends TestCase {
	Document doc;
	static String id = AgeFromDateRuleTest.class.getName();
	
	RuleEngineImpl ruleEngine;
	RuleResult result;
	Map namedParamsMap;
	
	public AgeFromDateRuleTest(){
		super(id);
		
	}
	
	public void setUp() throws Exception {		
		doc = ThreadLocalDocumentBuilder.getDocumentBuilder(false).
		parse(new FileInputStream("unittest_data/infoForRules.xml"));
		
		result = new RuleResult();
		ruleEngine = new RuleEngineImpl();
		namedParamsMap = new HashMap();
		
	}
	
	public void tearDown() {
		doc = null;
		namedParamsMap=null;
		ruleEngine=null;
		result=null;
		
	}

	public static void main(String[] args) throws Exception {
		//to run as an application
		new junit.textui.TestRunner().doRun(new TestSuite(AgeFromDateRuleTest.class));
	
	}

	public void testAgeSuccess() {
		namedParamsMap.clear();
		result.reset();
		
		Rule rule = new AgeFromDateRule();

		//-- Test with Calendar Type --
		
		Calendar date = Calendar.getInstance();
		date.set(1956, 11, 7);

		namedParamsMap.put( AgeFromDateRule.REQUIRED_FIRST_PARAMETER_START_DATE, date);
		namedParamsMap.put( AgeFromDateRule.REQUIRED_SECOND_PARAMETER_AGE, "18");
		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), true);

		//--  Test with Context Node doc and PATH_DETAIL_DATE_OF_BIRTH  --
		namedParamsMap.put( AgeFromDateRule.REQUIRED_FIRST_PARAMETER_START_DATE, new RuleNodePathName(SessionNodePathMap.PATH_DETAIL_DATE_OF_BIRTH));
		namedParamsMap.put( AgeFromDateRule.REQUIRED_SECOND_PARAMETER_AGE, "18");
		namedParamsMap.put( AgeFromDateRule.OPTIONAL_STANDARD_PARAMETER_CONTEXT_NODE, doc);
		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), true);

		//--  Test with Context Node doc and PATH_SUMMARY_DATE_OF_BIRTH --
		namedParamsMap.put( AgeFromDateRule.REQUIRED_FIRST_PARAMETER_START_DATE, new RuleNodePathName(SessionNodePathMap.PATH_SUMMARY_DATE_OF_BIRTH));
		namedParamsMap.put( AgeFromDateRule.REQUIRED_SECOND_PARAMETER_AGE, "18");
		namedParamsMap.put( AgeFromDateRule.OPTIONAL_STANDARD_PARAMETER_CONTEXT_NODE, doc);
		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), true);
	
		//-- Test with Context Node Customer and PATH_DETAIL_DATE_OF_BIRTH --
		
		Element elCustomer = (Element) doc.getElementsByTagName(RuleConstants.XML_EL_CUST).item(0);		
		
		namedParamsMap.put( AgeFromDateRule.REQUIRED_FIRST_PARAMETER_START_DATE, new RuleNodePathName(SessionNodePathMap.PATH_DETAIL_DATE_OF_BIRTH));
		namedParamsMap.put( AgeFromDateRule.REQUIRED_SECOND_PARAMETER_AGE, "18");
		namedParamsMap.put( AgeFromDateRule.OPTIONAL_STANDARD_PARAMETER_CONTEXT_NODE, elCustomer);
		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), true);
	
		//-- Test with Context Node Session and PATH_DETAIL_DATE_OF_BIRTH --
		Element elSession= (Element) doc.getElementsByTagName(RuleConstants.XML_EL_ROOT).item(0);		
		
		namedParamsMap.put( AgeFromDateRule.REQUIRED_FIRST_PARAMETER_START_DATE, new RuleNodePathName(SessionNodePathMap.PATH_DETAIL_DATE_OF_BIRTH));
		namedParamsMap.put( AgeFromDateRule.REQUIRED_SECOND_PARAMETER_AGE, "18");
		namedParamsMap.put( AgeFromDateRule.OPTIONAL_STANDARD_PARAMETER_CONTEXT_NODE, elSession);
		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), true);		
	}

	public void testAgeConditions(){
		namedParamsMap.clear();
		result.reset();
		
		Rule rule = new AgeFromDateRule();
		
		Element elCustomer = (Element) doc.getElementsByTagName(RuleConstants.XML_EL_CUST).item(0);		
		
		namedParamsMap.put( AgeFromDateRule.REQUIRED_FIRST_PARAMETER_START_DATE, new RuleNodePathName(SessionNodePathMap.PATH_DETAIL_DATE_OF_BIRTH));
		namedParamsMap.put( AgeFromDateRule.REQUIRED_SECOND_PARAMETER_AGE, "18");
		namedParamsMap.put( AgeFromDateRule.OPTIONAL_STANDARD_PARAMETER_CONTEXT_NODE, elCustomer);
		
		//age == 18  should fail
		namedParamsMap.put( AgeFromDateRule.OPTIONAL_PARAMETER_OPERATOR, RuleConstants.OPERATOR_EQUALS);		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), false);
		assertEquals(RuleConstants.OPERATOR_EQUALS.equals(result.getCode()), true );

		//age != 18  should pass
		namedParamsMap.put( AgeFromDateRule.OPTIONAL_PARAMETER_OPERATOR, RuleConstants.OPERATOR_NOT_EQUALS);		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), true);
		assertEquals(RuleConstants.OPERATOR_NOT_EQUALS.equals(result.getCode()), true );

		//age < 18  should fail
		namedParamsMap.put( AgeFromDateRule.OPTIONAL_PARAMETER_OPERATOR, RuleConstants.OPERATOR_LESS_THEN);		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), false);
		assertEquals(RuleConstants.OPERATOR_LESS_THEN.equals(result.getCode()), true );

		//age <= 18  should fail
		namedParamsMap.put( AgeFromDateRule.OPTIONAL_PARAMETER_OPERATOR, RuleConstants.OPERATOR_LESS_THEN_OR_EQUAL);		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), false);
		assertEquals(RuleConstants.OPERATOR_LESS_THEN_OR_EQUAL.equals(result.getCode()), true );

		//age > 18  should pass
		namedParamsMap.put( AgeFromDateRule.OPTIONAL_PARAMETER_OPERATOR, RuleConstants.OPERATOR_GREATER_THEN);		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), true);
		assertEquals(RuleConstants.OPERATOR_GREATER_THEN.equals(result.getCode()), true );

		//age >= 18  should pass
		namedParamsMap.put( AgeFromDateRule.OPTIONAL_PARAMETER_OPERATOR, RuleConstants.OPERATOR_GREATER_THEN_OR_EQUAL);		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), true);
		assertEquals(RuleConstants.OPERATOR_GREATER_THEN_OR_EQUAL.equals(result.getCode()), true );
		
	}	

	public void testInvalidValue() 
	{
		namedParamsMap.clear();
		result.reset();
		
		Rule rule = new AgeFromDateRule();
		
		Element elCustomer = (Element) doc.getElementsByTagName(RuleConstants.XML_EL_CUST).item(0);		
		
		namedParamsMap.put( AgeFromDateRule.REQUIRED_FIRST_PARAMETER_START_DATE, new RuleNodePathName(SessionNodePathMap.PATH_DETAIL_DATE_OF_BIRTH));
		namedParamsMap.put( AgeFromDateRule.REQUIRED_SECOND_PARAMETER_AGE, "X");
		namedParamsMap.put( AgeFromDateRule.OPTIONAL_STANDARD_PARAMETER_CONTEXT_NODE, elCustomer);
		
		result = ruleEngine.assess(rule, namedParamsMap, false);
		
		assertEquals(result.isOk(), false);
		assertEquals(RuleConstants.ERROR_CODE_INVALID_VALUE.equals( result.getCode() ), true);
	}
	
} //~
