package com.ingdirect.dg.util;

import com.ingdirect.util.StringUtil;
import com.ingdirect.util.threading.ThreadsTimer;
import com.ingdirect.util.threading.IndexedObjectCallback;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.logging.Logger;

//TODO ajb: add me to subversion
/**
 *  This class will collect a customer's eligibility
 *  for a list of products or all products.  It will
 *  collect the eligibility for each product in parallel
 *  via a thread safe model. 
 * 
 * @version $Revision: $
 */
public class CustGetEligibility {
	/**
	* The ClassId for this Class
	*/ 
   private final static String CLASS_ID = CustGetEligibility.class.getName();
   /**
	* The logName given to the logger
	*/ 
   private final static String LOG_NAME = CLASS_ID;
   /**
	* The logger
	*/ 
   private final static Logger log = Logger.getLogger(LOG_NAME);
	
	// $NoKeywords $
	private static final String PRODUCT_CLASS_PREFIX = "EligibilityFor";
	private static final List productList = new ArrayList(){
		{
			this.add(EligibilityForEORANGE.PRODUCT_TYPE);
		}
	};
	
	public String getEligibility(List selectedProductList, String cif){
		//TODO ajb: Resolve the following issues :
		//       1. Serial or Parallel collection of eligibility
		//       2. HardCode classes or dynamically instantiate classes
		//
		//For the present, since there is just one product, there
		//is no immediate need to address these issues.
		
		/**
		 * The activeList will be the productList if the
		 * argument selectedProductList is null, otherwise, the
		 * activeList is the selectedProductList.
		 */ 
		List activeList;
		if(selectedProductList == null){
			activeList = productList;
		} else {
			activeList = selectedProductList;
		}
		
		/**
		 * For each product in the activeList, run a
		 * thread to return the eligibility for the product.
		 */ 
		int nProducts = activeList.size();
		String product = null;
		Class productClass;
		EligibilityForProduct eligibilityProduct;
		//TODO ajb: fix me
		ThreadsTimer timer = new ThreadsTimer(0,0,0,"");
		
		List x = new ArrayList();
		List synclist =
		  Collections.synchronizedList(x);
		
		for(int i=0; i<nProducts; i++){
			try{
			product = (String) activeList.get(i);
			// get the Class
			productClass = Class.forName(PRODUCT_CLASS_PREFIX+product);
			// get an instance 
			eligibilityProduct = (EligibilityForProduct) productClass.newInstance();
				
			eligibilityProduct.setCif(cif);
			eligibilityProduct.setList(synclist);
				
			timer.fire( new Thread(eligibilityProduct) );
				
			} catch(Exception exception){
				log.severe("200- Exception : Eligibility for {"+StringUtil.fillNull(product)+"}\n"+exception);			
			}
		}
		
		//-- wait for the Thread(s) to complete
		timer.sleep();
		//-- remove any threads still running --
		timer.destroy();
		//-- check for a timeout --
		if( timer.hasTimeExpired() ){
			log.severe("210- time expired before all eligibility products completed.");			
		}
		//-- process the collected eligibility products --
		
		return new String();
	}
	
} //~
