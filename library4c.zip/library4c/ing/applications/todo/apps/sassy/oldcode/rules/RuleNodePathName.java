package com.ingdirect.util.rules;

/**
 * @version $Revision: 214 $
 */
public class RuleNodePathName {
	// $NoKeywords $
	String nodePathName = null;
	public RuleNodePathName(String nodePathName){
		super();
		this.nodePathName = nodePathName;
	}
	
	public String getName() { return nodePathName; }
}
