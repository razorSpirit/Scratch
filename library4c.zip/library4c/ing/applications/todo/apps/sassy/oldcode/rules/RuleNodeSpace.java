package com.ingdirect.util.rules;

import java.util.Map;

/**
 * @version $Revision: 409 $
 */
public class RuleNodeSpace {
	// $NoKeywords $
	private Map nameSpaceMap = null;
	private RuleNodePathMap nodePathMap = null;
	
	public RuleNodeSpace() { super(); }
	public RuleNodeSpace(Map nameSpaceMap, RuleNodePathMap nodePathMap){
		this();
		this.nameSpaceMap = nameSpaceMap;
		this.nodePathMap = nodePathMap;
	}
	
	public Map getNameSpaceMap() { return nameSpaceMap; }
	public void setNameSpaceMap(Map nameSpaceMap){ this.nameSpaceMap = nameSpaceMap; }

	public RuleNodePathMap getNodePathMap() { return nodePathMap; }
	public void setNodepathMap(RuleNodePathMap nodePathMap){ this.nodePathMap = nodePathMap; }
	
	public RuleNodePath getNodePath(String key){ return (RuleNodePath) getNodePathMap().get(key); }
}
