package com.ingdirect.util.rules;

import java.util.Map;
import java.util.HashMap;

/**
 * @version $Revision: 323 $
 */
public class SessionNodeSpace extends RuleNodeSpace{
	// $NoKeywords $ 

	final static RuleNodePathMap NODE_PATH_MAP = new SessionNodePathMap();
	
	final Map NAME_SPACE_MAP = new HashMap() 
	{
		{
			put("c:", "urn:gw-customer-100");
			put("helper:", "xalan://com.ingdirect.util.xsl.XslHelper");
			put("phone:", "xalan://com.ingdirect.util.contact.BasicTelephone");
			put("ssn:", "xalan://com.ingdirect.util.id.UsSsn");
			put("u:", "urn:gw-user-100");
			put("xsl:", "http://www.w3.org/1999/XSL/Transform");
			put("#document.Session.Customer.Detail", "urn:gw-customer-100");
			put("#document.Session.Customer.ExternalLinks", "urn:gw-account-100");
			put("#document.Session.ExternalLinks",  "urn:gw-account-100");
			put("#document.Session.StaticData.SecurityQuestionDescs", "urn:gw-customer-100");
			put("#document.Session.StaticData.TypeDescs", "urn:gw-account-100");
			put("#document.Session.Summaries",  "urn:gw-account-100");
			put("#document.Session.User.Summary",  "urn:gw-user-100");	
			
			put("Detail", "urn:gw-customer-100");
			put("ExternalLinks", "urn:gw-account-100");
			put("SecurityQuestionDescs", "urn:gw-customer-100");
			put("TypeDescs", "urn:gw-account-100");
			put("Summaries",  "urn:gw-account-100");
		}
	};
	
	public SessionNodeSpace(){
		super();
		super.setNodepathMap(NODE_PATH_MAP);
		super.setNameSpaceMap(NAME_SPACE_MAP);
	}
	
}
