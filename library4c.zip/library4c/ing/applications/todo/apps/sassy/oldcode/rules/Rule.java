package com.ingdirect.util.rules;

//Standard Java
import java.util.Map;
import java.util.HashMap;
import java.util.logging.Logger;
//   Third Party

//   ING DIRECT

/**
 * This abstract class defines the structure of a Rule.     
 * Each Rule object is required to be run by a <i>RuleEngine</i>.
 *
 * Please refer to the the rule framework.
 *  
 * @see RuleEngineImpl, package.html
 * 
 * @author abrida
 * @version $Revision: 409 $
 */

public abstract class Rule
 {
	/**
	 * The name of the class and the name used by the logger.
	 */ 
	String CLASS_ID = Rule.class.getName();
	String logName = CLASS_ID;
	
	/**
	 *   Indicates to the RuleEngine whether the rule 
	 *   is a candidate to be skipped.
	 *   If the value is false and this rule ran successfully, then 
	 *   it will not run again, otherwise, the rule will be ran.   
	 */ 
	boolean alwaysAssessRule = true;
	
	/**
	 * The RuleEngine that invoked this rule.
	 */ 
	RuleEngine engine;
	
	/**
	 * Standard Logger
	 */ 
	Logger log = Logger.getLogger(logName);
	
	/**
	 * These are the parameters required by the rule.
	 * 
	 * The RuleEngine accesses this array to determine if
	 * all the required parameters have been suppplied.  If
	 * any of the required parameters are missing, then the
	 * rule fails and an error is created in RuleResult. 
	 * 
	 * Notes :
	 *  1. To specify  Param1A or Param1B or Param1C AND Param2
	 * 
	 *      { {Param1A, Param1B, Param1C},
	 *        {Param2},
	 *      }
	 *  
	 */ 
	String[][] requiredParameters=null;
	
	/**
	 * Optional Parameters that the rule will accept.
	 */ 
	String[][] optionalParameters = null;
	
	/**
	 * Map that contains all the field entries derived
	 * from both the required and optional parameters.
	 * These are the values that the applyRule method applies
	 * to its calculations.
	 * 
	 * The fieldMap may contain other values as well to
	 * communicate pertinent information.
	 * 
	 * A rules parameter(s) may have to be evaluated
	 * and resolved to an expected value.  
	 * 
	 * For example if a parameter named text1 is expected to
	 * be a String and it's run time type is a Node then the
	 * Node is resolved to a String value and it is placed in
	 * the fieldMap.
	 * 
	 */ 
	Map fieldMap = new HashMap();	
	
	/**
	 * Flag.  True indicates that this is the first rule called
	 * and False indicates that this rule was called from another rule. 
	 */ 
	boolean isFirstRule=false;
	
	/**
	 * Default Constructor.
	 */ 
	public Rule(){
		super();
		init();
	}
	
	/**
	 * This constructor must be used to create this rule from within 
	 * another rule.
	 * 
	 * @param rule - the rule from which this rule is being created.
	 */ 
	public Rule(Rule rule){
        super();
		this.setRuleEngine( rule.getRuleEngine() );		
		init();
		isFirstRule=false;
	}
	
	/**
	 * Constructor with engine parameter
	 * @param alwaysAssessRule - boolean flag that tells the <i>RuleEngineImpl<i>
	 *        that this rule will always be ran, even if it has run already.
	 *        When false, the <i>RuleEngineImpl<i> will check to see if this
	 *        rule ran successfully, and if so, it will <i>NOT</i> run this
	 *        rule and return a successful result, otherwise, the rule will be
	 *        ran.
	 */	
	Rule(boolean alwaysAssessRule){
		this();
		this.alwaysAssessRule = alwaysAssessRule;
	}
	
	/**
	 * Called by constructor to initialize this rule.
	 */ 
	abstract void init();
	
	/**
	 * Called by RuleEngine prior to calling checkParametersValues.
	 */ 
	abstract void reset();
	
	/**
	 * Called by RuleEngine to check the required and optional values.
	 * After the RuleEngine determines the presence of the required
	 * and optional parameters, it then calls upon the rule to check
	 * that the values of these parameters are valid.
	 * 
	 * @return true - values are valid, otherwise, value are invalid.
	 */ 
	abstract boolean checkParametersValues();
	
	/**
	 * Called by the RuleEngine to apply this rule.  The RuleResult
	 * object is used by this method to record the result. 
	 */ 
	abstract void applyRule();
	
	/**
	 * Flag used by the RuleEngine to determine whether this rule
	 * should always be ran.
	 * 
	 * @return  true  - RuleEngine runs the rule.
	 *          false - RuleEngine checks to see if this rule ran
	 *                  before and was successful.  If so, the rule
	 *                  does not run, otherwise, the rule is ran.
	 */ 
	public final boolean alwaysAssessRule()  { return alwaysAssessRule; }
	/**
	 * Flag. @see alwaysAssessRule
	 * @return
	 */ 
	public final boolean getAlwaysAssessRule()  { return alwaysAssessRule; }
	/**
	 * Flag. @see alwaysAssessRule
	 * @param alwaysAssessRule - true - RuleEngine always runs the rule, otherwise,
	 *                           the RuleEngine evaluates whether the rule is to be
	 *                           ran.
	 */ 
	public final void setAlwaysAssessRule(boolean alwaysAssessRule) { this.alwaysAssessRule = alwaysAssessRule; }
	
	/**
	 * The RuleEngine that called this rule.
	 * @return
	 */ 
	final RuleEngine getRuleEngine() { return engine; }
	
	/**
	 * Called by the RuleEngine to identify itself to the Rule.
	 * @param engine - the RuleEngine that is running this Rule.
	 */ 
	final void setRuleEngine(RuleEngine  engine){ 
		this.engine = engine;
		isFirstRule = ( engine.getRuleCount() == 1);
	}
	
	/**
	 * Name given to this rule
	 * @return
	 */ 
	public final String getName() { return CLASS_ID; }	
	
	/**
	 * Called by the RuleEngine to determine if all the required parameters were supplied.
	 * @return String[][] which contains the required parameters.
	 * @see requiredParameters 
	 */ 
	public final String[][] getRequiredParameters() {  return requiredParameters; }
	
	/**
	 * 
	 * @param requiredParameters
	 */ 
	public final void setRequiredParameters(String[][] requiredParameters){
		this.requiredParameters = requiredParameters;
	}
	
	/**
	 * Called by the RuleEngine to examine the optional parameters.
	 * @return
	 */ 
	public final String[][] getOptionalParameters() {  return optionalParameters; }
	public final void setOptionalParameters(String[][] optionalParameters){
		this.optionalParameters = optionalParameters;
	}
	
	/**
	 * Top level parameters (FirstRule parameters) are distinguished from
	 * internally called parameters, so to avoid any collisions.
	 * 
	 * @param baseParamName - the parameter name defined in the required and optional 
	 *                        parameter arrays.
	 * 
	 * @return String representing the true name identifying this parameter 
	 */ 
	final String createParameterName(String baseParamName){
		if( isFirstRule() ){
			return RuleConstants.SYSTEM_PARAM_PREFIX+ getName() + "." + baseParamName;
		}
		return RuleConstants.SYSTEM_PARAM_CALLER_PREFIX+ getName() + "." + baseParamName;
	}
	
	/**
	 * There are 3 levels of parameters :
	 *    base level  - these are the parameter that are created outside
	 *                  the rule engine and they are Globally available to
	 *                  all rules.
	 *    First level - a.k.a. parent or FirstRule parameters.   These are
	 *                  created internally by the main rule.
	 * 
	 *   Second level - these parameters are created by the rules that
	 *                  were called by the Main rule.
	 * 
	 * @param baseParamName - parameter supplied outside the RuleEngine.
	 * 
	 * @return the parameter name found by searching the second level,
	 *         first level and base level names.
	 */ 
	final String getParameterName(String baseParamName){
		Map map = RuleHelper.getSystemDataMap(this);

		//Check private/caller parameter name
		String key = createParameterName(baseParamName);	
		
		//Private to Rule
		if( map.containsKey( key ) ){
			return key;
		}
	
		//Check global name
		if( map.containsKey( baseParamName ) ){
			return baseParamName;
		} 
		
		return null;
	}
	
	/**
	 * The ResultObject used by <U>all</U> rules that is
	 * located in the RuleEngine.
	 * 
	 * @return RuleResult object used to record the results.
	 */ 
	final RuleResult getResult() {  return engine.getResult(); }
	
	/**
	 * Returns a Field from the FieldMap.
	 *  
	 * @param key - String representing a named value.
	 * @return Object which represents the value of the supplied key.
	 * @see fieldMap
	 */ 
	public final Object getField(Object key) {	return fieldMap.get(key);    }
	
	/**
	 * Returns the fields map.
	 * @return
	 * @see fieldMap
	 */ 
	public final Map getFieldMap() {    return fieldMap;    }

	/**
	 * Flag indicating whether this Rule is the top level rule.
	 * @return true if this is the top level rule, otherwise, false.
	 */ 
	public final boolean isFirstRule() {  return isFirstRule; }
	
 } //~