package com.ingdirect.util.rules;

//	Standard Java
import java.util.logging.Logger;
import java.util.Map;
import java.util.ArrayList;
//   Third Party
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Element;

//   ING DIRECT
import com.ingdirect.util.xml.XmlHelper;

/**
 * This class is a Rule which must be ran using a RuleEngine according to 
 * the rule framework. @see RuleEngineImpl, package.html
 * 
 * The CountForValueRule compares two counts using a comparison operator and
 * returns the result of this comparison.   
 * 
 * Four parameters are required - a node list, a node name found in the list, a regular
 * expression, and a count.
 * 
 * The required count parameter is compared to a calculated count. 
 * The calculated count is derived by searching through the 
 * required node list for the required node name, then the required regular expression
 * is applied to the required node name value.  If the reqular expression matches the
 * node value then a counter is incremented.  This process continues until all the nodes
 * in the node list have been evaluated.
 *
 * <B><U>Parameter Requirements:</U></B>
 * 
 *  required : node list, node name in list, regular expression, count
 * 
 *  optional : operator
 * 
 *  defaults :  operator is <I>OPTIONAL_OPERATOR_VALUE_GREATER_THEN_OR_EQUAL</I> (>=)
 * 
 * <B><U>Parameter typing:</U></B>
 *                                
 * The following types - Node, RuleNodePathName, RuleNodePath, RuleNodeLocation
 * can be applied to parameters - node list
 * 
 * The following types - String, Node, RuleNodePathName, RuleNodePath, RuleNodeLocation
 * can be applied to parameters - node name in list, regular expression, operator
 * 
 * The following types - Integer, String, Node, RuleNodePathName, RuleNodePath, RuleNodeLocation
 * can be applied to parameters - count
 * 
 * @author abrida
 * @version $Revision: 409 $
 */
public class CountForValueRule extends Rule {
	/* Required Parameter Names */
	public final static String REQUIRED_FIRST_PARAMETER_NODE_LIST = RuleConstants.PARAM_NAME_NODE_LIST;
	public final static String REQUIRED_SECOND_PARAMETER_NODE_NAME_IN_LIST = RuleConstants.PARAM_NAME_NODE_NAME_IN_LIST;
	public final static String REQUIRED_THIRD_PARAMETER_REGULAR_EXPRESSION = RuleConstants.PARAM_NAME_REGULAR_EXPRESSION;
	public final static String REQUIRED_FOURTH_PARAMETER_COUNT = RuleConstants.PARAM_NAME_COUNT;
	
	/* Optional Parameter Names */
	public final static String OPTIONAL_PARAMETER_OPERATOR = RuleConstants.PARAM_NAME_OPERATOR;
	
	/* -- Standard Optional Parameter Names -- */
	public final static String OPTIONAL_STANDARD_PARAMETER_COMMENTS = RuleConstants.PARAM_NAME_COMMENTS;
	public final static String OPTIONAL_STANDARD_PARAMETER_CONTEXT_NODE = RuleConstants.PARAM_NAME_CONTEXT_NODE;
	public final static String OPTIONAL_STANDARD_PARAMETER_NODE_LOCATION = RuleConstants.PARAM_NAME_NODE_LOCATION;

	/* Optional Values */
	public final static String OPTIONAL_OPERATOR_VALUE_EQUALS = RuleConstants.OPERATOR_EQUALS;
	public final static String OPTIONAL_OPERATOR_VALUE_GREATER_THEN = RuleConstants.OPERATOR_GREATER_THEN;
	public final static String OPTIONAL_OPERATOR_VALUE_GREATER_THEN_OR_EQUAL = RuleConstants.OPERATOR_GREATER_THEN_OR_EQUAL;	
	public final static String OPTIONAL_OPERATOR_VALUE_LESS_THEN = RuleConstants.OPERATOR_LESS_THEN;
	public final static String OPTIONAL_OPERATOR_VALUE_LESS_THEN_OR_EQUAL = RuleConstants.OPERATOR_LESS_THEN_OR_EQUAL;	
	public final static String OPTIONAL_OPERATOR_VALUE_NOT_EQUALS = RuleConstants.OPERATOR_NOT_EQUALS;
	
	/* Default Values */
	public final String DEFAULT_OPERATOR = OPTIONAL_OPERATOR_VALUE_GREATER_THEN_OR_EQUAL;	
	
	/**
	 * Constructor : default
	 */ 
	public CountForValueRule() { super(); }
	
	/**
	 * Constructor with engine parameter
	 * @param alwaysAssessRule - boolean flag that tells the <i>RuleEngineImpl<i>
	 *        that this rule will always be ran, even if it has run already.
	 *        When false, the <i>RuleEngineImpl<i> will check to see if this
	 *        rule ran successfully, and if so, it will <i>NOT</i> run this
	 *        rule and return a successful result, otherwise, the rule will be
	 *        ran.
	 */	
	CountForValueRule( boolean alwaysAssessRule){
		 super( alwaysAssessRule); 
		}

	/**
	 * This constructor must be used to create this rule from within 
	 * another rule.
	 * 
	 * @param rule - the rule from which this rule is being created.
	 */ 
	CountForValueRule( Rule rule){
		 super( rule );
	}
		
	/**	
	 * Called by the contructor to define the 
	 * id of the rule, the log name, and the required and
	 * optional parameters.
	 */ 
	void init(){
		CLASS_ID = CountForValueRule.class.getName();
		logName = CLASS_ID;
		log = Logger.getLogger(logName);
		
		//Always assess this rule
		this.setAlwaysAssessRule(true);
		
		String[][] myParameterNames = { { REQUIRED_FIRST_PARAMETER_NODE_LIST},
										{ REQUIRED_SECOND_PARAMETER_NODE_NAME_IN_LIST},
										{ REQUIRED_THIRD_PARAMETER_REGULAR_EXPRESSION},
		                                { REQUIRED_FOURTH_PARAMETER_COUNT},
		                              };
		
		this.setRequiredParameters(myParameterNames);
		
		String [][] myOptionalParameterNames = { {OPTIONAL_PARAMETER_OPERATOR},
											  };
		this.setOptionalParameters(myOptionalParameterNames);
	}

	/**
	 * Called by the RuleEngine to validate the parameter values for this rule.
	 * 
	 * @return true  - if all the parameters are valid
	 *         false - if any of the parameters are invalid
	 */ 
	boolean checkParametersValues(){
		
		//Establish the result - false
		RuleResult result = getResult();
		
		//Validate the optional parameters
		if( ! validateOptionalParameters() ) return false;
		
		//Validate the required parameter values
		if( ! validateRequiredParameterValues() ) return false;
		
		//done
	    return result.isOk();
   }

	/**
	 * Called by the RuleEngine to apply the rule. 
	 * The RuleResult object in the RuleEngine is used to
	 * report the result.
	 * 
	 */	
	void applyRule(){
		
		RuleResult result = getResult();
		result.setIsOk(true);
		Map fieldMap = getFieldMap();
		
		//-- Get the required parameters      --
		NodeList nodeList = (NodeList) fieldMap.get(REQUIRED_FIRST_PARAMETER_NODE_LIST);		
		String nodeName = (String) fieldMap.get(REQUIRED_SECOND_PARAMETER_NODE_NAME_IN_LIST);
		String regex = (String) fieldMap.get(REQUIRED_THIRD_PARAMETER_REGULAR_EXPRESSION);
		Integer  intObject = (Integer) fieldMap.get(REQUIRED_FOURTH_PARAMETER_COUNT);
		int operator = RuleConstants.OPERATORS_LIST.indexOf( fieldMap.get(OPTIONAL_PARAMETER_OPERATOR) );		
	
		int countToTest = intObject.intValue();
		
		//-- Calculate the number of times the value is found -- 
		
		int countNodes = 0;
		if( nodeList != null ){
			countNodes = nodeList.getLength();
		}
		
		int countFound = 0;
		Node node;
		Element el;
		String text;

		for(int i=0; i<countNodes; i++){
			el = (Element) nodeList.item(i);
			node = el.getElementsByTagName(nodeName).item(0);
			if(node != null){
				text=XmlHelper.getNodeText(node);
				if(text.matches(regex)){
					++countFound;
				}
			}
		}

		//-- Make the assessment --
		
		boolean ok = false;

		switch(operator){
			
			case RuleConstants.INT_EQUALS:
				ok = (countFound == countToTest); 
				break;
			case RuleConstants.INT_GREATER_THEN:
				ok = (countFound > countToTest); 
				break;
			case RuleConstants.INT_GREATER_THEN_OR_EQUAL:
				ok = (countFound >= countToTest); 
				break;
			case RuleConstants.INT_LESS_THEN:
				ok = (countFound < countToTest); 
				break;
			case RuleConstants.INT_LESS_THEN_OR_EQUAL:
				ok = (countFound <= countToTest); 
				break;
			case RuleConstants.INT_NOT_EQUALS:
				ok = (countFound != countToTest); 
				break;
				
			default:				
				result.setCode(RuleConstants.ERROR_CODE_PROGRAMMER_ERROR);
				result.setDescription("900 - Programmer Error. operator("+operator+")");
				log.finest(result.getDescription());
				
		}		
		
		//-- done --
		result.setCode( (String) RuleConstants.OPERATORS_LIST.get(operator) );
		result.setIsOk(ok);
		
		log.finest("999 - Done - "+ result.isOk()+".");		
	}
	
	/**
	 * The fieldMap taken from the Rule base class is reset
	 * with the optional and default values.  The fieldMap is 
	 * used to hold the values rendered from the passed parameters.
	 * 
 	 */	
	void reset(){	
		Map fieldMap = getFieldMap();
		fieldMap.clear();
		
		fieldMap.put(OPTIONAL_PARAMETER_OPERATOR, DEFAULT_OPERATOR);		

		getResult().setIsOk(false);		
	 }

	/**
	 * This method validates the required parameters and places their derived
	 * values in the Rules fieldMap.
	 * @return
	 */ 
	private boolean validateRequiredParameterValues(){
		RuleResult result = getResult();
		
		Object value;
		String paramName;
		
		//Get the required parameter list 
		ArrayList parameterNames = (ArrayList) RuleHelper.getSystemData(this, RuleConstants.SYSTEM_PARAM_REQUIRED_LIST);
		
		//Required Parameter 1 : REQUIRED_FIRST_PARAMETER_NODE_LIST
		paramName = (String) parameterNames.get(0);
		value = RuleHelper.getParameterValue( this, paramName );
		if(value == null){
			result.setCode(RuleConstants.ERROR_CODE_INVALID_VALUE);
			result.setDescription("Null value. Value for parameter name("+paramName+") must resolve to a NodeList.");
			result.setIsOk(false);
			return false;
		} else {
			if( ! RuleParameterHelper.validateNodeList( this, paramName, value) ) {
				if(! RuleConstants.ERROR_CODE_NULL_VALUE.equals(result.getCode())){
					return false;
				}
			}
		}
		
		//Required Parameter 2 : REQUIRED_SECOND_PARAMETER_NODE_NAME_IN_LIST
		paramName = (String) parameterNames.get(1);
		value = RuleHelper.getParameterValue( this, paramName );
		if(value == null){
			result.setCode(RuleConstants.ERROR_CODE_INVALID_VALUE);
			result.setDescription("Null value. Value for parameter name("+paramName+") must resolve to a String.");
			result.setIsOk(false);
			return false;
		} else {
			if( ! RuleParameterHelper.validateString( this, paramName, value) ) return false;
		}

		//Required Parameter 3 : REQUIRED_THIRD_PARAMETER_VALUE
		paramName = (String) parameterNames.get(2);
		value = RuleHelper.getParameterValue( this, paramName );
		if(value == null){
			result.setCode(RuleConstants.ERROR_CODE_INVALID_VALUE);
			result.setDescription("Null value. Value for parameter name("+paramName+") must resolve to a String.");
			result.setIsOk(false);
			return false;
		} else {
			if( ! RuleParameterHelper.validateString( this, paramName, value) ) return false;
		}

		//Required Parameter 4 : REQUIRED_FOURTH_PARAMETER_COUNT
		paramName = (String) parameterNames.get(3);
		value = RuleHelper.getParameterValue( this, paramName );
		if(value == null){
			result.setCode(RuleConstants.ERROR_CODE_INVALID_VALUE);
			result.setDescription("Null value. Value for parameter name("+paramName+") must resolve to an integer.");
			result.setIsOk(false);
			return false;
		} else {
			if( ! RuleParameterHelper.validateInteger( this, paramName, value) ) return false;
		}
		
		result.setIsOk(true);
		return true;
	}
	
	/**
	 * This method validates the chosen optional parameters and places
	 * their values in the Rules FieldMap.  The RuleResult is used to
	 * report the success or failure to the RuleEngine.
	 * 
	 * @return  true  - validation passed
	 *          false - validation failed.
	 */ 
	private boolean validateOptionalParameters(){
		RuleResult result = getResult();
		
		Object value;
		
		//OPTIONAL_PARAMETER_OPERATOR
		value = RuleHelper.getParameterValue( this, OPTIONAL_PARAMETER_OPERATOR );
		if(value != null){
			if( ! RuleParameterHelper.validateOperator( this, OPTIONAL_PARAMETER_OPERATOR, value ) ) return false;
		}
		
		result.setIsOk(true);
		return true;
		
	}	
} //~
