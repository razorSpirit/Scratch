package com.ingdirect.util.rules;

import org.w3c.dom.Document;

import java.util.Map;
import java.util.HashMap;
import java.io.FileInputStream;

import com.ingdirect.util.xml.ThreadLocalDocumentBuilder;
import junit.framework.TestSuite;
import junit.framework.TestCase;

/**
 * @version $Revision: 409 $
 */
public class TextHasValueRuleTest extends TestCase {
	// $NoKeywords $
	Document doc;
	static String id = TextHasValueRuleTest.class.getName();
	
	RuleEngineImpl ruleEngine;
	RuleResult result;
	Map namedParamsMap;
	
	public TextHasValueRuleTest(){
		super(id);
		
	}
	
	public void setUp() throws Exception {		
		doc = ThreadLocalDocumentBuilder.getDocumentBuilder(false).
		parse(new FileInputStream("unittest_data/infoForRules.xml"));
		
		result = new RuleResult();
		ruleEngine = new RuleEngineImpl();
		namedParamsMap = new HashMap();
		
	}
	
	public void tearDown() {
		doc = null;
		namedParamsMap=null;
		ruleEngine=null;
		result=null;
		
	}

	public static void main(String[] args) throws Exception {
		//to run as an application
		new junit.textui.TestRunner().doRun(new TestSuite(TextHasValueRuleTest.class));	
	}

	public void testTextSuccess() {
		
		Rule rule = new TextHasValueRule();

		//-- Success : Test two strings --
		namedParamsMap.put( TextHasValueRule.REQUIRED_FIRST_PARAMETER_TEXT, "Jack");
		namedParamsMap.put( TextHasValueRule.REQUIRED_SECOND_PARAMETER_REGULAR_EXPRESSION, "Jack");
		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), true);

		//-- Success : Test Node Status for customer --
		namedParamsMap.put( TextHasValueRule.REQUIRED_FIRST_PARAMETER_TEXT, new RuleNodePathName(SessionNodePathMap.PATH_DETAIL_STATUS));
		namedParamsMap.put( TextHasValueRule.REQUIRED_SECOND_PARAMETER_REGULAR_EXPRESSION, "customer");
		namedParamsMap.put( TextHasValueRule.OPTIONAL_STANDARD_PARAMETER_CONTEXT_NODE, doc);
		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), true);

		//-- Failure : Test Node Status for badcustomer --
		namedParamsMap.put( TextHasValueRule.REQUIRED_FIRST_PARAMETER_TEXT, new RuleNodePathName(SessionNodePathMap.PATH_DETAIL_STATUS));
		namedParamsMap.put( TextHasValueRule.REQUIRED_SECOND_PARAMETER_REGULAR_EXPRESSION, "badcustomer");
		namedParamsMap.put( TextHasValueRule.OPTIONAL_STANDARD_PARAMETER_CONTEXT_NODE, doc);
		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), false);
		
	}
	
}
