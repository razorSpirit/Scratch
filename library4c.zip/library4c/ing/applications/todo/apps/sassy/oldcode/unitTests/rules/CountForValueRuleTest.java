package com.ingdirect.util.rules;

import org.w3c.dom.Document;

import java.util.Map;
import java.util.HashMap;
import java.io.FileInputStream;

import com.ingdirect.util.xml.ThreadLocalDocumentBuilder;
import junit.framework.TestSuite;
import junit.framework.TestCase;

/**
 * @version $Revision: 409 $
 */
public class CountForValueRuleTest  extends TestCase {
	// $NoKeywords $
	Document doc;
	static String id = CountForValueRuleTest.class.getName();
	
	RuleEngineImpl ruleEngine;
	RuleResult result;
	Map namedParamsMap;
	
	public CountForValueRuleTest(){
		super(id);
		
	}
	
	public void setUp() throws Exception {		
		doc = ThreadLocalDocumentBuilder.getDocumentBuilder(false).
		parse(new FileInputStream("unittest_data/infoForRules.xml"));
		
		result = new RuleResult();
		ruleEngine = new RuleEngineImpl();
		namedParamsMap = new HashMap();
		
	}
	
	public void tearDown() {
		doc = null;
		namedParamsMap=null;
		ruleEngine=null;
		result=null;
		
	}

	public static void main(String[] args) throws Exception {
		//to run as an application
		new junit.textui.TestRunner().doRun(new TestSuite(TextHasValueRuleTest.class));	
	}

	public void testSuccess() {
		
		Rule rule = new CountForValueRule();

		//-- Success :  --
		namedParamsMap.put( CountForValueRule.REQUIRED_FIRST_PARAMETER_NODE_LIST, new RuleNodePathName(SessionNodePathMap.PATH_EXTERNAL_LINK));
		namedParamsMap.put( CountForValueRule.REQUIRED_SECOND_PARAMETER_NODE_NAME_IN_LIST, RuleConstants.XML_EL_LINK_STATUS);
		namedParamsMap.put( CountForValueRule.REQUIRED_THIRD_PARAMETER_REGULAR_EXPRESSION, "verified");
		namedParamsMap.put( CountForValueRule.REQUIRED_FOURTH_PARAMETER_COUNT, new Integer(2));
		namedParamsMap.put( CountForValueRule.OPTIONAL_STANDARD_PARAMETER_CONTEXT_NODE, doc);
		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), true);	
	
	}
	
	public void testEachCondition(){

		Rule rule = new CountForValueRule();

		//-- Setup the Parameters --
		namedParamsMap.put( CountForValueRule.REQUIRED_FIRST_PARAMETER_NODE_LIST, new RuleNodePathName(SessionNodePathMap.PATH_EXTERNAL_LINK));
		namedParamsMap.put( CountForValueRule.REQUIRED_SECOND_PARAMETER_NODE_NAME_IN_LIST, RuleConstants.XML_EL_LINK_STATUS);
		namedParamsMap.put( CountForValueRule.REQUIRED_THIRD_PARAMETER_REGULAR_EXPRESSION, "verified");
		namedParamsMap.put( CountForValueRule.REQUIRED_FOURTH_PARAMETER_COUNT, new Integer(2));
		namedParamsMap.put( CountForValueRule.OPTIONAL_STANDARD_PARAMETER_CONTEXT_NODE, doc);
		
		//age == 2  should pass
		namedParamsMap.put( AgeFromDateRule.OPTIONAL_PARAMETER_OPERATOR, RuleConstants.OPERATOR_EQUALS);		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), true);
		assertEquals(RuleConstants.OPERATOR_EQUALS.equals(result.getCode()), true );

		//age != 2  should fail
		namedParamsMap.put( AgeFromDateRule.OPTIONAL_PARAMETER_OPERATOR, RuleConstants.OPERATOR_NOT_EQUALS);		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), false);
		assertEquals(RuleConstants.OPERATOR_NOT_EQUALS.equals(result.getCode()), true );

		//age < 2  should fail
		namedParamsMap.put( AgeFromDateRule.OPTIONAL_PARAMETER_OPERATOR, RuleConstants.OPERATOR_LESS_THEN);		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), false);
		assertEquals(RuleConstants.OPERATOR_LESS_THEN.equals(result.getCode()), true );

		//age <= 2  should pass
		namedParamsMap.put( AgeFromDateRule.OPTIONAL_PARAMETER_OPERATOR, RuleConstants.OPERATOR_LESS_THEN_OR_EQUAL);		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), true);
		assertEquals(RuleConstants.OPERATOR_LESS_THEN_OR_EQUAL.equals(result.getCode()), true );

		//age > 2  should fail
		namedParamsMap.put( AgeFromDateRule.OPTIONAL_PARAMETER_OPERATOR, RuleConstants.OPERATOR_GREATER_THEN);		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), false);
		assertEquals(RuleConstants.OPERATOR_GREATER_THEN.equals(result.getCode()), true );

		//age >= 2  should pass
		namedParamsMap.put( AgeFromDateRule.OPTIONAL_PARAMETER_OPERATOR, RuleConstants.OPERATOR_GREATER_THEN_OR_EQUAL);		
		result = ruleEngine.assess(rule, namedParamsMap, false);		
		assertEquals(result.isOk(), true);
		assertEquals(RuleConstants.OPERATOR_GREATER_THEN_OR_EQUAL.equals(result.getCode()), true );
		
	}	
}
