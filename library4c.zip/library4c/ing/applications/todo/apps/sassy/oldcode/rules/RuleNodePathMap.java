package com.ingdirect.util.rules;

import java.util.Map;
import java.util.HashMap;

/**
 * @version $Revision: 214 $
 */
public class RuleNodePathMap {
	// $NoKeywords $
	private String name = null;
	Map map = new HashMap();
	
	public RuleNodePathMap(){ super(); }
	
	public String getName() { return name; }
	public void setName(String name){ this.name = name; }
	
	public RuleNodePath get(Object key) { return (RuleNodePath) map.get(key); }

	public RuleNodePath get(Object key, int valueType) {
		RuleNodePath nodepath = (RuleNodePath) map.get(key);
		return new RuleNodePath( nodepath.getPathName(), nodepath.getPath(), valueType);
	}
	
}
