package com.ingdirect.util.rules;

import org.w3c.dom.Node;

/**
 * @version $Revision: 214 $
 */
public class RuleNodeLocation {
	// $NoKeywords $
	Node contextNode = null;
	RuleNodeSpace nodeSpace  = null;
	RuleNodePath nodePath = null;
	
	RuleNodeLocation(){    super(); }

	RuleNodeLocation(Node contextNode, RuleNodeSpace nodeSpace, RuleNodePath nodePath){
		this(); 
		this.contextNode = contextNode;
		this.nodeSpace = nodeSpace;
		this.nodePath = nodePath;
	}
	
	public Node getContextNode() { return contextNode; }
	public void setContextNode(Node contextNode) { this.contextNode=contextNode; }
	
	public RuleNodeSpace getNodeSpace() { return nodeSpace; }
	public void setNodeSpace(RuleNodeSpace nodeSpace) { this.nodeSpace=nodeSpace; }

	public RuleNodePath getNodePath() { return nodePath;}
	public void setNodePath(RuleNodePath nodePath) { this.nodePath = nodePath;}
	
}
