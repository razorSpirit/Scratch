package com.ingdirect.util.rules;

import java.util.Calendar;
import java.util.Map;
import java.util.logging.Logger;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import com.ingdirect.util.DateUtil;

/**
 * @version $Revision: 323 $
 */
public class RuleParameterHelper {
	// $NoKeywords $
	static String CLASS_ID = Rule.class.getName();
	static String logName = CLASS_ID;
	static Logger log = Logger.getLogger(logName);
	
	static boolean validateOperator( Rule rule, String paramName, Object value ){
		RuleResult result = rule.getResult();
		result.setIsOk(false);
		
		if(value == null){
			result.setDescription("Null value. Parameter name("+paramName+") must be a valid operator.");
		}else if(value instanceof String){
			if( RuleConstants.OPERATORS_LIST.indexOf(value) == -1){
				result.setDescription("Parameter name("+paramName+") must be a valid operator. value("+value+".");				
			} else {
				result.setIsOk(true);
			}			
		} else {
			result.setDescription("Value for parameter name("+paramName+") must be a String.");
		}

		if( result.isOk() ){
			rule.getFieldMap().put(paramName, value);
		} else {
			result.setCode(RuleConstants.ERROR_CODE_INVALID_VALUE);
		}
		
		return result.isOk();
		
	}

	static boolean validateContextNode( Rule rule, String paramName, Object value ){

		RuleResult result = rule.getResult();
		result.setIsOk(false);
		
		if(value == null){
			result.setDescription("Null value. Value for parameter name("+paramName+") must be a Node.");	
		}else if(value instanceof Node){
			result.setIsOk(true);
		}
		
		if( result.isOk() ){
			rule.getFieldMap().put(paramName, value);
		} else {
			result.setCode(RuleConstants.ERROR_CODE_INVALID_VALUE);
		}
		
		return result.isOk();
	}

	static boolean validateDateFormat( Rule rule, String paramName, Object value ){

		RuleResult result = rule.getResult();
		result.setIsOk(false);
		Object returnValue = null;
		
		if(value == null){
			result.setDescription("Null value. Value for parameter name("+paramName+") must be a String.");
		} else if( value instanceof Calendar){
			returnValue = value;
		}else {
			validateString(rule, paramName, value);
			if( result.isOk() ){
				String valueString = (String) rule.getFieldMap().get(paramName);
				if(validateForStringCount(valueString, "Y",4)){
					if(validateForStringCount(valueString, "M",2) ){
						if(validateForStringCount(valueString, "D",2)){
							;
						} else {
							result.setIsOk(false);
							result.setDescription("Value for parameter name("+paramName+") must contain at the occurrence of Y 4 times, the occurrence of M twice and the occurrence of D twice.");							
						}
					}
				}
			}
			
			if(! result.isOk() ){
				result.setDescription("Value for parameter name("+paramName+") must be a String.");
			}
		}

		if( result.isOk() ){
			rule.getFieldMap().put(paramName, returnValue);
		} else {
			result.setCode(RuleConstants.ERROR_CODE_INVALID_VALUE);
		}
		
		return result.isOk();
	}
	
	static boolean validateCalendar( Rule rule, String paramName, Object value, String dateFormat ){

		RuleResult result = rule.getResult();
		result.setIsOk(false);
		
		if(value == null){
			result.setDescription("Null value. Value for parameter name("+paramName+") must be a String.");
		} else if( value instanceof Calendar){
			result.setIsOk(true);
		}else {
			validateString(rule, paramName, value);
			if( result.isOk()){
				String date = (String) rule.getFieldMap().get(paramName);
				value = getCalendarWithFormat(rule, date, dateFormat);
			} else {
				result.setDescription("Value for parameter name("+paramName+") must evaluate to a Calendar.");
			}
		}

		if( result.isOk() ){
			rule.getFieldMap().put(paramName, value);
		} else {
			result.setCode(RuleConstants.ERROR_CODE_INVALID_VALUE);
		}
		
		return result.isOk();
	}

	static boolean validateInteger( Rule rule, String paramName, Object value ){

		RuleResult result = rule.getResult();
		result.setIsOk(false);
		
		Integer returnValue = null;
		
		if(value == null){
			result.setDescription("Null value. Value for parameter name("+paramName+") must be a String.");
		}else if(value instanceof Integer){
			returnValue = (Integer) value;
			result.setIsOk(true);			
		}else {
			validateString(rule, paramName, value);
			if(result.isOk() ){
				try{
					String valueString = (String) rule.getFieldMap().get(paramName);
					returnValue = new Integer( valueString );
				} catch(Exception exception){
					result.setIsOk(false);			
				}
			}
			
			if(! result.isOk()){
				result.setDescription("Value for parameter name("+paramName+") must be a String that evaluates to an Integer.");				
			}
		}

		if( result.isOk() ){
			rule.getFieldMap().put(paramName, returnValue);
		} else {
			result.setCode(RuleConstants.ERROR_CODE_INVALID_VALUE);
		}
		
		return result.isOk();
	}

	static boolean validateLong( Rule rule, String paramName, Object value ){

		RuleResult result = rule.getResult();
		result.setIsOk(false);
		
		Long returnValue = null;
		
		if(value == null){
			result.setDescription("Null value. Value for parameter name("+paramName+") must be a String.");		
		}else if(value instanceof Long){
			returnValue = (Long) value;
			result.setIsOk(true);			
		} else {
			validateString(rule, paramName, value);
			if(result.isOk() ){
				try{
					String valueString = (String) rule.getFieldMap().get(paramName);
					returnValue = new Long( valueString );
				} catch(Exception exception){
					result.setIsOk(false);			
				}
			}
			
			if(! result.isOk()){
				result.setDescription("Value for parameter name("+paramName+") must be a String that evaluates to a Long.");
			}			
		}

		if( result.isOk() ){
			rule.getFieldMap().put(paramName, returnValue);
		} else {
			result.setCode(RuleConstants.ERROR_CODE_INVALID_VALUE);
		}
		
		return result.isOk();
	}

	static boolean validateMap( Rule rule, String paramName, Object value ){

		RuleResult result = rule.getResult();
		result.setIsOk(false);
		
		if(value == null){
			result.setDescription("Null value. Value for parameter name("+paramName+") must be a Map.");		
		}else if(value instanceof Map){
			result.setIsOk(true);
		} else {
			result.setDescription("Value for parameter name("+paramName+") must be a Map.");
		}

		if( result.isOk() ){
			rule.getFieldMap().put(paramName, value);
		} else {
			result.setCode(RuleConstants.ERROR_CODE_INVALID_VALUE);
		}
		
		return result.isOk();
	}
	
	static boolean validateNodeList( Rule rule, String paramName, Object value ){

		RuleResult result = rule.getResult();
		result.setIsOk(false);
		
		NodeList returnValue = null;
		
		if(value == null){
			result.setDescription("Null value. Value for parameter name("+paramName+") must resolve to a NodeList.");		
		}else if(value instanceof NodeList){
			returnValue = (NodeList) value;
			result.setIsOk(true);			
		} else {
			validateString(rule, paramName, value);
			if(result.isOk() ){
				Object object =  rule.getFieldMap().get(paramName);
				if(object == null || object instanceof NodeList){
					returnValue = (NodeList) object;
				} else {
					result.setIsOk(false);				
				}
			}
			
			if(! result.isOk()){
				result.setDescription("Value for parameter name("+paramName+") must be a String that evaluates to a NodeList.");
			}			
		}

		if( result.isOk() ){
			rule.getFieldMap().put(paramName, returnValue);
		} else if( RuleConstants.ERROR_CODE_NULL_VALUE.equals( result.getCode() ) ){
			;
		} else {
			result.setCode(RuleConstants.ERROR_CODE_INVALID_VALUE);
		}
		
		return result.isOk();
	}
	
	static boolean validateNodePath( Rule rule, String paramName, Object value ){

		RuleResult result = rule.getResult();
		result.setIsOk(false);
		
		if(value == null){
			result.setDescription("Null value. Value for parameter name("+paramName+") must be a NodePath.");		
		}else if(value instanceof RuleNodePath){
			result.setIsOk(true);			
		} else {
			result.setDescription("Value for parameter name("+paramName+") must be a NodePath.");
		}

		RuleNodePath nodePath = (RuleNodePath) value;
		
		if(nodePath.getPath() == null){
			result.setDescription("NameSpaceMap is null. The nameSpaceMap for the NodeSpace parameter name("+paramName+") must NOT be null.");			
		}
		if( result.isOk() ){
			rule.getFieldMap().put(paramName, value);
		} else {
			result.setCode(RuleConstants.ERROR_CODE_INVALID_VALUE);
		}
		
		return result.isOk();
	}
	
	static boolean validateNodeSpace( Rule rule, String paramName, Object value ){

		RuleResult result = rule.getResult();
		result.setIsOk(false);
		
		if(value == null){
			result.setDescription("Null value. Value for parameter name("+paramName+") must be a NodeSpace.");		
		}else if(value instanceof RuleNodeSpace){
			result.setIsOk(true);			
		} else {
			result.setDescription("Value for parameter name("+paramName+") must be a NodeSpace.");
		}

		RuleNodeSpace nodeSpace = (RuleNodeSpace) value;
		
		if(nodeSpace.getNameSpaceMap() == null){
			result.setDescription("NameSpaceMap is null. The nameSpaceMap for the NodeSpace parameter name("+paramName+") must NOT be null.");			
		} else {
			RuleNodePathMap nodePathMap = nodeSpace.getNodePathMap();
			if(nodePathMap == null){
				result.setDescription("NodePathMap is null. The nodePathMap for the NodeSpace parameter name("+paramName+") must NOT be null.");				
			} else {
				result.setIsOk(true);
			}
		} 
		
		if( result.isOk() ){
			rule.getFieldMap().put(paramName, value);
		} else {
			result.setCode(RuleConstants.ERROR_CODE_INVALID_VALUE);
		}
		
		return result.isOk();
	}
	
	static boolean validateString( Rule rule, String paramName, Object value ){

		RuleResult result = rule.getResult();
		result.setIsOk(false);
		
		Object returnValue = null;
		
		if(value == null){
			// ------ Null -----
			returnValue = null;	
		}else if(value instanceof String){
			// ------ String -----
			returnValue = value;
			result.setIsOk(true);
		} else if( (value instanceof RuleNodePathName) || (value instanceof RuleNodePath) ){
			// ------ RuleNodePath -----
			/**
			 * RuleNodePaths require both a contextNode and a nameSpaceMap
			 */ 
			
			boolean isNodePathName = value instanceof RuleNodePathName;
			String typeDescription = isNodePathName ? "RuleNodePathName" : "RuleNodePath";
			
			Map fieldMap = rule.getFieldMap();
			Object object;
			
			//-- The Optional Context Node is required with this parameter type --
			object =  fieldMap.get(RuleConstants.PARAM_NAME_CONTEXT_NODE);

			validateContextNode(rule, RuleConstants.SYSTEM_PARAM_NAME_TEST_VALUE, object);			
			if(!result.isOk()){
				result.setDescription("ContextNode is invalid.  Parameter named ("+paramName+") whose value is a "+ typeDescription +" requires the optional parameter named("+RuleConstants.PARAM_NAME_CONTEXT_NODE+").");
				return false;
			}			
			Node contextNode = (Node) object;
			
			//-- The Optional RuleNodeSpace is required with this parameter type --
			object = fieldMap.get(RuleConstants.PARAM_NAME_NODE_SPACE);			
			
			validateNodeSpace(rule, RuleConstants.SYSTEM_PARAM_NAME_TEST_VALUE, object);			
			if(!result.isOk()){
				result.setDescription("NodeSpace is invalid.  Parameter named ("+paramName+") whose value is a "+ typeDescription +" requires the optional parameter named("+RuleConstants.PARAM_NAME_NODE_SPACE+").");
				return false;
			}			
		
			RuleNodeSpace ruleNodeSpace = (RuleNodeSpace) object;
			
			RuleNodePath ruleNodePath;
			
			if(isNodePathName){		
				//-- Validate the RuleNodePathName and get the ruleNodePath  --
				RuleNodePathName ruleNodePathName = (RuleNodePathName) value;
				
				ruleNodePath = ruleNodeSpace.getNodePath(ruleNodePathName.getName());
				
				if( ruleNodePath == null ){
					result.setDescription("RuleNodePath is null for parameter named ("+paramName+") whose value is a RuleNodePathName.");
					result.setIsOk(false);
					return false;					
				}else{
					;
				}
				
			} else {
				//-- Validate the RuleNodePath --
				ruleNodePath = (RuleNodePath) value;
				
				validateNodePath(rule, RuleConstants.SYSTEM_PARAM_NAME_TEST_VALUE, contextNode);			
				if(!result.isOk()){
					result.setDescription("ContextNode is invalid.  Parameter named ("+paramName+") whose value is a RuleNodePath requires the optional parameter named("+RuleConstants.PARAM_NAME_CONTEXT_NODE+").");
					return false;
				}			
			}
			
			//--  Get the value from the contextNode --
			if( result.isOk() ){
				returnValue = RuleHelper.getObjectForPathFromContextNodeNS( ruleNodeSpace, contextNode, ruleNodePath);
			}			
		} else if(value instanceof RuleNodeLocation){
			// ------ RuleNodeLocation -----
			RuleNodeLocation location = (RuleNodeLocation) value;
			
			//validate the contextNode
			Node contextNode = location.getContextNode();
			
			validateContextNode(rule, RuleConstants.SYSTEM_PARAM_NAME_TEST_VALUE, contextNode);			
			if(!result.isOk()){
				result.setDescription("ContextNode is invalid.  Parameter named ("+paramName+") whose value is a RuleNodePath requires the optional parameter named("+RuleConstants.PARAM_NAME_CONTEXT_NODE+").");
				return false;
			}			

			//validate the nodeSpace
			RuleNodeSpace ruleNodeSpace = location.getNodeSpace();
		
			validateNodeSpace(rule, RuleConstants.SYSTEM_PARAM_NAME_TEST_VALUE, ruleNodeSpace);			
			if(!result.isOk()){
				result.setDescription("NodeSpace is invalid.  Parameter named ("+paramName+") whose value is a RuleNodePath requires the optional parameter named("+RuleConstants.PARAM_NAME_NODE_SPACE+").");
				return false;
			}			

			//-- Validate the RuleNodePath --
			RuleNodePath ruleNodePath = location.getNodePath();
			
			validateNodePath(rule, RuleConstants.SYSTEM_PARAM_NAME_TEST_VALUE, contextNode);			
			if(!result.isOk()){
				result.setDescription("ContextNode is invalid.  Parameter named ("+paramName+") whose value is a RuleNodePath requires the optional parameter named("+RuleConstants.PARAM_NAME_CONTEXT_NODE+").");
				return false;
			}			
			
			
			//Get the value from the contextNode
			if( result.isOk() ){
				returnValue = RuleHelper.getObjectForPathFromContextNodeNS( ruleNodeSpace, contextNode, ruleNodePath);
			}
			
		} else {
			// ------ ERROR -----
			result.setDescription("Value for parameter name("+paramName+") must be a String.");
		}
		
		if( returnValue == null){
			result.setIsOk(false);
			result.setCode(RuleConstants.ERROR_CODE_NULL_VALUE);
			result.setDescription("Null value.");
		}
		
		if( result.isOk() || (returnValue == null) ) {
			rule.getFieldMap().put(paramName, returnValue);
		} else {
			result.setCode(RuleConstants.ERROR_CODE_INVALID_VALUE);
		}
		
		return result.isOk();
	}

	/**
	 *  This function validates the value argument is a String which contains the String
	 *  forString and that it occurs count times.
	 * 
	 * @param value       The string value being evaluated 
	 * @param forString   The string which should be in the value string
	 * @param count       The number of times forString occurs in the value string.
	 * @return            true - if forString occurs count times in value
	 *                    false - otherwise
	 */ 
	static private boolean validateForStringCount( String value, String forString, int count ){		
		if(value == null){
			return false;
		}
		
		String[] temp=( (String) value).split(forString+"*");
		if( temp.length >= count ){
			return true;
		} else {
			return false;				
		}		

	}
	
	/**
	 * 
	 * @param date  a string that represents a date in the format format
	 * @param format a format for a date
	 * @param findChar a character that appears in the format
	 * @param count the number of times that _char appears in format
	 * @return integer  where -1 represents an error
	 *                  anything else is
	 */ 
	static private int getDateForChar( Rule rule, String date, String format, char findChar, int count ){
	
		RuleResult result = rule.getResult();
		result.setIsOk(false);
		
		int pos = 0;
		StringBuffer sbuf = new StringBuffer();
		String value;
		for(int i=0; i<count; i++){
			pos = format.indexOf(findChar, pos);

			if(pos == -1) {
				return pos;
			}
			
			value = date.substring(pos, ++pos);
			sbuf.append(value);			
		}
		
		String text=sbuf.toString();
		
		//
		try{
			int i = Integer.parseInt(text);
			//log.finest("900 - Done for text("+text+")");
			return i;
		} catch(Exception exception){
			log.severe("999 - Done - Exception - Numeric for text("+text+").");			
		  return -1;	
		}
	}

	/**
	 * Returns a Calendar that is representative of the date in format
	 * format.
	 * 
	 * @param value  - String value representing a date in format format
	 * @param format - the date format
	 * @return Calendar for given date or null if there was an error.
	 */ 
	static private Calendar getCalendarWithFormat( Rule rule, String value, String format ){

		RuleResult result = rule.getResult();
		result.setIsOk(false);
		
		int year = getDateForChar(rule, value, format, 'Y', 4);
		if(year == -1 ) {
			if(! result.isOk() ){
				result.setDescription("Failed to get YYYY for value("+value+") with format("+format+").");
				return null;
			}
		}
		
		int month = getDateForChar(rule, value, format, 'M', 2);
		if(month == -1){
			if(! result.isOk() ){
				result.setDescription("Failed to get MM for value("+value+") with format("+format+").");
				return null;
			}
		}
		
		int day = getDateForChar(rule, value, format, 'D', 2);
		if(day == -1){
			if(! result.isOk() ){
				result.setDescription("Failed to get DD for value("+value+") with format("+format+").");
				return null;
			}
		}
		
		Calendar calDate = DateUtil.nowCalendar();
		calDate.set(year, month, day);

		result.setIsOk(true);
		return calDate;
	}
	
} //~
