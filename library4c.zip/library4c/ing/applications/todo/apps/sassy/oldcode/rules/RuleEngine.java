package com.ingdirect.util.rules;

//Standard Java
import java.util.Map;
//   Third Party

//   ING DIRECT

/**
 * The interface for a <I>RuleEngine</I>. 
 *
 * Please refer to the the rule framework.
 *  
 * @see RuleEngineImpl, package.html
 * 
 * @author abrida
 * @version $Revision: 409 $
 */
public interface RuleEngine {
	/**
	 * The name of this RuleEngine.
	 * 
	 * @return String representing the name of this Rule Engine.
	 */ 
	public String getName();
	
	/**
	 * Returns a String.
	 * @return String 
	 */ 
	public String toString();
	
	/**
	 * Method that assesses the Rule by applying parameters
	 * to a computation that results in a boolean.  Errors
	 * are capture in the RuleResult and are considered False. 
	 * 
	 * This method is ran to run the First Rule.
	 * 
	 * @param rule - The Rule to be ran
	 * @param namedParams - Map containing the parameters for the rule.
	 * @param reuseRules - boolean indicating if the information gathered
	 *                     by previous ran Rules should be used for the purpose
	 *                     of determining whether the rule should be assessed.
	 *                     
	 *                     True - will use accumulated information.
	 *                     False - clears any information.
	 * 
	 * @return RuleResult - The result of running the rule.
	 */ 
	public RuleResult assess(Rule rule, Map namedParams, boolean reuseRules);
	
	/**
	 * This method is called by a Rule to run another rule.
	 * 
	 * @param rule - The Rule to be ran
	 * @return RuleResult - The result of running the rule.
	 */ 
	RuleResult assess(Rule rule);

	/**
	 * Map that tracks the successful rules.
	 * 
	 * @return Map containing the names of the Rules that ran successfully.
	 */ 
	public Map getSuccessMap();
	
	/**
	 * A Map containing the pararmeters.
	 * @return Map containing parameters.
	 */ 
	public Map getDataMap();
	
	/**
	 * 
	 * @return the RuleResult object that is used by each
	 *         Rule to report their result.
	 */ 
	public RuleResult getResult();

	/**
	 * @return int representing the number of rules ran.
	 */ 
	int getRuleCount();
}
