package com.ingdirect.dg.util;

import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Locale;

import com.ingdirect.dg.xmlbind.GatewayMessage;
import com.ingdirect.dg.xmlbind.XMLBindException;
import com.ingdirect.dg.xmlbind.AutoMarshallGatewayMessage;
import com.ingdirect.dg.xmlbind.CustSearch;
import com.ingdirect.dg.DirectGatewayException;
import com.ingdirect.dg.service.ElectricOrangeGetEligibility;
import com.ingdirect.dg.service.CustGetDetail;
import com.ingdirect.util.ApplicationProperties;
import com.ingdirect.util.xml.XmlData;
import com.ingdirect.util.xml.SimpleElement;
import com.ingdirect.util.xml.ThreadLocalDocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * @version $Revision: $
 */
public class DgwRequestHelper {
	//** The name of the class and the name used by the logger. */
	final static String CLASS_ID = DgwRequestHelper.class.getName();
	final static String logName = CLASS_ID;

	//** Standard Logger  */
	final static Logger log = Logger.getLogger(logName);
	
	final static String DFT_DETAIL_LEVEL = "0";
	final static Locale DFT_LOCALE = new Locale("en", "US");
	final static String DFT_LANG = localeToString(DFT_LOCALE);
	
	public static String getRequestForCustDetailByCif(String transaction, String cif, String lang, AutoMarshallGatewayMessage reqGwMsg)
	        throws XMLBindException
	{
		final String DGW_TRAN = CustGetDetail.TRAN_PRIMARY_DETAIL;
		final String tran = transaction == null ? DGW_TRAN : transaction;
		
		return getRequestForCustomerId(tran, cif, lang, null, reqGwMsg);
	}
	
	public static String getRequestForCustSummariesByCif(String cif, AutoMarshallGatewayMessage reqGwMsg)
	        throws XMLBindException
	{
		final String DGW_TRAN = "CustFind";
		final String CFG_MAXRECORDS = "cmd.lookup.maxRecords";
		final String DFT_MAXRECORDS = "30";
		
		//TODO ajb : DON'T I want all the summaries ?
		int maxRecords = Integer.parseInt(
				ApplicationProperties.getProperty(CFG_MAXRECORDS, DFT_MAXRECORDS));
		
		//-- Create the request --
		CustSearch dgReq = new CustSearch();
		
		dgReq.initNew();
		dgReq.cloneIdentities(reqGwMsg);
		dgReq.setTransaction(DGW_TRAN );

		dgReq.setMaxRecords(maxRecords);
		dgReq.setUserId(cif);  
		dgReq.setTelephone(null);
		dgReq.setLastName(null);
		dgReq.setFirstName(null);
		dgReq.setPostcode(null);
		dgReq.setExternalId(null);
		dgReq.setEmail(null);
		dgReq.setSolicitId(null);
		dgReq.setDateOfBirth(null);
		
		//-- marshall it to a String --
		String dgReqXml = dgReq.marshallToString();
		
		//-- show the request in the log --
		if(log.isLoggable(Level.FINEST)) {
			log.finest("----------------- Request XML for tran("+DGW_TRAN+")--------------------");
			log.finest(dgReqXml);
			log.finest("--------------------------------------------------------------------");
		}
		
		//-- done --
		return dgReqXml;
	}

	public static String getRequestForExternalLinksByCif(String cif, AutoMarshallGatewayMessage reqGwMsg)
	        throws XMLBindException
	{
		final String DGW_TRAN = "AccountGetLinks";
		
		return getRequestForCustomerId(DGW_TRAN, cif, null, null, reqGwMsg);
	}
	
	public static String getRequestForElectricOrangeEligibility(String transaction, String cif, String lang, AutoMarshallGatewayMessage reqGwMsg)
	        throws XMLBindException
	{
		final String DGW_TRAN = ElectricOrangeGetEligibility.DGW_TRAN_PRIMARY;
		final String tran = transaction == null ? DGW_TRAN : transaction;
		
		return getRequestForCustomerId(tran, cif, lang, null, reqGwMsg);
	}
	
	public static String getRequestForCustomerId(String transaction, String cif, String lang, String detailLevel, AutoMarshallGatewayMessage reqGwMsg)
	        throws XMLBindException
	{
		final String DGW_TRAN = ElectricOrangeGetEligibility.DGW_TRAN_PRIMARY;
		final String tran = transaction == null ? DGW_TRAN : transaction;
		
		//-- Create the request --
		//Create a request for the Links
		com.ingdirect.dg.xmlbind.data.CustId custId = new com.ingdirect.dg.xmlbind.data.CustId();		
		custId.CIF= new SimpleElement(cif);
		custId.Lang = new SimpleElement(lang == null ? DFT_LANG : lang);
		custId.DetailLevel = new SimpleElement(detailLevel == null ? DFT_DETAIL_LEVEL : detailLevel);
		
		AutoMarshallGatewayMessage dgReq = new AutoMarshallGatewayMessage();
		dgReq.initNew();
		dgReq.cloneIdentities(reqGwMsg);
		dgReq.setTransaction(tran);
		dgReq.setBodyData( custId, "Id");
		
		//-- marshall it to a String --
		String dgReqXml = dgReq.marshallToString();
		
		//-- show the request in the log --
		if(log.isLoggable(Level.FINEST)) {
			log.finest("----------------- Request XML for tran("+tran+")--------------------");
			log.finest(dgReqXml);
			log.finest("--------------------------------------------------------------------");
		}
		
		//-- done --
		return dgReqXml;
	}
	
	public static Element unmarshallResponse(String dgResponseXml, XmlData dgResponseData, boolean validateXml)
		throws XMLBindException, DirectGatewayException
	{		
		//-- log the response --
		if(log.isLoggable(Level.FINEST)) {
			log.finest("----------------- Response -------------------");
			log.finest(dgResponseXml);
			log.finest("----------------------------------------------");
		}
		
		//Document doc = ThreadLocalDocumentBuilder.getDocumentBuilder(false).newDocument();
		AutoMarshallGatewayMessage gwMsg = new AutoMarshallGatewayMessage();
		gwMsg.unmarshall(dgResponseXml, null, validateXml);
		
		if (gwMsg.getResponseType() != GatewayMessage.RESTYPE_RESULT) {
			if(log.isLoggable(Level.SEVERE)) {
				log.finest("----------------- Exception in Response -------------------");
				log.finest(dgResponseXml);
				log.finest("-----------------------------------------------------------------");
			}
			throw new DirectGatewayException("Response exception.\n"+ dgResponseXml);			
		}
		
		Document doc = ThreadLocalDocumentBuilder.getDocumentBuilder(false).newDocument();		
		Element element = gwMsg.cloneBodyForImport(doc);
		
		if( dgResponseData != null){
			gwMsg.fillBodyData(dgResponseData);
		}
		//Object object = gwMsg.cloneBodyForImport(doc);
		return element;
	}
	
	public static String localeToString(Locale locale) {
		StringBuffer buf = new StringBuffer(locale.getLanguage());
		String country = locale.getCountry();
		if(country != null && country.length() != 0) {
			buf.append('-').append(country);
		 }
		String variant = locale.getVariant();
		if(variant != null && variant.length() != 0) {
			buf.append('-').append(variant);
		 }
		return buf.toString();
	 }
	
}
