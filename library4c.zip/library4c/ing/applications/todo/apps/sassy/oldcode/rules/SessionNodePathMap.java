package com.ingdirect.util.rules;

import java.util.Map;
import java.util.HashMap;

/**
 * @version $Revision: 607 $
 */
public class SessionNodePathMap extends RuleNodePathMap {
	
	public final static String PATH_DETAIL_DATE_OF_BIRTH = "Detail.DateOfBirth";
	public final static String PATH_DETAIL_ELIGIBILITY = "Detail.Eligibility";
	public final static String PATH_DETAIL_FAS_AGENT = "Detail.FasAgent";
	public final static String PATH_DETAIL_INVITATIONS = "Detail.Invitations";
	public final static String PATH_DETAIL_RELEATED_CUSTOMER = "Detail.RelatedCustomer";
	public final static String PATH_DETAIL_RESTRICTION = "Detail.Restriction";
	public final static String PATH_DETAIL_STATUS = "Detail.Status";
	public final static String PATH_EXTERNAL_LINK = "ExternalLinks.ExternalLink";
	public final static String PATH_EXTERNAL_LINKS = "ExternalLinks";
	public final static String PATH_SUMMARY_DATE_OF_BIRTH = "Summary.DateOfBirth";
	public final static String PATH_SUMMARY_STATUS = "Summary.Status";
	public final static String PATH_SUMMARIES_SUMMARY = "Summaries.Summary";

	public final static String PATH_DETAIL_DATE_OF_BIRTH_2 = "Detail.DateOfBirth2";
	public final static String PATH_DETAIL_ELIGIBILITY_2 = "Detail.Eligibility2";
	public final static String PATH_DETAIL_FAS_AGENT_2 = "Detail.FasAgent2";
	public final static String PATH_DETAIL_INVITATIONS_2 = "Detail.Invitations2";
	public final static String PATH_DETAIL_RELEATED_CUSTOMER2 = "Detail.RelatedCustomer2";
	public final static String PATH_DETAIL_RESTRICTION_2 = "Detail.Restriction2";
	public final static String PATH_DETAIL_STATUS_2 = "Detail.Status2";
	public final static String PATH_EXTERNAL_LINK_2 = "ExternalLinks.ExternalLink2";
	public final static String PATH_EXTERNAL_LINKS_2 = "ExternalLinks2";
	public final static String PATH_SUMMARY_DATE_OF_BIRTH_2 = "Summary.DateOfBirth2";
	public final static String PATH_SUMMARY_STATUS_2 = "Summary.Status2";
	public final static String PATH_SUMMARIES_SUMMARY_2 = "Summaries.Summary2";
	
	public final static Map map = new HashMap() {
		{
			put( PATH_DETAIL_DATE_OF_BIRTH,  new RuleNodePath(PATH_DETAIL_DATE_OF_BIRTH, "#document/Session/Customer/Detail/DateOfBirth", RuleNodePath.IS_TYPE_TEXT));
			put( PATH_DETAIL_ELIGIBILITY,  new RuleNodePath(PATH_DETAIL_ELIGIBILITY, "#document/Session/Customer/Detail/Eligibility", RuleNodePath.IS_TYPE_NODE_SET));
			put( PATH_DETAIL_FAS_AGENT,  new RuleNodePath(PATH_DETAIL_FAS_AGENT, "#document/Session/Customer/Detail/FasAgent", RuleNodePath.IS_TYPE_NODE_SET));
			put( PATH_DETAIL_INVITATIONS,  new RuleNodePath(PATH_DETAIL_INVITATIONS, "#document/Session/Customer/Detail/Invitations", RuleNodePath.IS_TYPE_NODE_SET));
			put( PATH_DETAIL_RELEATED_CUSTOMER,  new RuleNodePath(PATH_DETAIL_RELEATED_CUSTOMER, "#document/Session/Customer/Detail/RelatedCustomer", RuleNodePath.IS_TYPE_NODE_SET));
			put( PATH_DETAIL_RESTRICTION,  new RuleNodePath(PATH_DETAIL_RESTRICTION, "#document/Session/Customer/Detail/Restriction", RuleNodePath.IS_TYPE_NODE_SET));
			put( PATH_DETAIL_STATUS,  new RuleNodePath(PATH_DETAIL_STATUS, "#document/Session/Customer/Detail/Status", RuleNodePath.IS_TYPE_TEXT));
			put( PATH_EXTERNAL_LINKS,  new RuleNodePath(PATH_EXTERNAL_LINKS, "#document/Session/Customer/ExternalLinks", RuleNodePath.IS_TYPE_NODE));
			put( PATH_EXTERNAL_LINK,  new RuleNodePath(PATH_EXTERNAL_LINK, "#document/Session/Customer/ExternalLinks/ExternalLink", RuleNodePath.IS_TYPE_NODE_SET));
			put( PATH_SUMMARY_DATE_OF_BIRTH,  new RuleNodePath(PATH_SUMMARY_DATE_OF_BIRTH, "#document/Session/Customer/Summary/DateOfBirth", RuleNodePath.IS_TYPE_TEXT));
			put( PATH_SUMMARIES_SUMMARY,  new RuleNodePath(PATH_SUMMARIES_SUMMARY, "#document/Session/Customer/Summaries/Summary", RuleNodePath.IS_TYPE_NODE_SET));
			put( PATH_SUMMARY_STATUS,  new RuleNodePath(PATH_SUMMARY_STATUS, "#document/Session/Customer/Summary/Status", RuleNodePath.IS_TYPE_TEXT));

			put( PATH_DETAIL_DATE_OF_BIRTH_2,  new RuleNodePath(PATH_DETAIL_DATE_OF_BIRTH_2, "#document/Session/SecondaryCustomer/Detail/DateOfBirth", RuleNodePath.IS_TYPE_TEXT));
			put( PATH_DETAIL_ELIGIBILITY_2,  new RuleNodePath(PATH_DETAIL_ELIGIBILITY_2, "#document/Session/SecondaryCustomer/Detail/Eligibility", RuleNodePath.IS_TYPE_NODE_SET));
			put( PATH_DETAIL_FAS_AGENT_2,  new RuleNodePath(PATH_DETAIL_FAS_AGENT_2, "#document/Session/SecondaryCustomer/Detail/FasAgent", RuleNodePath.IS_TYPE_NODE_SET));
			put( PATH_DETAIL_INVITATIONS_2,  new RuleNodePath(PATH_DETAIL_INVITATIONS_2, "#document/Session/SecondaryCustomer/Detail/Invitations", RuleNodePath.IS_TYPE_NODE_SET));
			put( PATH_DETAIL_RELEATED_CUSTOMER2,  new RuleNodePath(PATH_DETAIL_RELEATED_CUSTOMER2, "#document/Session/SecondaryCustomer/Detail/RelatedCustomer", RuleNodePath.IS_TYPE_NODE_SET));
			put( PATH_DETAIL_RESTRICTION_2,  new RuleNodePath(PATH_DETAIL_RESTRICTION_2, "#document/Session/SecondaryCustomer/Detail/Restriction", RuleNodePath.IS_TYPE_NODE_SET));
			put( PATH_DETAIL_STATUS_2,  new RuleNodePath(PATH_DETAIL_STATUS_2, "#document/Session/SecondaryCustomer/Detail/Status", RuleNodePath.IS_TYPE_TEXT));
			put( PATH_EXTERNAL_LINKS_2,  new RuleNodePath(PATH_EXTERNAL_LINKS_2, "#document/Session/SecondaryCustomer/ExternalLinks", RuleNodePath.IS_TYPE_NODE));
			put( PATH_EXTERNAL_LINK_2,  new RuleNodePath(PATH_EXTERNAL_LINK_2, "#document/Session/SecondaryCustomer/ExternalLinks/ExternalLink", RuleNodePath.IS_TYPE_NODE_SET));
			put( PATH_SUMMARY_DATE_OF_BIRTH_2,  new RuleNodePath(PATH_SUMMARY_DATE_OF_BIRTH_2, "#document/Session/SecondaryCustomer/Summary/DateOfBirth", RuleNodePath.IS_TYPE_TEXT));
			put( PATH_SUMMARIES_SUMMARY_2,  new RuleNodePath(PATH_SUMMARIES_SUMMARY_2, "#document/Session/SecondaryCustomer/Summaries/Summary", RuleNodePath.IS_TYPE_NODE_SET));
			put( PATH_SUMMARY_STATUS_2,  new RuleNodePath(PATH_SUMMARY_STATUS_2, "#document/Session/SecondaryCustomer/Summary/Status", RuleNodePath.IS_TYPE_TEXT));
		}
			
	};
	
	// $NoKeywords $
	SessionNodePathMap(){   
		super(); 
		super.map = this.map;
	}
	
	public static void main(String args[]){
		SessionNodePathMap map = new SessionNodePathMap();
		System.out.println(map.get(SessionNodePathMap.PATH_DETAIL_DATE_OF_BIRTH));
	}
}
