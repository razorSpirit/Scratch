package com.ingdirect.util.rules;

import com.ingdirect.util.StringUtil;

/**
 * @version $Revision: 239 $
 */
public class RuleNodePath {
	// $NoKeywords $
	public static final int IS_TYPE_NONE = 0;
	public static final int IS_TYPE_NODE = 1;
	public static final int IS_TYPE_NODE_SET = 2;
	public static final int IS_TYPE_TEXT = 3;

	private String path = null;
	private String pathName = null;
	private int typeValue = IS_TYPE_TEXT;
	
	
	public RuleNodePath(){
		super();
	}
	
	public RuleNodePath(String pathName){
		this.pathName = pathName;
		typeValue = IS_TYPE_NONE;
	}
	
	RuleNodePath(RuleNodePath nodePath){
		this();
		this.path = nodePath.getPath();
		this.pathName=nodePath.getPathName();
		
		if(! this.isNoneType() ){
			this.typeValue = nodePath.typeValue;
		} 
	}
	
	RuleNodePath(String pathName, String path, int isType){
		this();
		this.path = path;
		this.pathName = pathName;
		
		switch(isType){
			case IS_TYPE_NODE:
				typeValue=isType;
				break;
			case IS_TYPE_NODE_SET:
				typeValue=isType;
				break;
			case IS_TYPE_TEXT:
				typeValue=isType;
				break;		
				
			default:
				typeValue=IS_TYPE_TEXT;
				break;				
		}
	}
	
	public String getPathName() { return pathName; }
	void setPathName(String pathName) { this.pathName = pathName; }

	void setPath(String path) { this.path = path; }
	public String getPath() { return path; }
	
	public boolean isNodeType(){ return this.typeValue == IS_TYPE_NODE; }
	public boolean getIsNodeType() { return isNodeType(); }
	public void setNodeType(){ 	this.typeValue = IS_TYPE_NODE;	}
	
	public boolean isNodeSetType(){ return this.typeValue == IS_TYPE_NODE_SET;}
	public boolean getIsNodeSetType() { return isNodeSetType();}
	public void setNodeSetType(){ this.typeValue = IS_TYPE_NODE_SET; }
	
	public boolean isTextType(){ return this.typeValue == IS_TYPE_TEXT;}
	public boolean getIsTextType() { return isTextType();}
	public void setTextType(){ this.typeValue = IS_TYPE_TEXT; }

	public boolean isNoneType(){ return this.typeValue == IS_TYPE_NONE;}
	
	public String toString(){
		StringBuffer sb = new StringBuffer();
		sb.append("============ RuleNodePath ===========\n")
		  .append("PathName("+StringUtil.fillNull(pathName)+")\n")
		  .append("Path("+StringUtil.fillNull(path)+")\n")
		  .append("Type("+ (isTextType() ? "Text" : (isNodeType() ? "Node" : (isNodeSetType() ? "NodeSet" : "None") ) )+")" );
		
		return sb.toString();
	}	
		
}
