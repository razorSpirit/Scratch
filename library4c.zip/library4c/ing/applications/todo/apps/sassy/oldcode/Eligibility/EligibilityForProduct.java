package com.ingdirect.dg.util;

// Standard Java 
import java.util.List;
//   Third Party
// ING Direct
import com.ingdirect.dg.xmlbind.data.CustDetail;
//TODO ajb: add me to subversion
/**
 * This class serves as an abstract base class for all Eligibility Products.
 *  
 * @version $Revision: $
 */
public abstract class EligibilityForProduct  {
	// $NoKeywords $
	private String cif = null;
	private List list = null;
	
	public EligibilityForProduct() { super(); }
	
	public EligibilityForProduct(String cif){
		super();
		this.cif = cif;
	}
	
	public final CustDetail.Eligibility getEligibility(){
		return getEligibility(cif);
	}
	
	public abstract CustDetail.Eligibility getEligibility(String cif);
	
	public String getCif(){ return cif; }
	public void setCif(String cif) { this.cif = cif;}

	public List getList(){ return list; }
	public void setList(List list) { this.list = list;}
	
	//implements Runnable
	//public void run(){
	//	list.add( getEligibility() );
	//}
	
} //~
