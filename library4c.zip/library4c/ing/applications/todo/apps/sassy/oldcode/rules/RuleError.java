package com.ingdirect.util.rules;

//Standard Java
//   Third Party

//   ING DIRECT
import com.ingdirect.util.StringUtil;
import com.ingdirect.util.ExceptionUtil;

/**
 * This class represent an Error condition that 
 * will be placed into the ErrorResult object.
 *
 * Please refer to the the rule framework.
 *  
 * @see RuleEngineImpl, package.html
 * 
 * @author abrida
 * @version $Revision: 409 $
 */
public class RuleError {
	/**
	 * Contains a code from RuleConstants that is prefixed with ERROR_CODE_
	 * to quickly identify or tag an Error Condition.
	 * @see RuleConstants
	 */ 
	private String code = null;
	
	/**
	 * Descriptive information about an error that may include keywords
	 * or additional data to troubleshoot the issue.
	 */ 
	private String description = null;
	
	/**
	 * A java exception that may have been caught.
	 */ 
	private Exception exception = null;
	
	/**
	 * Default Constructor.
	 */ 
	public RuleError(){
		super();
	}

	/**
	 * 
	 * @param code - String representing an id for this error
	 * @param description - a description of the error
	 * @param exception - any Java exception that may have been caught
	 * @see code 
	 * @see description
	 * @see exception
	 */ 
	public RuleError(String code, String description, Exception exception){
		this.code = code;
		this.description = description;
		this.exception = exception;
	}
	
	/**
	 * Getter for code
 	 * @return
	 * @see code
	 */	
	public String getCode(){ return code; }
	/**
	 * Setter for code.
	 * @param code
	 * @see code
	 */ 
	public void setCode(String code) { this.code = code;}
	
	/**
	 * Getter for description
 	 * @return
	 * @see description
	 */	
	public String getDescription(){ return description; }
	/**
	 * Setter for description.
	 * @param description
	 * @see description
	 */ 
	public void setDescription(String description) { this.description = description;}

	/**
	 * Getter for exception
 	 * @return
	 * @see exception
	 */	
	public Exception getException(){ return exception; }
	/**
	 * Setter for exception.
	 * @param exception
	 * @see exception
	 */ 
	public void setException(Exception exception) { this.exception = exception;}
	
	/**
	 * 
	 * @return String representation of this object.
	 */ 
	public String toString(){
		StringBuffer sb = new StringBuffer();
		
		sb.append("\nCode("+StringUtil.fillNull(getCode())+")");
		sb.append("\nDescription("+StringUtil.fillNull(getDescription())+")");
		sb.append("\nException("+ ( exception == null ? "NULL" : ExceptionUtil.getStackTrace(exception) ) + ")" );
		
		return sb.toString();
	}
	
} //~
