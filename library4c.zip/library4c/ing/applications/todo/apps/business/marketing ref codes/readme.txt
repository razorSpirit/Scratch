Tony, I just got off the phone with Tammy. See attached the doc she sent to me. This may be the same doc you got your hands on. From a high-level my understanding is these are the types of ref codes:

 

1. Cookies:

 - Refer-a-friend

 - Banner on yahoo (www/yahoo landing pages) - POSTed to the OpenAccount app

 - These ref codes are never typed in by the customer

 - Type: Automatic

 

2. Customers type in ref code

 - Customers get it from paper mailing, or special promotion on flyer

 - Two variations:

   - Generic code:

     - 4 or 5 letters typed in in the OpenAccount app field

     - Type: User provided

   - Specific code for 1 customer

     - 4 or 5 letters + sequence of alphanumeric digits, from the "coupon" (piece of paper)

     - Type: Automatic

     - "FSI" - free standing insert (aka "coupon")

   SASSy used to type in only the ref code piece, not the coupon

 

3. Bonus cheque (RAF paper version)

 - Ref code + "/" + encrypted account number (similar but not identical to FSI, bonus cheque may not have numbers)

 - Customer types it in

 - Type: User-provided

 

4. Solicit code/pre-fill code:

 - Used for IDEA only currently.

 - Ref code (4/5 letters) + (no slash) 12 numbers

 - Lookup in MCIF table

 

In SASSy these types of ref codes should probably be possible, from what I understand:

- Bonus cheques

- FSI

- Solicit code/pre-fill code

- Not Refer a Friend or Gift Referral (subset) (it's a cookie)

Note that the above 3 are all a ref code + some alphanumeric combination. (not just �DMSA�)

 

Note: The bonus is listed on CIF level, so ref code is already entered with (visitor) CIF creation.

 

http://10.20.1.94/admin/tools/CreateBonusCheck.asp

�      This links to the ingmnqatchls1 server. If needed I can see how to get access to this ASP page

 

Thanks,

Walter

 


--------------------------------------------------------------------------------

From: Osborne, Tamara 
Sent: Thursday, December 04, 2008 12:07 PM
To: Van Geffen, Walter
Subject: Promotions document

