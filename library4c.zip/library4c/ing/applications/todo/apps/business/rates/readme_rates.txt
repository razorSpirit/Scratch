Rates are displayed from static page using
  accounttype.js
  which is genereated nightly.

The Open Account process gets rates from PROFILE.

****SO THERE COULD BE A CONFLICT****

Some flows actually parse accounttype.js.

What MRPC's are involved ?


Rates

OpenAccount Site

https://banking.ingdirect.com/savings/initial.vm?type=3500




Batch   
   Runs nightly
   
   AccountTypeExport.java
      Uses AccountTypeUtility
        calls MRPC :
          1) Z912 Deposit Rates
          2) Z113 Deposit Rates Detail
        
      Uses RateDAOImpl
   
   AccountTypeUtility
   
   
   MRPC:
     (1) Z912 Deposit Rates
     (2) 
   MRPC : ZLRAT
   
      
   